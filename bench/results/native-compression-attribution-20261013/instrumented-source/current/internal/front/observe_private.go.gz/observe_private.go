package front

import (
	"compress/gzip"
	"sync/atomic"
	"time"
)

var observedCloseCalls atomic.Uint64
var observedCloseNanos atomic.Uint64

// Attribution only: elapsed Close time is not compression CPU time.
func observeGzipClose(writer *gzip.Writer) error {
	started := time.Now()
	err := writer.Close()
	observedCloseCalls.Add(1)
	observedCloseNanos.Add(uint64(time.Since(started).Nanoseconds()))
	return err
}
func GzipCloseObservation() (uint64, uint64) {
	return observedCloseCalls.Load(), observedCloseNanos.Load()
}
