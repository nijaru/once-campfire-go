package front

import (
	"bytes"
	"compress/gzip"
	"errors"
	"testing"
)

type observationErrorSink struct{ err error }

func (s observationErrorSink) Write([]byte) (int, error) { return 0, s.err }
func TestPrivateCloseObservation(t *testing.T) {
	before, _ := GzipCloseObservation()
	payload := bytes.Repeat([]byte("bench write 12345 "), 500)
	encode := func(observe bool) []byte {
		var output bytes.Buffer
		writer, err := gzip.NewWriterLevel(&output, 6)
		if err != nil {
			t.Fatal(err)
		}
		writer.Header.OS = 3
		if _, err := writer.Write(payload); err != nil {
			t.Fatal(err)
		}
		if observe {
			err = observeGzipClose(writer)
		} else {
			err = writer.Close()
		}
		if err != nil {
			t.Fatal(err)
		}
		return output.Bytes()
	}
	if !bytes.Equal(encode(false), encode(true)) {
		t.Fatal("changed gzip member")
	}
	expected := errors.New("sink failure")
	writer, _ := gzip.NewWriterLevel(observationErrorSink{expected}, 6)
	if !errors.Is(observeGzipClose(writer), expected) {
		t.Fatal("lost close error")
	}
	after, elapsed := GzipCloseObservation()
	if after-before != 2 || elapsed == 0 {
		t.Fatalf("wrong observation: %d %d", after-before, elapsed)
	}
}
