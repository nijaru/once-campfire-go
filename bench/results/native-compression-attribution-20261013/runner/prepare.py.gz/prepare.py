"""Prepare isolated attribution copies; never modify either production checkout."""
import difflib, hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
ROOT=Path.cwd(); WORK=ROOT/'.cache/native-compression-work-20261012'; WORK.mkdir(exist_ok=True)
HOOK='''package front

import (
 "compress/gzip"
 "sync/atomic"
 "time"
)

var observedCloseCalls atomic.Uint64
var observedCloseNanos atomic.Uint64

// Attribution only: elapsed Close time is not compression CPU time.
func observeGzipClose(writer *gzip.Writer) error {
 started := time.Now()
 err := writer.Close()
 observedCloseCalls.Add(1)
 observedCloseNanos.Add(uint64(time.Since(started).Nanoseconds()))
 return err
}
func GzipCloseObservation() (uint64, uint64) {
 return observedCloseCalls.Load(), observedCloseNanos.Load()
}
'''
TEST='''package front

import (
 "bytes"
 "compress/gzip"
 "errors"
 "testing"
)

type observationErrorSink struct{ err error }
func (s observationErrorSink) Write([]byte) (int, error) { return 0, s.err }
func TestPrivateCloseObservation(t *testing.T) {
 before, _ := GzipCloseObservation()
 payload := bytes.Repeat([]byte("bench write 12345 "), 500)
 encode := func(observe bool) []byte {
  var output bytes.Buffer
  writer, err := gzip.NewWriterLevel(&output, 6)
  if err != nil { t.Fatal(err) }
  writer.Header.OS = 3
  if _, err := writer.Write(payload); err != nil { t.Fatal(err) }
  if observe { err = observeGzipClose(writer) } else { err = writer.Close() }
  if err != nil { t.Fatal(err) }
  return output.Bytes()
 }
 if !bytes.Equal(encode(false), encode(true)) { t.Fatal("changed gzip member") }
 expected := errors.New("sink failure")
 writer, _ := gzip.NewWriterLevel(observationErrorSink{expected}, 6)
 if !errors.Is(observeGzipClose(writer), expected) { t.Fatal("lost close error") }
 after, elapsed := GzipCloseObservation()
 if after-before != 2 || elapsed == 0 { t.Fatalf("wrong observation: %d %d", after-before, elapsed) }
}
'''
metadata={'sources':{},'hypothesis':'Determine whether the native compression CPU/write discrepancy persists on restored production, with equal successful gzip-close counts and matched receipt populations. Close elapsed is NOT CPU. A material repeated owner is a candidate-selection clue, not POST-tail causality.','budget':'One sequential current/upstream instrumented pair; 3000 offered POST/s,64 workers,2+20s per arm;132000 expected writes;no extra sweep or optimization candidate.','settings':{'go':'1.27.1','CGO_ENABLED':1,'tags':'sqlite_fts5','GOAMD64':'v1','GOMAXPROCS':4,'readers':4,'jobs':3,'GOGC':100,'gzip_level':6},'instrumentation':'Identical explicit gzip Close wrapper and shutdown counter. Unchanged stock gzip writer/pool/types; no queue/cache/authorization/cancellation changes. Process CPU uses joined OS wait4. Capture startup excludes setup/login via restart.','discriminator':'Compare common gzip.Writer.Close/Write absolute sampled CPU per exact-audited write, call counts, wire sizes and joined process CPU. A >=10% owner difference with >=1s sampled owner CPU per arm is material attribution, not a statistical latency gate. Equal costs close the old owner premise for this workload; insufficient samples or invalid populations are inconclusive, not permission to extend the budget.','client_commit':'4a358518a130fe33b0356db9224f96082030b1e7'}
for app,rev,assets in [('current','8351224',ROOT/'assets/generated'),('upstream','c4ab53d',ROOT/'.cache/local-post-work-20261011/upstream/assets/generated')]:
 dest=WORK/app
 if dest.exists():raise RuntimeError(f'refusing existing source {dest}')
 archive=WORK/f'{app}.tar';archive.write_bytes(subprocess.check_output(['git','archive',rev]))
 dest.mkdir()
 with tarfile.open(archive) as tar:tar.extractall(dest,filter='data')
 shutil.copytree(assets,dest/'assets/generated')
 tls='reference/crates/campfire/src/integrations/testdata/tls'
 shutil.copytree(ROOT/tls,dest/tls)
 changes=[]
 for name in ['internal/front/compression.go','internal/front/gzip_cache.go']:
  p=dest/name;old=p.read_text();new=old.replace('wrapped.writer.Close()', 'observeGzipClose(wrapped.writer)') if name.endswith('compression.go') else old.replace('writer.Close()', 'observeGzipClose(writer)')
  assert old!=new and new.count('observeGzipClose(')==1,name
  p.write_text(new)
  changes.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
 p=dest/'cmd/campfire/main.go';old=p.read_text();assert old.count('func run() error {')==1
 new=old.replace('func run() error {','func run() error {\n defer func() {\n  calls, nanos := front.GzipCloseObservation()\n  fmt.Printf("GZIP_CLOSE_OBSERVATION calls=%d elapsed_nanos=%d\\n", calls, nanos)\n }()')
 p.write_text(new);changes.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/cmd/campfire/main.go',tofile='b/cmd/campfire/main.go')))
 (dest/'internal/front/observe_private.go').write_text(HOOK)
 (dest/'internal/front/observe_private_test.go').write_text(TEST)
 subprocess.check_call(['gofmt','-w','internal/front/observe_private.go','internal/front/observe_private_test.go','cmd/campfire/main.go'],cwd=dest)
 (WORK/f'{app}.patch').write_text(''.join(changes))
 metadata['sources'][app]={'revision':subprocess.check_output(['git','rev-parse',rev],text=True).strip(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'private_source_sha256':{str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.rglob('*')) if p.is_file() and (str(p.relative_to(dest)).startswith(('cmd/','internal/','assets/','third_party/')) or p.name in ('go.mod','go.sum'))}}
shutil.copytree(ROOT/'bench/httprate',WORK/'client');shutil.copy2(ROOT/'bench/acknowledged_writes.py',WORK/'acknowledged_writes.py')
metadata['client_source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((WORK/'client').glob('*.go'))}
metadata['audit_helper_sha256']=hashlib.sha256((WORK/'acknowledged_writes.py').read_bytes()).hexdigest()
(WORK/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Prepared both isolated source identities and identical explicit Close hooks; no production changes.')
