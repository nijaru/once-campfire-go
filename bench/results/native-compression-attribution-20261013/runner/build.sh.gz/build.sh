#!/bin/bash
set -eu
cd "$(dirname "$0")"
[ "$(/usr/local/go/bin/go env GOVERSION)" = go1.27.1 ]
export CGO_ENABLED=1 GOAMD64=v1 GOMAXPROCS=4
export GOCACHE="$PWD/go-build"
for app in current upstream; do
  (
    cd "$app"
    /usr/local/go/bin/go test -tags sqlite_fts5 ./internal/front -run TestPrivateCloseObservation -count=1
    /usr/local/go/bin/go build -tags sqlite_fts5 -trimpath -buildvcs=false -o "../$app-native" ./cmd/campfire
  )
done
mkdir -p current/bench
# Replace the archived benchmark client, not copy into its existing directory.
rm -rf current/bench/httprate
cp -R client current/bench/httprate
(cd current && /usr/local/go/bin/go test ./bench/httprate -count=1 && /usr/local/go/bin/go build -trimpath -buildvcs=false -o ../httprate-native ./bench/httprate)
/usr/local/go/bin/go version -m current-native
/usr/local/go/bin/go version -m upstream-native
sha256sum current-native upstream-native httprate-native
