package main

import (
	"context"
	"encoding/csv"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"testing"
	"time"
)

func TestPrivateTimingRecords(t *testing.T) {
	var mu sync.Mutex
	ids := map[string]bool{}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		ids[r.Header.Get("X-Benchmark-Request")] = true
		mu.Unlock()
		io.WriteString(w, "complete")
	}))
	defer server.Close()
	c := testConfig(server.URL)
	c.Concurrency = 4
	c.Rate = 1000
	c.Duration = 50 * time.Millisecond
	c.Pacing = "active"
	c.TimingPath = filepath.Join(t.TempDir(), "client.csv")
	result, err := run(context.Background(), c)
	if err != nil || result.OK != 50 || result.Errors != 0 {
		t.Fatalf("population: %+v %v", result, err)
	}
	file, err := os.Open(c.TimingPath)
	if err != nil {
		t.Fatal(err)
	}
	defer file.Close()
	rows, err := csv.NewReader(file).ReadAll()
	if err != nil {
		t.Fatal(err)
	}
	if len(rows) != 51 || len(ids) != 50 {
		t.Fatalf("timing populations %d/%d", len(rows), len(ids))
	}
	seen := map[string]bool{}
	for _, row := range rows[1:] {
		if seen[row[0]] || !ids[row[0]] {
			t.Fatalf("invalid timing identity %s", row[0])
		}
		seen[row[0]] = true
		stamps := make([]int64, 4)
		for i := range stamps {
			stamps[i], err = strconv.ParseInt(row[i+1], 10, 64)
			if err != nil {
				t.Fatal(err)
			}
		}
		if stamps[0] > stamps[1] || stamps[1] > stamps[2] || stamps[2] > stamps[3] || row[5] != "8" {
			t.Fatalf("invalid completed response timing: %v", row)
		}
	}
}
