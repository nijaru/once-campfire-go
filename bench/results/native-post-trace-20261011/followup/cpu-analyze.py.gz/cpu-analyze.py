import csv
import json
import math
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).parent
HEADER = re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+) (.*)$')


def field(text, key):
    match = re.search(r'\b' + key + r'=(?:"([^"]*)"|([^ ]+))', text)
    return (match[1] if match[1] is not None else match[2]) if match else None


def distribution(values):
    values = sorted(values)
    return {'count': len(values), 'mean': sum(values) / len(values),
            'p50': values[math.ceil(.5 * len(values)) - 1],
            'p99': values[math.ceil(.99 * len(values)) - 1], 'max': values[-1]}


def analyze(stem):
    tasks = {}
    proc = subprocess.Popen(['go', 'tool', 'trace', '-d=parsed', str(ROOT / 'capture' / (stem + '.trace'))],
                            stdout=subprocess.PIPE, text=True, bufsize=1024 * 1024)
    for line in proc.stdout:
        if not line.startswith('M='):
            continue
        match = HEADER.match(line)
        kind, stamp, text = match[4], int(match[5]), match[6]
        if kind == 'TaskBegin' and field(text, 'Type') == 'http.message.create':
            tasks[field(text, 'ID')] = {'begin': stamp}
        elif kind == 'TaskEnd' and field(text, 'ID') in tasks:
            tasks[field(text, 'ID')]['end'] = stamp
        elif kind == 'Log' and field(text, 'Task') in tasks:
            task = tasks[field(text, 'Task')]
            if field(text, 'Category') == 'benchmark.ingress':
                task['request_id'] = field(text, 'Message').split(',')[0]
            elif field(text, 'Category') == 'membership.cpu':
                assert 'cpu_ns' not in task, task
                for key, value in zip(['wall_ns', 'cpu_ns', 'vm_steps', 'fullscan_steps', 'changes'],
                                      field(text, 'Message').split(',')):
                    task[key] = int(value)
                task['probe_stamp'] = stamp
    assert proc.wait() == 0
    timed = {t['request_id']: t for t in tasks.values() if 'request_id' in t}
    assert len(timed) == 9000, len(timed)
    clients = list(csv.DictReader((ROOT / 'capture' / (stem + '-client.csv')).open()))
    assert len(clients) == 9000
    slowest = {c['request_id'] for c in sorted(clients, key=lambda c: int(c['finished_unix_ns']) - int(c['started_unix_ns']))[-90:]}
    def group(ids):
        rows = [timed[ident] for ident in ids]
        for row in rows:
            assert row['begin'] <= row['probe_stamp'] <= row['end']
        return {key: distribution([r[key] for r in rows]) for key in ['wall_ns', 'cpu_ns', 'vm_steps', 'fullscan_steps', 'changes']}
    result = {'all': group(set(timed)), 'slowest_client_service_one_percent': group(slowest)}
    (ROOT / 'capture' / (stem + '-membership.json')).write_text(json.dumps(list(timed.values()), separators=(',', ':')) + '\n')
    print(stem, json.dumps(result), flush=True)
    return result


if __name__ == '__main__':
    result = {}
    for stem in ['go-before-1', 'go-1', 'go-2', 'go-before-2']:
        result[stem] = analyze(stem)
        (ROOT / 'capture' / 'membership-summary.json').write_text(json.dumps(result, indent=2) + '\n')
