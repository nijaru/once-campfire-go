"""Private attribution of retained traces; no new instrumentation or timing runs."""
import bisect
import collections
import csv
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).parent / 'capture'
HEADER = re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+) (.*)$')
TRANSITION = re.compile(r' (\w+)->(\w+)')


def field(text, key):
    match = re.search(r'\b' + key + r'=(?:"([^"]*)"|([^ ]+))', text)
    return (match[1] if match[1] is not None else match[2]) if match else None


def events(stream):
    item = None
    for line in stream:
        match = HEADER.match(line)
        if match:
            if item is not None:
                yield item
            item = (match, [])
        elif item is not None:
            item[1].append(line.rstrip())
    if item is not None:
        yield item


def stack_parts(lines):
    transition, caller = [], []
    target = None
    for line in lines:
        if line == 'TransitionStack=':
            target = transition
        elif line == 'Stack=':
            target = caller
        elif target is not None and line.strip():
            target.append(line.strip())
    return transition, caller


def creation_frame(stack):
    for index, line in enumerate(stack[:-1]):
        if ('/internal/database.(*DB).createMessage.func1 @ ' in line or
                '/internal/database.(*DB).CreateMessage.func1 @ ' in line):
            return stack[index + 1]
    return None


def analyze(stem):
    tasks = json.loads((ROOT / (stem + '.requests.json')).read_text())
    timed = {t['request_id']: t for t in tasks if 'request_id' in t}
    by_parent = collections.defaultdict(list)
    for ident, task in timed.items():
        by_parent[task['gid']].append((task['begin'], task['end'], ident))
    for spans in by_parent.values():
        spans.sort()
    starts = {gid: [span[0] for span in spans] for gid, spans in by_parent.items()}

    def request(gid, stamp):
        if gid not in by_parent:
            return None
        index = bisect.bisect_right(starts[gid], stamp) - 1
        if index < 0:
            return None
        begin, end, ident = by_parent[gid][index]
        return ident if begin <= stamp < end else None

    children, latest, waiting, resuming = {}, {}, {}, {}
    rows, waits = [], []
    reference_waiting, reference_expected = {}, collections.Counter()
    proc = subprocess.Popen(['go', 'tool', 'trace', '-d=parsed', str(ROOT / (stem + '.trace'))],
                            stdout=subprocess.PIPE, text=True, bufsize=1024 * 1024)
    for match, stack in events(proc.stdout):
        if match[4] != 'StateTransition' or field(match[6], 'GoID') is None:
            continue
        gid, emitter, stamp = int(field(match[6], 'GoID')), int(match[3]), int(match[5])
        old, new = TRANSITION.search(match[6]).groups()
        # Generation-boundary state snapshots (e.g. Waiting->Waiting) are not
        # wakes. The original waiting.py incorrectly truncated one four-ns tail.
        if old == new:
            continue
        # Independently clip waiting intervals using the earlier method.
        if old == 'Waiting' and gid in reference_waiting:
            began, is_exec = reference_waiting.pop(gid)
            if is_exec:
                for begin, end, ident in by_parent[gid]:
                    if begin >= stamp:
                        break
                    duration = max(0, min(stamp, end) - max(began, begin))
                    reference_expected[ident] += duration
        if new == 'Waiting' and gid in by_parent:
            transition, _ = stack_parts(stack)
            reference_waiting[gid] = (stamp, any('(*SQLiteStmt).exec' in f for f in transition))
        if old == 'NotExist' and new == 'Runnable':
            transition, caller = stack_parts(stack)
            if any('(*SQLiteStmt).exec.func1 @ ' in line for line in transition):
                ident = request(emitter, stamp)
                if ident is not None:
                    row = {'request_id': ident, 'child': gid, 'parent': emitter,
                           'created': stamp, 'state': new, 'since': stamp,
                           'spans': [], 'site': creation_frame(caller)}
                    children[gid] = latest[emitter] = row
            continue
        if gid in children:
            row = children[gid]
            assert row['state'] == old, (stem, gid, row['state'], old)
            row['spans'].append((row['since'], stamp, old))
            row['state'], row['since'] = new, stamp
            if new == 'Running' and 'first_running' not in row:
                row['first_running'] = stamp
            if new == 'NotExist':
                row['ended'] = stamp
                rows.append(row)
        if new == 'Waiting' and request(gid, stamp) is not None:
            transition, _ = stack_parts(stack)
            if any('(*SQLiteStmt).exec @ ' in line for line in transition):
                assert gid not in waiting
                row = latest.get(gid)
                active = row is not None and row.get('ended', stamp + 1) >= stamp
                waiting[gid] = {'request_id': request(gid, stamp), 'parent': gid, 'begin': stamp,
                                'reason': field(match[6], 'Reason'), 'site': creation_frame(transition),
                                'child': row['child'] if active else None}
        if old == 'Waiting' and new == 'Runnable' and gid in waiting:
            window = waiting.pop(gid)
            window['wake'] = stamp
            window['waker'] = emitter
            window['child_wake'] = emitter == window['child']
            if emitter in children:
                assert window['child_wake'], (stem, window, emitter)
            resuming[gid] = window
            waits.append(window)
        if new == 'Running' and gid in resuming:
            resuming.pop(gid)['parent_running'] = stamp
    assert proc.wait() == 0
    assert not waiting and not resuming, (waiting, resuming)
    assert len(rows) == len(children), (stem, len(rows), len(children))
    for row in rows:
        row['child_lifetime_ns'] = row['ended'] - row['created']
        row['start_delay_ns'] = row['first_running'] - row['created']
        row['child_states_ns'] = {}
        for begin, end, state in row['spans']:
            row['child_states_ns'][state] = row['child_states_ns'].get(state, 0) + end - begin
        assert sum(row['child_states_ns'].values()) == row['child_lifetime_ns']
        del row['state'], row['since']
    for window in waits:
        window['wait_ns'] = window['wake'] - window['begin']
        window['parent_resume_ns'] = window['parent_running'] - window['wake']
        window['child_overlap_ns'] = {}
        if window['child'] is not None:
            for begin, end, state in children[window['child']]['spans']:
                overlap = max(0, min(end, window['wake']) - max(begin, window['begin']))
                if overlap:
                    window['child_overlap_ns'][state] = window['child_overlap_ns'].get(state, 0) + overlap
        window['uncovered_ns'] = window['wait_ns'] - sum(window['child_overlap_ns'].values())
        assert window['uncovered_ns'] >= 0
    for row in rows:
        del row['spans']

    # Independent earlier parser includes GC/preemption waits with an exec frame,
    # not only semaphore waits. Match it exactly rather than silently dropping them.
    earlier = json.loads((ROOT / (stem + '-waits.json')).read_text())
    expected, actual = collections.Counter(), collections.Counter()
    for span in earlier:
        if any('(*SQLiteStmt).exec' in frame for frame in span['stack']):
            expected[span['request_id']] += span['duration_ns']
    for window in waits:
        actual[window['request_id']] += window['wait_ns']
    assert actual == reference_expected, (stem, (actual - reference_expected).most_common(3),
                                          (reference_expected - actual).most_common(3))
    historical_deltas = {ident: actual[ident] - expected[ident] for ident in set(actual) | set(expected)
                         if actual[ident] != expected[ident]}

    clients = list(csv.DictReader((ROOT / (stem + '-correlated.csv')).open()))
    slowest = {c['request_id'] for c in sorted(clients, key=lambda c: int(c['client_service_ns']))[-90:]}

    def describe(ids):
        selected = [row for row in rows if row['request_id'] in ids]
        selected_waits = [window for window in waits if window['request_id'] in ids]
        def category(cs, ws):
            totals, reasons = collections.Counter(), collections.Counter()
            for row in cs:
                for key in ['child_lifetime_ns', 'start_delay_ns']:
                    totals[key] += row[key]
                for state, ns in row['child_states_ns'].items():
                    totals['child_' + state + '_ns'] += ns
            for window in ws:
                totals['wait_ns'] += window['wait_ns']
                totals['parent_resume_ns'] += window['parent_resume_ns']
                totals['uncovered_ns'] += window['uncovered_ns']
                reasons[window['reason']] += window['wait_ns']
                for state, ns in window['child_overlap_ns'].items():
                    totals['wait_child_' + state + '_ns'] += ns
            return {'children': len(cs), 'exec_frame_waits': len(ws), 'child_wakes': sum(w['child_wake'] for w in ws),
                    'mean_us_per_selected_request': {k: v / len(ids) / 1000 for k, v in totals.items()},
                    'wait_reason_mean_us_per_selected_request': {k: v / len(ids) / 1000 for k, v in reasons.items()}}
        sites = {row['site'] for row in selected if row['site']}
        return {'all_exec': category(selected, selected_waits),
                'creation': category([r for r in selected if r['site']], [w for w in selected_waits if w['site']]),
                'creation_sites': {site: category([r for r in selected if r['site'] == site],
                                                 [w for w in selected_waits if w['site'] == site]) for site in sorted(sites)}}
    (ROOT / (stem + '-children.json')).write_text(json.dumps({'children': rows, 'waits': waits}, separators=(',', ':')) + '\n')
    summary = {'requests': len(timed), 'children': len(rows), 'creation_children': sum(bool(r['site']) for r in rows),
               'independent_same_stream_wait_sums_match': True,
               'historical_waiting_parser_delta_ns': historical_deltas,
               'all': describe(set(timed)), 'slowest_client_service_one_percent': describe(slowest)}
    print(stem, json.dumps(summary['slowest_client_service_one_percent']['creation']), flush=True)
    return summary


if __name__ == '__main__':
    result = {}
    for stem in ['go-before-1', 'go-1', 'go-2', 'go-before-2']:
        result[stem] = analyze(stem)
        (ROOT / 'children-summary.json').write_text(json.dumps(result, indent=2) + '\n')
