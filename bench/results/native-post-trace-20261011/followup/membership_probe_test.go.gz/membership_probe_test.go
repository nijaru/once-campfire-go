package database

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime/trace"
	"testing"
	"time"
)

// Private diagnostic: equal isolated seed and authorization; only write ordering
// differs. It is not an HTTP acceptance or capacity benchmark.
func TestPrivateMembershipOrderCPU(t *testing.T) {
	root := os.Getenv("MEMBERSHIP_PROBE_ROOT")
	if root == "" {
		t.Fatal("missing private fixture root")
	}
	var labels map[string]json.RawMessage
	data, err := os.ReadFile(filepath.Join(root, "seed", "labels.json"))
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(data, &labels); err != nil {
		t.Fatal(err)
	}
	var room int64
	if err := json.Unmarshal(labels["rooms.hq"], &room); err != nil {
		t.Fatal(err)
	}
	var email string
	if err := json.Unmarshal(labels["emails.david"], &email); err != nil {
		t.Fatal(err)
	}
	seed, err := os.ReadFile(filepath.Join(root, "seed", "db", "production.sqlite3"))
	if err != nil {
		t.Fatal(err)
	}
	for _, order := range []string{"current", "upstream", "production"} {
		t.Run(order, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "probe.sqlite3")
			if err := os.WriteFile(path, seed, 0600); err != nil {
				t.Fatal(err)
			}
			d, err := Open(path, 4)
			if err != nil {
				t.Fatal(err)
			}
			defer d.Close()
			var user int64
			if err := d.Read.QueryRow("SELECT id FROM users WHERE email_address=?", email).Scan(&user); err != nil {
				t.Fatal(err)
			}
			f, err := os.Create(filepath.Join(os.Getenv("MEMBERSHIP_PROBE_OUTPUT"), order+".trace"))
			if err != nil {
				t.Fatal(err)
			}
			defer f.Close()
			if err := trace.Start(f); err != nil {
				t.Fatal(err)
			}
			defer trace.Stop()
			parent, cancel := context.WithCancel(context.Background())
			defer cancel()
			for i := range 1000 {
				ctx, task := trace.NewTask(parent, "probe."+order)
				body, plain := fmt.Sprintf("<p>bench write %d</p>", i), fmt.Sprintf("bench write %d", i)
				if order == "production" {
					_, err = d.CreateMessage(ctx, user, room, MessageInput{Body: &body, ClientID: fmt.Sprintf("probe-%d", i)})
				} else {
					err = d.Transaction(ctx, func(tx *sql.Tx) error {
						var receipt Room
						var author string
						if err := tx.QueryRowContext(ctx, "SELECT r.id,r.creator_id,coalesce(r.name,''),r.type,u.name FROM rooms r JOIN users u ON u.id=? WHERE r.id=? AND u.status=0 AND EXISTS(SELECT 1 FROM memberships m WHERE m.room_id=r.id AND m.user_id=u.id)", user, room).Scan(&receipt.ID, &receipt.CreatorID, &receipt.Name, &receipt.Type, &author); err != nil {
							return err
						}
						now := time.Now().UTC()
						stamp := Stamp(now)
						r, err := tx.ExecContext(ctx, "INSERT INTO messages(client_message_id,creator_id,room_id,created_at,updated_at) VALUES (?,?,?,?,?)", fmt.Sprintf("probe-%d", i), user, room, stamp, stamp)
						if err != nil {
							return err
						}
						id, err := r.LastInsertId()
						if err != nil {
							return err
						}
						ops := []struct {
							sql  string
							args []any
						}{
							{"INSERT INTO action_text_rich_texts(name,record_type,record_id,body,created_at,updated_at) VALUES ('body','Message',?,?,?,?)", []any{id, body, stamp, stamp}},
							{"INSERT INTO message_search_index(rowid,body) VALUES (?,?)", []any{id, plain}},
							{"UPDATE rooms SET updated_at=? WHERE id=?", []any{stamp, room}},
							{"UPDATE memberships SET unread_at=?,updated_at=? WHERE room_id=? AND user_id!=? AND involvement!='invisible' AND (connected_at IS NULL OR connected_at < ?)", []any{stamp, stamp, room, user, Stamp(now.Add(-60 * time.Second))}},
						}
						sequence := []int{0, 1, 2, 3}
						if order == "upstream" {
							sequence = []int{2, 3, 1, 0}
						}
						for _, index := range sequence {
							if _, err := tx.ExecContext(ctx, ops[index].sql, ops[index].args...); err != nil {
								return err
							}
						}
						return nil
					})
				}
				task.End()
				if err != nil {
					t.Fatal(err)
				}
			}
		})
	}
}
