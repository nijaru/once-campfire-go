import difflib,gzip,hashlib,http.cookiejar,json,os,re,shutil,signal,socket,sqlite3,subprocess,tempfile,time,urllib.parse,urllib.request
from pathlib import Path
ROOT=Path.cwd();WORK=ROOT/'.cache/compression-owner-20261012';OLD=ROOT/'.cache/local-post-work-20261011';SEED=ROOT/'.cache/parity-seeds/default';OUT=WORK/'receipts';OUT.mkdir(exist_ok=False)
labels=json.loads((SEED/'labels.json').read_text());fixture={}
for line in (ROOT/'.cache/shared-current/reference.env').read_text().splitlines():
 if line and not line.startswith('#'):k,v=line.split('=',1);fixture[k]=v
metadata={'baseline_source':'8351224','upstream_source':'c4ab53d','seed_sha256':hashlib.sha256((SEED/'db/production.sqlite3').read_bytes()).hexdigest(),'budget':'One sequential current/upstream body-capture pair, eight deterministic posts each. No latency claim. Match persisted IDs, client IDs, body, creator, room, FTS and complete decoded receipts; compare bodies and compression separately before choosing a candidate.','binaries':{app:hashlib.sha256((OLD/binary).read_bytes()).hexdigest() for app,binary in [('current','current'),('upstream','upstream-bin')]}}
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def ready(base,p):
 end=time.monotonic()+45
 while time.monotonic()<end:
  if p.poll() is not None:raise RuntimeError('server exited')
  try:
   if urllib.request.urlopen(base+'/up',timeout=1).status==200:return
  except OSError:pass
  time.sleep(.1)
 raise RuntimeError('server not ready')
def stop(p):
 if p.poll() is None:p.send_signal(signal.SIGTERM);p.wait(timeout=35)
 assert p.returncode==0,p.returncode
rows=[]
for app,binary in [('current','current'),('upstream','upstream-bin')]:
 with tempfile.TemporaryDirectory(prefix='runtime-',dir=WORK) as td:
  d=Path(td);db=d/'production.sqlite3'
  with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
  shutil.copytree(SEED/'storage',d/'files')
  with sqlite3.connect(db) as c:
   c.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id");c.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
   seed_fk=c.execute('PRAGMA foreign_key_check').fetchall();actor=c.execute('SELECT id FROM users WHERE email_address=?',(labels['emails.david'],)).fetchone()[0];before=c.execute('SELECT max(id) FROM messages').fetchone()[0]
  target,front=port(),port();base=f'http://127.0.0.1:{front}'
  env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ}|fixture|{'DISABLE_SSL':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(d),'CAMPFIRE_FILES_PATH':str(d/'files'),'GOMAXPROCS':'4','JOB_CONCURRENCY':'3','GOGC':'100'}
  log=(WORK/f'{app}.log').open('w');p=subprocess.Popen([str(OLD/binary),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   ready(base,p);jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
   body=client.open(base+'/session/new').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else ''
   client.open(urllib.request.Request(base+'/session',data=urllib.parse.urlencode({'email_address':labels['emails.david'],'password':labels['passwords.all'],'authenticity_token':csrf}).encode(),headers={'Sec-Fetch-Site':'same-origin'})).read()
   assert any(x.name=='session_token' for x in jar)
   body=client.open(base+f'/rooms/{labels["rooms.watercooler"]}').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else ''
   for seq in range(8):
    text=f'bench write {seq}';clientid=f'compression-probe-{seq}'
    req=urllib.request.Request(base+f'/rooms/{labels["rooms.hq"]}/messages',data=urllib.parse.urlencode({'message[body]':text,'message[client_message_id]':clientid,'authenticity_token':csrf}).encode(),headers={'Accept-Encoding':'gzip','Accept':'text/vnd.turbo-stream.html, text/html, application/xhtml+xml','X-CSRF-Token':csrf,'Sec-Fetch-Site':'same-origin','Content-Type':'application/x-www-form-urlencoded'})
    response=client.open(req);wire=response.read();assert response.status==200 and response.headers['Content-Encoding']=='gzip';plain=gzip.decompress(wire)
    assert plain.startswith(b'<turbo-stream') and plain.rstrip().endswith(b'</turbo-stream>') and text.encode() in plain and clientid.encode() in plain
    with sqlite3.connect(db) as c:
     r=c.execute("SELECT m.id,m.creator_id,m.room_id,rt.body,idx.body FROM messages m JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' JOIN message_search_index idx ON idx.rowid=m.id WHERE m.client_message_id=?",(clientid,)).fetchone()
    assert r and r[1]==actor and r[2]==int(labels['rooms.hq']) and r[3]==text and r[4].split()==text.split() and f'data-message-id="{r[0]}"'.encode() in plain
    (OUT/f'{app}-{seq}.html').write_bytes(plain);(OUT/f'{app}-{seq}.gzip').write_bytes(wire)
    rows.append({'app':app,'seq':seq,'id':r[0],'plain_bytes':len(plain),'wire_bytes':len(wire),'plain_sha256':hashlib.sha256(plain).hexdigest(),'wire_sha256':hashlib.sha256(wire).hexdigest(),'gzip_header':wire[:10].hex(),'headers':{k:response.headers.get(k) for k in ['Content-Length','Content-Encoding','Content-Type','ETag','Transfer-Encoding']}})
   stop(p)
   with sqlite3.connect(db) as c:
    assert c.execute('SELECT count(*) FROM messages WHERE id>?',(before,)).fetchone()[0]==8;assert c.execute('PRAGMA integrity_check').fetchone()==('ok',);assert c.execute('PRAGMA foreign_key_check').fetchall()==seed_fk
  finally:
   if p.poll() is None:stop(p)
   log.close()
for seq in range(8):
 a=(OUT/f'current-{seq}.html').read_text();b=(OUT/f'upstream-{seq}.html').read_text();(OUT/f'diff-{seq}.txt').write_text(''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='upstream',tofile='current')))
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');(OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
