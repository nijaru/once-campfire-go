package main

import (
 "bytes"
 "compress/gzip"
 "encoding/json"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "regexp"
 "runtime"
 "syscall"
 "time"
)

type result struct { App string `json:"app"`; Mode string `json:"mode"`; Round int `json:"round"`; Count int `json:"count"`; CPUUS float64 `json:"cpu_us_per_body"`; WallUS float64 `json:"wall_us_per_body"`; WireBytes int `json:"wire_bytes_per_body"` }
func cpu() float64 { var r syscall.Rusage; if err:=syscall.Getrusage(syscall.RUSAGE_SELF,&r);err!=nil{panic(err)};return float64(r.Utime.Sec+r.Stime.Sec)+float64(r.Utime.Usec+r.Stime.Usec)/1e6 }
func main(){
 runtime.GOMAXPROCS(4)
 root:=os.Args[1];bodies:=map[string][][]byte{}
 timestamp:=regexp.MustCompile(`179[0-9]{10}|2026-10-12T[0-9:.]+Z`);origin:=regexp.MustCompile(`http://127\.0\.0\.1:[0-9]+`)
 for _,app:=range []string{"current","upstream"}{
  for i:=0;i<8;i++{
   data,err:=os.ReadFile(filepath.Join(root,fmt.Sprintf("%s-%d.html",app,i)));if err!=nil{panic(err)}
   var out bytes.Buffer;w,_:=gzip.NewWriterLevel(&out,6);w.Header.OS=3;w.Write(data);w.Close()
   wire,err:=os.ReadFile(filepath.Join(root,fmt.Sprintf("%s-%d.gzip",app,i)));if err!=nil{panic(err)}
   if !bytes.Equal(wire,out.Bytes()){panic(fmt.Sprintf("wire mismatch %s%d",app,i))}
   bodies[app]=append(bodies[app],data)
   canonical:=origin.ReplaceAll(timestamp.ReplaceAll(data,[]byte("timestamp")),[]byte("http://127.0.0.1:25170"))
   if app=="current"{bodies["canonical"]=append(bodies["canonical"],canonical)}else if !bytes.Equal(canonical,bodies["canonical"][i]){panic("canonical payload mismatch")}
  }
 }
 const count=10000
 var rows []result
 for round:=1;round<=3;round++{
  order:=[]string{"current","upstream"};if round==2{order=[]string{"upstream","current"}}
  for _,app:=range order{
   for _,mode:=range []string{"finite","streaming"}{
    runtime.GC();w,_:=gzip.NewWriterLevel(nil,6)
    startCPU,startWall:=cpu(),time.Now();size:=0
    for i:=0;i<count;i++{
     var out bytes.Buffer;target:=io.Writer(&out);if mode=="streaming"{target=io.Discard}
     w.Reset(target);w.Header.OS=3
     if _,err:=w.Write(bodies[app][i%8]);err!=nil{panic(err)};if err:=w.Close();err!=nil{panic(err)}
     size+=out.Len();w.Reset(nil)
    }
    rows=append(rows,result{app,mode,round,count,(cpu()-startCPU)*1e6/count,float64(time.Since(startWall).Nanoseconds())/1e3/count,size/count})
   }
  }
 }
 json.NewEncoder(os.Stdout).Encode(map[string]any{"wire_exact_matches":16,"canonical_plain_matches":8,"settings":"Go1.27.1 darwin/arm64;level6;GOMAXPROCS4;single replay goroutine;10000 bodies per arm/mode;3 interleaved pairs;streaming target discard excludes network/buffering overhead","results":rows})
}
