"""Adapt existing audited desktop workloads; no new acceptance matrix."""
from pathlib import Path
import shutil
ROOT=Path.cwd();WORK=ROOT/'.cache/current-three-way-20261013';OLD=ROOT/'.cache/comparison-host-provenance';WORK.mkdir(exist_ok=True)
shutil.copy2(ROOT/'bench/acknowledged_writes.py',WORK/'acknowledged_writes.py')
for mode in ['http','cable']:
 text=(OLD/f'{mode}.rb').read_text()
 start=text.index('metadata = {')
 # Both archived adapters use a single literal metadata assignment.
 end=text.index('\n',start)
 text=text[:start]+"metadata = JSON.parse(File.read(File.join(root,'experiment.json')),symbolize_names:true).merge(started_at:Time.now.utc.iso8601,mode:"+("mode" if mode=='http' else "'cable'")+",images:{})"+text[end:]
 text=text.replace("localhost/campfire-publication-map-production","localhost/campfire-write-generation-production")
 text=text.replace("[%w[upstream current],%w[current upstream],%w[upstream current]]","metadata.fetch(:orders)")
 if mode=='http':
  text=text.replace("{'current'=>'/go-candidate','upstream'=>'/go-upstream'}","{'current'=>'/go-candidate','upstream'=>'/go-upstream','rust'=>'/rust-current'}")
  text=text.replace("'GOGC'=>'100')","'GOGC'=>'100','GO_CPU_PROFILE'=>'','GO_ALLOC_PROFILE'=>'','GO_PHASE_CPU'=>'')")
  old="""            if mode == 'fixed'
              expected_acks = rows.map { |r| [r.fetch('body')[/\\Abench write ([0-9]+)\\z/,1]&.to_i,r.fetch('id')] }.sort
              raise 'acknowledged IDs/population/body mismatch' unless acknowledged.length == actual && acknowledged.sort == expected_acks
              sample['acknowledged_write_audit'] = {count:actual,exact_ids:true,exact_body_sequences:true}
            end"""
  new="""            if mode == 'fixed'
              receipt_path=File.join(out,"#{app}-#{round+1}-#{name}-#{duration}.raw.json")
              sample['acknowledged_write_audit'] = JSON.parse(run('python3',File.join(root,'audit_fixed.py'),db,before.to_s,write_room.to_s,creator.to_s,receipt_path))
            else
              FileUtils.cp(audit,File.join(out,"#{app}-#{round+1}-#{duration}-acks.jsonl"))
            end"""
  assert old in text;text=text.replace(old,new)
 else:
  text=text.replace("images = {'current'=>'localhost/campfire-write-generation-production','upstream'=>'localhost/campfire-write-generation-production'}","images = {'current'=>'localhost/campfire-write-generation-production','upstream'=>'localhost/campfire-write-generation-production','rust'=>'localhost/campfire-write-generation-production'}")
  text=text.replace("(app == 'current' ? '/go-candidate' : '/go-upstream')","{'current'=>'/go-candidate','upstream'=>'/go-upstream','rust'=>'/rust-current'}.fetch(app)")
  text=text.replace("metadata[:budget][:order].each_with_index", "metadata.fetch(:orders).each_with_index")
 # Keep the existing per-response, persisted-write, delivery and presence audits.
 (WORK/f'{mode}.rb').write_text(text)
print('prepared existing HTTP/write/Cable workloads for current/upstream/Rust')
