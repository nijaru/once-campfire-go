import json,sqlite3,sys
from acknowledged_writes import verify
with sqlite3.connect(sys.argv[1]) as connection:
 with open(sys.argv[5]) as file:sample=json.load(file)
 result=verify(connection,int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]),sample)
print(json.dumps(result))
