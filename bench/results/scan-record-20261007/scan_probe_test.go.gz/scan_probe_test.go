package database

import (
	"context"
	"slices"
	"testing"
)

// Temporary allocation probe; not a proposed permanent test.
func TestScanAllocationProbe(t *testing.T) {
	d := testDB(t)
	ctx := context.Background()
	user, err := d.Setup(ctx, "User", "u@test", "digest")
	if err != nil {
		t.Fatal(err)
	}
	rooms, err := d.Rooms(ctx, user.ID)
	if err != nil {
		t.Fatal(err)
	}
	room := rooms[0].ID
	for range 100 {
		if _, err := d.CreateMessage(ctx, user.ID, room, "", "needle", "needle"); err != nil {
			t.Fatal(err)
		}
	}
	oldPage := func() ([]Message, error) {
		rows, err := d.Read.QueryContext(ctx, "SELECT id,updated_at FROM messages WHERE room_id=? ORDER BY created_at DESC LIMIT 40", room)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		var messages []Message
		for rows.Next() {
			if messages == nil {
				messages = make([]Message, 0, 40)
			}
			message := Message{RoomID: room}
			if err := rows.Scan(&message.ID, timestamp{&message.UpdatedAt}); err != nil {
				return nil, err
			}
			messages = append(messages, message)
		}
		slices.Reverse(messages)
		return messages, rows.Err()
	}
	oldSearch := func() ([]Message, error) {
		rows, err := d.Read.QueryContext(ctx, "SELECT m.id,m.room_id,m.updated_at FROM messages m JOIN message_search_index idx ON idx.rowid=m.id JOIN memberships member ON member.room_id=m.room_id WHERE member.user_id=? AND idx.body MATCH ? ORDER BY m.created_at DESC LIMIT 100", user.ID, searchTerms("needle"))
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		messages := []Message{}
		for rows.Next() {
			var m Message
			if err := rows.Scan(&m.ID, &m.RoomID, timestamp{&m.UpdatedAt}); err != nil {
				return nil, err
			}
			messages = append(messages, m)
		}
		slices.Reverse(messages)
		return messages, rows.Err()
	}
	for _, probe := range []struct {
		name  string
		count int
		load  func() ([]Message, error)
	}{
		{"page-before", 40, oldPage},
		{"page-after", 40, func() ([]Message, error) { return d.MessagePageReferences(ctx, room, 0, "around") }},
		{"search-before", 100, oldSearch},
		{"search-after", 100, func() ([]Message, error) { return d.SearchReferences(ctx, user.ID, "needle") }},
	} {
		result := testing.Benchmark(func(b *testing.B) {
			b.ReportAllocs()
			for range b.N {
				messages, err := probe.load()
				if err != nil || len(messages) != probe.count {
					b.Fatalf("count %d: %v", len(messages), err)
				}
			}
		})
		t.Log(probe.name, result.String(), result.MemString())
	}
}
