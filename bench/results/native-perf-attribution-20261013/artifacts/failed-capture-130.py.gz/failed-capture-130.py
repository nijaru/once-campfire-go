"""One independent native perf attribution pair; never latency evidence."""
import hashlib, http.cookiejar, json, os, re, shutil, socket, sqlite3, subprocess, tempfile, time, urllib.parse, urllib.request
from pathlib import Path
from acknowledged_writes import verify
WORK=Path(__file__).resolve().parent; FIXTURE=Path.home()/'.cache/campfire-post-fix-20261010'; SEED=FIXTURE/'seed'; OUT=WORK/'capture'
if os.uname().sysname!='Linux' or os.uname().machine!='x86_64':raise RuntimeError('native Linux/amd64 required')
OUT.mkdir(exist_ok=False)
IMAGE='localhost/campfire-publication-map-production:latest'
labels=json.loads((SEED/'labels.json').read_text());fixture={}
for line in (FIXTURE/'reference.env').read_text().splitlines():
 if line and not line.startswith('#'):k,v=line.split('=',1);fixture[k]=v
metadata=json.loads((WORK/'metadata.json').read_text());metadata|={'image_id':subprocess.check_output(['docker','inspect','--format','{{.Id}}',IMAGE],text=True).strip(),'seed_sha256':hashlib.sha256((SEED/'db/production.sqlite3').read_bytes()).hexdigest(),'native_binaries':{name:hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in ['current-native','upstream-native','httprate-native']},'kernel':os.uname().release,'cpu':Path('/proc/cpuinfo').read_text(),'load_before':Path('/proc/loadavg').read_text(),'affinity':{'server':'0,2,4,6','client':'8,10,12,14'},'orders':['current','upstream'],'started_unix':time.time(),'independent_perf':{'hypothesis':'Linux perf CPU-clock attribution can identify substantial actual work without Go SIGPROF stack attribution. Compare total sampled period to joined process CPU and observed Close cumulative CPU to its elapsed upper bound before trusting owners.','budget':'Exactly one sequential current/upstream pair; 2+20 seconds at 3000/s, 64 workers, 132000 exact audited writes; no frequency or rate sweep.','event':'cpu-clock','frequency':997,'callgraph':'dwarf,16384','acceptance':'Require zero lost records, resolved application/C stacks and sampled period within 20% of joined process CPU. Require Close estimate no more than 1.2 times counted elapsed. Owners need at least one CPU second before comparative interpretation. No latency/capacity claim; reject attribution if checks fail.'}}
assert metadata['seed_sha256']=='691c52bfdc30b38bd8867e93b0914613df20e03d4cd7b00796ab68e0a5d26c9a'
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
def command(*argv,**kw):return subprocess.check_output(argv,text=True,**kw)
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def ready(base,container):
 end=time.monotonic()+60
 while time.monotonic()<end:
  if command('docker','inspect','--format','{{.State.Running}}',container).strip()!='true':raise RuntimeError('server exited during startup')
  try:
   if urllib.request.urlopen(base+'/up',timeout=1).status==200:return
  except OSError:pass
  time.sleep(.1)
 raise RuntimeError('server readiness timeout')
results=[]
for app in ['current','upstream']:
 container=f'cf-native-perf-{os.getpid()}-{app}'
 with tempfile.TemporaryDirectory(prefix='cf-native-compression-',dir='/dev/shm') as td:
  data=Path(td);db=data/'production.sqlite3'
  with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
  shutil.copytree(SEED/'storage',data/'files')
  for p in [data,*data.rglob('*')]:p.chmod(p.stat().st_mode|0o666|(0o111 if p.is_dir() else 0))
  with sqlite3.connect(db) as c:
   c.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id");c.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
   seed_fk=c.execute('PRAGMA foreign_key_check').fetchall();creator=c.execute('SELECT id FROM users WHERE email_address=?',(labels['emails.david'],)).fetchone()[0]
  front,target=port(),port();base=f'http://127.0.0.1:{front}'
  config=fixture|{'DISABLE_SSL':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':'/probe/production.sqlite3','CAMPFIRE_STORAGE_PATH':'/probe','CAMPFIRE_FILES_PATH':'/probe/files','GOMAXPROCS':'4','RAILS_MAX_THREADS':'4','JOB_CONCURRENCY':'3','GOGC':'100','ATTRIBUTION_CPU_PATH':'/probe/cpu.json'}
  def start():
   args=['docker','run','-d','--name',container,'--network','host','--security-opt','label=disable','--user','0','-v',f'{data}:/probe','-v',f'{WORK}:/attribution:ro','-v',f'{WORK.parent / "campfire-native-compression-20261013"}:/binaries:ro']
   for k,v in config.items():args+=['-e',f'{k}={v}']
   args += [IMAGE,'python3','/attribution/supervise.py','taskset','-c','0,2,4,6',f'/binaries/{app}-native','server']
   command(*args);ready(base,container)
  def stop():
   command('docker','stop','--time','35',container)
   state=json.loads(command('docker','inspect',container))[0]['State']
   if state['ExitCode']!=0:raise RuntimeError('server did not shut down cleanly')
  perf=None;perf_log=None
  try:
   config['GO_CPU_PROFILE']='';config['GO_ALLOC_PROFILE']=''
   start()
   jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
   body=client.open(base+'/session/new').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else ''
   client.open(urllib.request.Request(base+'/session',data=urllib.parse.urlencode({'email_address':labels['emails.david'],'password':labels['passwords.all'],'authenticity_token':csrf}).encode(),headers={'Sec-Fetch-Site':'same-origin'})).read()
   assert any(x.name=='session_token' for x in jar);cookie='; '.join(f'{x.name}={x.value}' for x in jar)
   body=client.open(base+f'/rooms/{labels["rooms.watercooler"]}').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else '';css=re.search(r'<link[^>]*href="([^"]+\.css[^\"]*)"',body)[1]
   preflight=json.loads(command('ruby',str(FIXTURE/'bench/contracts.rb'),base,cookie,str(db),str(SEED/'labels.json'),css,str(data/'contracts')))
   stop();command('docker','rm',container);(data/'cpu.json').unlink()
   start();time.sleep(1);samples=[]
   supervisor=int(command('docker','inspect','--format','{{.State.Pid}}',container))
   children=Path(f'/proc/{supervisor}/task/{supervisor}/children').read_text().split();assert len(children)==1,children
   server=int(children[0]);assert Path(f'/proc/{server}/exe').resolve().name==f'{app}-native'
   threads=[int(p.name) for p in Path(f'/proc/{server}/task').iterdir()]
   (OUT/f'{app}-attachment.json').write_text(json.dumps({'supervisor_pid':supervisor,'server_pid':server,'existing_threads':threads,'executable':str(Path(f'/proc/{server}/exe').resolve())},indent=2)+'\n')
   perf_log=(OUT/f'{app}-perf.log').open('w')
   perf=subprocess.Popen(['perf','record','-o',str(OUT/f'{app}.perf.data'),'-e','cpu-clock','-F','997','--call-graph','dwarf,16384','-p',str(server)],stdout=perf_log,stderr=perf_log)
   time.sleep(.3);assert perf.poll() is None, 'perf failed to attach'
   assert Path(f'/proc/{server}/exe').resolve().name==f'{app}-native'
   for seconds in [2,20]:
    with sqlite3.connect(db) as c:before=c.execute('SELECT max(id) FROM messages').fetchone()[0]
    raw=command('taskset','-c','8,10,12,14',str(WORK/'httprate-native'),'--base',base,'--cookie',cookie,'--gzip','1','--conc','64','--queue','8192','--pacing','active','--rate','3000','--duration',str(seconds),'--post-room',str(labels['rooms.hq']),'--csrf',csrf)
    (OUT/f'{app}-{seconds}-receipts.json').write_text(raw);sample=json.loads(raw)
    assert sample['ok']==3000*seconds and sample['errors']==0 and sample['unscheduled']==0 and sample['invalid_responses']==0 and sample['statuses']=={'200':3000*seconds},sample
    with sqlite3.connect(db) as c:sample['write_audit']=verify(c,before,labels['rooms.hq'],creator,sample)
    sample.pop('acknowledged');sample['warmup']=seconds==2;samples.append(sample)
   perf.send_signal(2);perf_exit=perf.wait(timeout=30)
   # perf propagates an intentional SIGINT as 128+SIGINT after flushing data.
   assert perf_exit in (0,130),perf_exit
   perf_log.close();perf_log=None;perf=None
   stop();process=json.loads((data/'cpu.json').read_text());assert process['exit_code']==0
   log=command('docker','logs',container);observations=re.findall(r'GZIP_CLOSE_OBSERVATION calls=(\d+) elapsed_nanos=(\d+)',log);assert len(observations)==1,observations
   calls,nanos=map(int,observations[0]);assert calls==66000,(app,calls)
   assert not (data/'cpu.pprof').exists(), 'Go profiling must be disabled'
   command('perf','buildid-cache','--add',str(WORK/f'{app}-native'))
   with sqlite3.connect(db) as c:assert c.execute('PRAGMA integrity_check').fetchone()==('ok',);assert c.execute('PRAGMA foreign_key_check').fetchall()==seed_fk
   result={'app':app,'samples':samples,'audited_writes':66000,'gzip_close_calls':calls,'gzip_close_elapsed_nanos':nanos,'process_cpu':process,'perf_exit_code':perf_exit,'preflight':preflight['preflight'],'integrity':'ok','unchanged_seed_fk_population':len(seed_fk)}
   results.append(result);(OUT/f'{app}.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(app,'66000 audited writes;',process['cpu_seconds'],'process CPU seconds;',nanos/1e9,'summed Close elapsed seconds',flush=True)
  finally:
   if perf is not None:
    perf.send_signal(2);perf.wait(timeout=30)
   if perf_log is not None:perf_log.close()
   subprocess.run(['docker','rm','-f',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
metadata['load_after']=Path('/proc/loadavg').read_text();(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
