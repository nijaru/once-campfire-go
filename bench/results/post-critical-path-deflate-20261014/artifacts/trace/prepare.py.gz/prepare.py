"""Matched private current/upstream request tracing; production stays untouched."""
import difflib,hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path.cwd();W=ROOT/'.cache/post-critical-path-20261013';W.mkdir(exist_ok=True)
metadata={'hypothesis':'Current fixed POST tail includes additional synchronous postcommit/reader work or scheduling beyond writer hold. Attribute individually correlated complete requests, not marginal percentile subtraction or sampled Go compression shares. Earlier 811 traces and rejected FTS-order controls are historical, not this source/client cohort.','budget':'Exactly one current/upstream sequential pair,3000/s,64 workers,2 warm+8 timed seconds each;60000 exact-audited writes. No extension or uninstrumented ranking claim.','selection_gate':'All 24000 timed clients per arm must join exactly one completed task and writer regions; state partitions must reconstruct task and region durations. Select the slowest 240 individual client-service requests per arm. A source-grounded removable phase/wait averaging >=50us and >=15% handler time in the current selected tail supports a candidate mechanism; otherwise close this hypothesis without another trace sweep. Correlation is not a competitor-gap causal proof. Known rejected controls require genuinely new mechanism evidence, not renewed profile shares.','instrumentation':'Identical runtime execution trace, request tasks, writer acquire/hold and functional phase regions. Private common maintained receipt client adds correlation header and preallocated request timestamps; complete wire timestamp remains before unchanged validation. No CPU/alloc profiler, perf, periodic counters or overlapping task builds/tests/agents. Instrumentation overhead is not assumed neutral.','settings':{'GOMAXPROCS':4,'GOGC':100,'jobs':3,'server_cpus':'0,2,4,6','client_cpus':'8,10,12,14','rate':3000,'workers':64,'queue':8192,'pacing':'active','gzip':1,'warmup_seconds':2,'timed_seconds':8},'sources':{}}
for app,rev in [('current','8351224'),('upstream','c4ab53d')]:
 dest=W/app
 assert not dest.exists(),dest
 arc=W/f'{app}.tar';arc.write_bytes(subprocess.check_output(['git','archive',rev]));dest.mkdir()
 with tarfile.open(arc) as t:t.extractall(dest,filter='data')
 assets=ROOT/'assets/generated' if app=='current' else ROOT/'.cache/native-compression-work-20261012/upstream/assets/generated'
 shutil.copytree(assets,dest/'assets/generated')
 tls='reference/crates/campfire/src/integrations/testdata/tls';shutil.copytree(ROOT/tls,dest/tls)
 originals={}
 def change(file,old,new):
  p=dest/file;s=p.read_text();originals.setdefault(file,s);assert s.count(old)==1,(app,file,old);p.write_text(s.replace(old,new))
 def traced(file):
  p=dest/file;s=p.read_text()
  if '"runtime/trace"' not in s:change(file,'import (','import (\n "runtime/trace"')
 def region(file,signature,ctx,label):
  p=dest/file;s=p.read_text();a=s.index(signature);b=s.index('{',a);originals.setdefault(file,s)
  p.write_text(s[:b+1]+f'\n defer trace.StartRegion({ctx}, "{label}").End()\n'+s[b+1:]);traced(file)
 file='cmd/campfire/main.go';change(file,'func run() error {','''func run() error {
 if path := os.Getenv("GO_EXECUTION_TRACE"); path != "" {
  file, err := os.Create(path); if err != nil { return err }; defer file.Close()
  if err := trace.Start(file); err != nil { return err }; defer trace.Stop()
 }
''');traced(file)
 file='internal/front/server.go';change(file,'func forward(next http.Handler, c Config) http.Handler {\n\treturn http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {','''func forward(next http.Handler, c Config) http.Handler {
 return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
  if r.Method == "POST" && strings.HasSuffix(r.URL.Path, "/messages") {
   wall := time.Now().UnixNano()
   ctx, task := trace.NewTask(r.Context(), "http.message.create")
   if id := r.Header.Get("X-Benchmark-Request"); id != "" { trace.Log(ctx, "benchmark.ingress", id+","+strconv.FormatInt(wall,10)) }
   defer task.End(); r = r.WithContext(ctx)
  }
''');traced(file)
 file='internal/database/database.go';change(file,'\ttx, err := d.Write.BeginTx(ctx, nil)','\tacquire := trace.StartRegion(ctx,"writer.acquire")\n tx, err := d.Write.BeginTx(ctx, nil)\n acquire.End()');change(file,'\tdefer tx.Rollback()\n\tif err = fn(tx);','\thold := trace.StartRegion(ctx,"writer.hold")\n defer hold.End()\n defer tx.Rollback()\n if err = fn(tx);');traced(file)
 region('internal/web/server.go','func (s *Server) createMessage(', 'r.Context()', 'action.create')
 region('internal/web/response_cache.go','func (s *Server) beginResponseCache(', 'r.Context()', 'response.version')
 region('internal/web/response.go','func (w *responseBuffer) finish(', 'r.Context()', 'response.finish')
 region('internal/database/models.go','func (d *DB) Room(', 'ctx', 'room.read')
 if app=='current':
  region('internal/database/sessions.go','func (d *DB) AuthenticateSession(', 'ctx', 'authentication.db')
  region('internal/application/messages.go','func (s *Messages) create(', 'ctx', 'command.create')
  region('internal/application/message_queries.go','func (s *MessageQueries) Views(', 'ctx', 'presentation.views')
  region('internal/application/message_queries.go','func (s *MessageQueries) CreatedStream(', 'ctx', 'presentation.stream')
  region('internal/database/message_display.go','func (d *DB) MessageDisplays(', 'ctx', 'presentation.db')
  file='internal/application/message_effects.go';change(file,'\ts.Notifications.Created(result.Commit.Message, result.Commit.Room)','\tnotifications := trace.StartRegion(ctx,"notifications")\n s.Notifications.Created(result.Commit.Message, result.Commit.Room)\n notifications.End()');change(file,'\ts.Webhooks.Enqueue(result.Commit.Message, result.Commit.Room)','\twebhooks := trace.StartRegion(ctx,"webhooks")\n s.Webhooks.Enqueue(result.Commit.Message, result.Commit.Room)\n webhooks.End()');traced(file)
  region('internal/front/response.go','func PrepareResponse(', 'r.Context()', 'response.prepare')
 else:
  region('internal/database/models.go','func (d *DB) SessionUser(', 'ctx', 'authentication.db')
  region('internal/web/message_attributes.go','func (s *Server) saveNewMessage(', 'ctx', 'command.create')
  region('internal/web/messages.go','func (s *Server) messageViews(', 'ctx', 'presentation.views')
  region('internal/web/messages.go','func (s *Server) hydrateMessageViews(', 'ctx', 'presentation.db')
  file='internal/web/server.go';change(file,'\ts.messageCreated(m, room)','\tnotifications := trace.StartRegion(r.Context(),"notifications")\n s.messageCreated(m, room)\n notifications.End()');change(file,'\ts.enqueueWebhooks(m, room)','\twebhooks := trace.StartRegion(r.Context(),"webhooks")\n s.enqueueWebhooks(m, room)\n webhooks.End()')
 # Deflate includes its own final Close, outside response.finish on upstream.
 file='internal/front/compression.go';s=(dest/file).read_text();a=s.index('func Deflate(');b=s.index('return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {',a);originals.setdefault(file,s);b+=len('return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {');(dest/file).write_text(s[:b]+'\n defer trace.StartRegion(r.Context(), "front.deflate").End()\n'+s[b:]);traced(file)
 subprocess.check_call(['gofmt','-w',*originals],cwd=dest)
 patch=''.join(''.join(difflib.unified_diff(old.splitlines(True),(dest/file).read_text().splitlines(True),fromfile='a/'+file,tofile='b/'+file)) for file,old in sorted(originals.items()))
 (W/f'{app}.patch').write_text(patch)
 metadata['sources'][app]={'revision':subprocess.check_output(['git','rev-parse',rev],text=True).strip(),'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'overlay_sha256':hashlib.sha256(patch.encode()).hexdigest()}
shutil.copytree(ROOT/'bench/httprate',W/'client');p=W/'client/main.go';s=p.read_text()
s=s.replace('type counters struct {','type clientTrace struct {\n Sequence uint64 `json:"sequence"`\n Scheduled, Started, Finished int64\n WireBytes int64\n}\ntype counters struct {\n traces []clientTrace\n')
s=s.replace('type result struct {','type result struct {\n Traces []clientTrace `json:"request_traces"`\n')
s=s.replace('r.Header.Set("Sec-Fetch-Site", "same-origin")','r.Header.Set("Sec-Fetch-Site", "same-origin")\n r.Header.Set("X-Benchmark-Request", prefix+strconv.FormatUint(j.index,10))')
s=s.replace('s.ok++','s.traces = append(s.traces, clientTrace{j.index,j.scheduled.UnixNano(),started.UnixNano(),finished.UnixNano(),n})\n s.ok++')
s=s.replace('all.acknowledged = append(all.acknowledged, s.acknowledged...)','all.traces = append(all.traces,s.traces...)\n all.acknowledged = append(all.acknowledged, s.acknowledged...)')
s=s.replace('Acknowledged: all.acknowledged,','Traces: all.traces, Acknowledged: all.acknowledged,')
# Preallocate the finite per-worker recorder; receipt retention remains original.
s=s.replace('prefix := "rate-" + rand.Text() + "-"','prefix := "rate-" + rand.Text() + "-"\n for i := range stats { stats[i].traces = make([]clientTrace,0,int(math.Ceil(c.Rate*c.Duration.Seconds()/float64(c.Concurrency)))+64) }')
p.write_text(s);subprocess.check_call(['gofmt','-w',str(p)])
metadata['client_source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((W/'client').glob('*.go'))}
shutil.copy2(ROOT/'bench/acknowledged_writes.py',W/'acknowledged_writes.py');(W/'experiment.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Prepared private phase regions and common maintained receipt client. No production changes.')
