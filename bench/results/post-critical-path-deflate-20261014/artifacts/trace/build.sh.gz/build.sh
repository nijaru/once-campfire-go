#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
WORK="$PWD"
tar -xzf build-sources.tar.gz
# Only copied, task-owned trees; the previous kit supplies read-only TLS vectors.
for app in current upstream; do
  test -d "$HOME/.cache/campfire-native-compression-20261013/$app/reference"
  rm -rf "$WORK/$app/reference"
  cp -R "$HOME/.cache/campfire-native-compression-20261013/$app/reference" "$WORK/$app/reference"
  rm -rf "$WORK/$app/bench/httprate"
  cp -R client "$WORK/$app/bench/httprate"
  docker run --rm --user 0 --security-opt label=disable \
    -v "$WORK:/probe" \
    -v "$HOME/.cache/campfire-native-compression-20261013/go-build:/go-build" \
    localhost/campfire-publication-map-production:latest bash -c "
      set -euo pipefail
      export PATH=/usr/local/go/bin:\$PATH CGO_ENABLED=1 GOAMD64=v1 GOMAXPROCS=4 GOCACHE=/go-build
      # Test-only decoder, installed only inside this disposable build container.
      apt-get update -qq
      apt-get install -y --no-install-recommends zstd
      zstd --version
      cd /probe/$app
      go version
      go test -race -tags sqlite_fts5 ./internal/front ./bench/httprate
      go vet -tags sqlite_fts5 ./internal/front ./internal/database ./internal/web ./bench/httprate
      go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /probe/$app-native ./cmd/campfire
      if [ '$app' = current ]; then go build -trimpath -buildvcs=false -o /probe/httprate-native ./bench/httprate; fi
    "
done
sha256sum current-native upstream-native httprate-native
