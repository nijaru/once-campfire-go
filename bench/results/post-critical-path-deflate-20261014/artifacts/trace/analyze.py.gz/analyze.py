"""Stream trace events, retain request partitions, correlate exact client IDs."""
import collections,json,math,os,re,statistics,subprocess,sys
from pathlib import Path
W=Path(__file__).resolve().parent
HEADER=re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+) (.*)$')
def field(s,key):
 m=re.search(r'\b'+key+r'=(?:"([^"]*)"|([^ ]+))',s)
 return (m[1] if m[1] is not None else m[2]) if m else None

def parse(path,require_ids=True):
 tasks={};active={};states={};regions={}
 def account(g,t):
  if g in active:
   state,start=states[g];task=tasks[active[g]]
   assert t>=start
   if t>start:task['state_spans'].append([start,t,state])
  if g in states:states[g]=(states[g][0],t)
 proc=subprocess.Popen([os.environ.get('GO','go'),'tool','trace','-d=parsed',str(path)],stdout=subprocess.PIPE,text=True,bufsize=1024*1024)
 for line in proc.stdout:
  m=HEADER.match(line)
  if not m:continue
  g=int(m[3]);kind=m[4];t=int(m[5]);text=m[6]
  if kind=='StateTransition' and field(text,'GoID') is not None:
   gid=int(field(text,'GoID'));transition=re.search(r' (\w+)->(\w+)',text)
   assert transition
   # Generation snapshots do not wake a waiting goroutine or replace its stack.
   if transition[1]==transition[2]:continue
   account(gid,t);states[gid]=(transition[2],t)
  elif kind=='TaskBegin' and field(text,'Type')=='http.message.create':
   id=int(field(text,'ID'));assert g not in active
   active[g]=id;states[g]=('Running',t);tasks[id]={'begin':t,'gid':g,'state_spans':[],'region_spans':collections.defaultdict(list)}
  elif kind=='Log' and field(text,'Category')=='benchmark.ingress':
   id=int(field(text,'Task'));message=field(text,'Message')
   if id in tasks:
    key,wall=message.split(',');tasks[id]|={'request_id':key,'wall_begin':int(wall)}
  elif kind=='TaskEnd':
   id=int(field(text,'ID'))
   if id in tasks:account(tasks[id]['gid'],t);tasks[id]['end']=t;active.pop(tasks[id]['gid'])
  elif kind in ('RegionBegin','RegionEnd'):
   id=int(field(text,'Task'));name=field(text,'Type');key=(g,id,name)
   if kind=='RegionBegin':assert key not in regions;regions[key]=t
   elif key in regions:
    start=regions.pop(key)
    if id in tasks:tasks[id]['region_spans'][name].append([start,t])
 assert proc.wait()==0
 assert not active,'incomplete HTTP tasks'
 rows=list(tasks.values())
 for r in rows:
  assert 'end' in r and (not require_ids or 'request_id' in r)
  assert sum(b-a for a,b,state in r['state_spans'])==r['end']-r['begin']
  for name,spans in r['region_spans'].items():
   for a,b in spans:
    assert r['begin']<=a<=b<=r['end']
    assert sum(max(0,min(b,y)-max(a,x)) for x,y,state in r['state_spans'])==b-a
 return rows

def describe(rows):
 keys=[k for k in rows[0] if k.endswith('_ns')]
 return {'count':len(rows),'mean_us':{k[:-3]:statistics.mean(r[k] for r in rows)/1000 for k in keys},'negative_residuals':sum(r['before_ingress_ns']<0 or r['after_handler_ns']<0 for r in rows)}

def correlate(tasks,sample):
 clients=sample['request_traces'];prefix=sample['client_message_prefix'];server={r['request_id']:r for r in tasks}
 assert len(server)==len(tasks);assert len(clients)==sample['ok'];rows=[]
 for client in clients:
  r=server[prefix+str(client['sequence'])];duration=r['end']-r['begin']
  row={'sequence':client['sequence'],'client_service_ns':client['Finished']-client['Started'],'handler_ns':duration,'before_ingress_ns':r['wall_begin']-client['Started'],'after_handler_ns':client['Finished']-r['wall_begin']-duration}
  assert row['client_service_ns']==row['before_ingress_ns']+row['handler_ns']+row['after_handler_ns']
  for state in ['Running','Runnable','Waiting','Syscall']:
   row['handler_'+state+'_ns']=sum(b-a for a,b,s in r['state_spans'] if s==state)
  for name,spans in r['region_spans'].items():
   row[name+'_ns']=sum(b-a for a,b in spans)
   for state in ['Running','Runnable','Waiting','Syscall']:
    row[name+'_'+state+'_ns']=sum(max(0,min(b,y)-max(a,x)) for a,b in spans for x,y,s in r['state_spans'] if s==state)
  assert 'writer.acquire_ns' in row and 'writer.hold_ns' in row
  rows.append(row)
 assert len({r['sequence'] for r in rows})==sample['ok']
 # Keys must be common across the observed attachment-free success population.
 assert all(set(r)==set(rows[0]) for r in rows)
 tail=sorted(rows,key=lambda r:r['client_service_ns'])[-math.ceil(len(rows)*.01):]
 return rows,{'all':describe(rows),'slowest_one_percent':describe(tail)}

if __name__=='__main__':
 if len(sys.argv)>1:
  path=Path(sys.argv[1]);rows=parse(path);print('Validated',len(rows),'tasks and all state/region partitions');path.with_suffix('.partitions.json').write_text(json.dumps(rows,separators=(',',':')))
 else:
  summaries={}
  for app in ['current','upstream']:
   tasks=parse(W/'capture'/f'{app}.trace');assert len(tasks)==30000
   sample=json.loads((W/'capture'/f'{app}-8-receipts.json').read_text());assert sample['ok']==24000
   rows,summaries[app]=correlate(tasks,sample)
   (W/'capture'/f'{app}-correlated.json').write_text(json.dumps(rows,separators=(',',':')))
  (W/'capture'/'correlation-summary.json').write_text(json.dumps(summaries,indent=2)+'\n');print(json.dumps(summaries,indent=2))
