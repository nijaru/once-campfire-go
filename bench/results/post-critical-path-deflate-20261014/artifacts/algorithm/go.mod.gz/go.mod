module campfire-deflate-control

go 1.27.1

require github.com/klauspost/compress v1.20.3
