package main

import (
 "bytes"
 stdgzip "compress/gzip"
 "encoding/json"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "runtime"
 "syscall"
 "time"
 kgzip "github.com/klauspost/compress/gzip"
)
type encoder interface { Write([]byte)(int,error); Close()error; Reset(io.Writer) }
func usage() float64 { var u syscall.Rusage; if err:=syscall.Getrusage(syscall.RUSAGE_SELF,&u);err!=nil {panic(err)};return float64(u.Utime.Sec+u.Stime.Sec)+float64(u.Utime.Usec+u.Stime.Usec)/1e6 }
func main(){
 if len(os.Args)!=3 {panic("replay corpus_directory std|specialized")};dir,mode:=os.Args[1],os.Args[2]
 if mode!="std" && mode!="specialized" {panic("unknown algorithm")}
 paths,err:=filepath.Glob(filepath.Join(dir,"body-*.html"));if err!=nil || len(paths)!=256 {panic("need256 real bodies")}
 corpus:=make([][]byte,len(paths));for i,p:=range paths {corpus[i],err=os.ReadFile(p);if err!=nil{panic(err)}}
 runtime.GC();runtime.GC();var before,after runtime.MemStats;runtime.ReadMemStats(&before)
 var buf bytes.Buffer;buf.Grow(4096);var w encoder
 if mode=="std" {w,err=stdgzip.NewWriterLevel(&buf,6)} else {w,err=kgzip.NewWriterLevel(&buf,6)};if err!=nil {panic(err)}
 encode:=func(body []byte){buf.Reset();w.Reset(&buf);if mode=="std" {w.(*stdgzip.Writer).Header.OS=3} else {w.(*kgzip.Writer).Header.OS=3};if _,err:=w.Write(body);err!=nil {panic(err)};if err:=w.Close();err!=nil {panic(err)}}
 wire:=make([]int,len(paths));original:=make([]int,len(paths));totalWire,totalOriginal:=0,0
 for i,body:=range corpus{
  encode(body);wire[i]=buf.Len();totalWire+=wire[i]
  member,e:=os.ReadFile(paths[i][:len(paths[i])-5]+".gzip");if e!=nil{panic(e)};original[i]=len(member);totalOriginal+=len(member)
  if mode=="std" && !bytes.Equal(buf.Bytes(),member) {panic(fmt.Sprintf("stock member reproduction failed:%s",paths[i]))}
  reader,e:=stdgzip.NewReader(bytes.NewReader(buf.Bytes()));if e!=nil{panic(e)};plain,e:=io.ReadAll(reader);if e!=nil{panic(e)};if e=reader.Close();e!=nil{panic(e)};if !bytes.Equal(plain,body){panic("decoded bytes differ")}
 }
 runtime.GC();runtime.GC();runtime.ReadMemStats(&after)
 const n=10000;started:=time.Now();cpu:=usage();bytesOut:=0
 for i:=range n {encode(corpus[i%len(corpus)]);bytesOut+=buf.Len()}
 elapsed,used:=time.Since(started).Seconds(),usage()-cpu
 result:=map[string]any{"algorithm":mode,"go":runtime.Version(),"architecture":runtime.GOARCH,"compressions":n,"cpu_seconds":used,"wall_seconds":elapsed,"cpu_us_per_body":used*1e6/n,"encoded_bytes":bytesOut,"corpus_wire_bytes":totalWire,"original_wire_bytes":totalOriginal,"individual_wire_bytes":wire,"individual_original_wire_bytes":original,"all_independent_decodes_exact":true,"stock_member_reproduction":mode=="std","intrinsic_retained_encoder_bytes":int64(after.HeapAlloc)-int64(before.HeapAlloc)}
 runtime.KeepAlive(w);runtime.KeepAlive(buf);runtime.KeepAlive(corpus)
 if err:=json.NewEncoder(os.Stdout).Encode(result);err!=nil {panic(err)}
}
