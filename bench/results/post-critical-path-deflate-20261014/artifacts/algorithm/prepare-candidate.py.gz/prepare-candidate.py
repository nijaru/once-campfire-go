import difflib,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
R=Path.cwd();W=R/'.cache/deflate-algorithm-20261014';D=W/'source';assert not D.exists();D.mkdir()
archive=W/'production.tar';archive.write_bytes(subprocess.check_output(['git','archive','8351224']))
with tarfile.open(archive) as t:t.extractall(D,filter='data')
shutil.copytree(R/'assets/generated',D/'assets/generated')
files=['internal/front/compression.go','internal/front/gzip_cache.go','internal/front/public_compression.go']
backup=W/'baseline';backup.mkdir()
for file in files:
 p=D/file;(backup/file).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,backup/file);old=p.read_text();assert old.count('"compress/gzip"')==1;p.write_text(old.replace('"compress/gzip"','"github.com/klauspost/compress/gzip"'))
for file in ['go.mod','go.sum']:shutil.copy2(D/file,backup/file)
# Match assets and contracts; read reference vectors without editing them.
(D/'reference').rmdir();(D/'reference').symlink_to('../../../reference',target_is_directory=True)
subprocess.check_call(['/Users/nick/.local/share/mise/installs/go/1.27.1/bin/go','mod','edit','-require=github.com/klauspost/compress@v1.20.3'],cwd=D)
patch=''.join(''.join(difflib.unified_diff((backup/file).read_text().splitlines(True),(D/file).read_text().splitlines(True),fromfile='a/'+file,tofile='b/'+file)) for file in files+['go.mod'])
(W/'candidate.patch').write_text(patch);print('Private candidate changes only the three front compressor imports and direct module requirement; pool/cache/writer lifecycle unchanged.')
