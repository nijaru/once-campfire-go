#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
WORK="$PWD"
docker run --rm --user 0 --security-opt label=disable \
 -v "$WORK:/probe" \
 -v "$HOME/.cache/campfire-native-compression-20261013/go-build:/go-build" \
 localhost/campfire-publication-map-production:latest bash -c '
 set -euo pipefail
 export PATH=/usr/local/go/bin:$PATH CGO_ENABLED=1 GOAMD64=v1 GOMAXPROCS=4 GOCACHE=/go-build
 cd /probe
 go version
 go mod tidy
 go test -race ./client
 go vet ./client
 go build -trimpath -buildvcs=false -o httprate-native ./client
 go build -trimpath -buildvcs=false -o replay-native .
 go version -m replay-native
 '
sha256sum httprate-native replay-native go.mod go.sum
