#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
W="$PWD"
tar -xzf candidate-sources.tar.gz
# Preserve the exact original embedded tree, including existing AppleDouble files.
# COPYFILE_DISABLE avoids manufacturing new resource forks but is not a baseline change.
rm -rf source/assets/generated
cp -R "$HOME/.cache/campfire-display-projection-20261013/source/assets/generated" source/assets/generated
for dir in internal/presentation/templates internal/web/pwa; do
  rm -rf "source/$dir"
  cp -R "$HOME/.cache/campfire-display-projection-20261013/source/$dir" "source/$dir"
done
# Native test-only TLS fixtures, not a source change.
rm -rf source/reference
cp -R "$HOME/.cache/campfire-native-compression-20261013/current/reference" source/reference
tar -xzf reference-test-fixtures.tar.gz -C source
mkdir -p candidate
for file in internal/front/compression.go internal/front/gzip_cache.go internal/front/public_compression.go go.mod go.sum; do mkdir -p "candidate/$(dirname "$file")"; cp "source/$file" "candidate/$file"; done
if [ ! -f httprate-corpus-native ]; then mv httprate-native httprate-corpus-native; fi
for arm in current candidate; do
 from=baseline; [ "$arm" = current ] || from=candidate
 for file in internal/front/compression.go internal/front/gzip_cache.go internal/front/public_compression.go go.mod go.sum; do cp "$from/$file" "source/$file"; done
 docker run --rm --user 0 --security-opt label=disable \
  -v "$W:/probe" -v "$HOME/.cache/campfire-native-compression-20261013/go-build:/go-build" \
  localhost/campfire-publication-map-production:latest bash -c "
  set -euo pipefail
  export PATH=/usr/local/go/bin:\$PATH CGO_ENABLED=1 GOAMD64=v1 GOMAXPROCS=4 GOCACHE=/go-build
  cd /probe/source
  if [ '$arm' = candidate ]; then
    go mod download github.com/klauspost/compress
    apt-get update -qq && apt-get install -y --no-install-recommends zstd
    go test -race -tags sqlite_fts5 ./internal/front ./internal/web
    go vet -tags sqlite_fts5 ./internal/front ./internal/web
  fi
  go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /probe/$arm-native ./cmd/campfire
  "
done
ln -sfn "$HOME/.cache/campfire-three-way-20261013/httprate" httprate-native
sha256sum current-native candidate-native httprate-native httprate-corpus-native
# Failed baseline reproduction closes the setup before any application posting.
[ "$(sha256sum current-native | cut -d' ' -f1)" = 8a1409c09aa79e188010fb04dfa0c63b66e4f2748de734a117f6ae5db49b0e29 ]
[ "$(sha256sum httprate-native | cut -d' ' -f1)" = 4f8848e2a52927660d6aa031fa38c16b7f7e7cd500cf1c8aee7e3f245b73b1f9 ]
