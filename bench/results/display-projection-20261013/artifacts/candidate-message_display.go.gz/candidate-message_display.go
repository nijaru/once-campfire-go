package database

import (
	"context"
	"database/sql"
	"encoding/json"
	"strings"
	"time"
)

// UserDisplay contains presentation dependencies, never credentials or authority.
type UserDisplay struct {
	ID        int64
	Name, Bio string
	UpdatedAt time.Time
}

func (u UserDisplay) Title() string {
	parts := []string{}
	for _, value := range []string{u.Name, u.Bio} {
		if strings.TrimSpace(value) != "" {
			parts = append(parts, value)
		}
	}
	return strings.Join(parts, " – ")
}

type MessageDisplay struct {
	Message      Message
	Author       *UserDisplay
	Room         Room
	Participants []RoomParticipant
	Boosts       []Boost
	Attachment   *Blob
}

// MessageDisplays materializes associations in a short read snapshot. The caller
// supplies owned records (including commit receipts); no rendering or IO holds the
// connection. Each relationship is loaded separately to avoid multiplied rows.
// Authors belong to their message; the separate user map contains only mentions.
func (d *DB) MessageDisplays(ctx context.Context, records []Message, mentioned []int64) (map[int64]MessageDisplay, map[int64]UserDisplay, error) {
	result := make(map[int64]MessageDisplay, len(records))
	users := make(map[int64]UserDisplay)
	if len(records) == 0 {
		return result, users, nil
	}
	tx, err := d.Read.BeginTx(ctx, &sql.TxOptions{ReadOnly: true})
	if err != nil {
		return nil, nil, err
	}
	defer tx.Rollback()
	result, users, err = messageDisplays(ctx, tx, records, mentioned)
	if err != nil {
		return nil, nil, err
	}
	if err = tx.Commit(); err != nil {
		return nil, nil, err
	}
	return result, users, nil
}

func messageDisplays(ctx context.Context, tx *sql.Tx, records []Message, mentioned []int64) (map[int64]MessageDisplay, map[int64]UserDisplay, error) {
	result := make(map[int64]MessageDisplay, len(records))
	projections := make([][3]int64, 0, len(records))
	for _, record := range records {
		projections = append(projections, [3]int64{record.ID, record.RoomID, record.CreatorID})
		result[record.ID] = MessageDisplay{Message: record}
	}
	if len(records) == 0 {
		return result, map[int64]UserDisplay{}, nil
	}
	raw, _ := json.Marshal(projections)
	// Each joined relationship has at most one row. The attachment subquery skips
	// dangling blob edges and chooses the lowest attachment ID, as before.
	rows, err := tx.QueryContext(ctx, `SELECT selected.value->>0,
 r.id,r.creator_id,coalesce(r.name,''),r.type,r.updated_at,
 u.id,CASE WHEN u.id IS NULL THEN '' ELSE u.name END,coalesce(u.bio,''),u.updated_at,
 b.id,CASE WHEN b.id IS NULL THEN '' ELSE b.key END,
 CASE WHEN b.id IS NULL THEN '' ELSE b.filename END,b.content_type,b.metadata,
 CASE WHEN b.id IS NULL THEN '' ELSE b.service_name END,
 CASE WHEN b.id IS NULL THEN 0 ELSE b.byte_size END,b.checksum,
 CASE WHEN b.id IS NULL THEN '' ELSE b.created_at END
 FROM json_each(?) selected
 JOIN rooms r ON r.id=selected.value->>1
 LEFT JOIN users u ON u.id=selected.value->>2
 LEFT JOIN active_storage_blobs b ON b.id=(
 SELECT b2.id FROM active_storage_attachments a2 JOIN active_storage_blobs b2 ON b2.id=a2.blob_id
 WHERE u.id IS NOT NULL AND a2.record_type='Message' AND a2.name='attachment'
 AND a2.record_id=selected.value->>0 ORDER BY a2.id LIMIT 1)`, string(raw))
	if err != nil {
		return nil, nil, err
	}
	valid, found, directs := map[int64]bool{}, map[int64]bool{}, map[int64]bool{}
	for rows.Next() {
		var id int64
		var room Room
		var author UserDisplay
		var blob Blob
		var authorID, blobID sql.NullInt64
		var authorUpdated any
		var metadata, checksum sql.NullString
		err = rows.Scan(&id, &room.ID, &room.CreatorID, &room.Name, &room.Type, timestamp{&room.UpdatedAt},
			&authorID, &author.Name, &author.Bio, &authorUpdated,
			&blobID, &blob.Key, &blob.Filename, &blob.ContentType, &metadata, &blob.ServiceName, &blob.ByteSize, &checksum, &blob.CreatedAt)
		if err != nil {
			rows.Close()
			return nil, nil, err
		}
		data := result[id]
		data.Room = room
		if authorID.Valid {
			if err = (timestamp{&author.UpdatedAt}).Scan(authorUpdated); err != nil {
				rows.Close()
				return nil, nil, err
			}
			author.ID = authorID.Int64
			data.Author = &author
			valid[id] = true
		}
		if blobID.Valid {
			blob.ID = blobID.Int64
			blob.Metadata = json.RawMessage(metadata.String)
			if !json.Valid(blob.Metadata) {
				blob.Metadata = json.RawMessage("{}")
			}
			blob.Checksum = checksum.String
			data.Attachment = &blob
		}
		if room.Type == "Rooms::Direct" {
			directs[room.ID] = true
		}
		result[id] = data
		found[id] = true
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return nil, nil, err
	}
	for _, record := range records {
		if !found[record.ID] {
			return nil, nil, sql.ErrNoRows
		}
	}
	participants, err := messageParticipants(ctx, tx, directs)
	if err != nil {
		return nil, nil, err
	}
	boosts, err := messageBoosts(ctx, tx, valid)
	if err != nil {
		return nil, nil, err
	}
	for id, data := range result {
		data.Participants = participants[data.Room.ID]
		data.Boosts = boosts[id]
		result[id] = data
	}
	ids := make(map[int64]bool, len(mentioned))
	for _, id := range mentioned {
		ids[id] = true
	}
	users, err := userDisplays(ctx, tx, ids)
	if err != nil {
		return nil, nil, err
	}
	return result, users, nil
}

func displayIDs(ids map[int64]bool) string {
	list := make([]int64, 0, len(ids))
	for id := range ids {
		list = append(list, id)
	}
	raw, _ := json.Marshal(list) // int64 slices cannot fail JSON encoding.
	return string(raw)
}

func messageParticipants(ctx context.Context, tx *sql.Tx, ids map[int64]bool) (map[int64][]RoomParticipant, error) {
	participants := make(map[int64][]RoomParticipant)
	if len(ids) == 0 {
		return participants, nil
	}
	rows, err := tx.QueryContext(ctx, "SELECT m.room_id,u.id,u.name,u.updated_at FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.room_id IN (SELECT value FROM json_each(?)) ORDER BY m.room_id,m.user_id", displayIDs(ids))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var room int64
		var u RoomParticipant
		if err = rows.Scan(&room, &u.ID, &u.Name, timestamp{&u.UpdatedAt}); err != nil {
			return nil, err
		}
		participants[room] = append(participants[room], u)
	}
	return participants, rows.Err()
}

func messageBoosts(ctx context.Context, tx *sql.Tx, ids map[int64]bool) (map[int64][]Boost, error) {
	if len(ids) == 0 {
		return map[int64][]Boost{}, nil
	}
	rows, err := tx.QueryContext(ctx, "SELECT b.id,b.message_id,b.booster_id,b.content,u.name,coalesce(u.bio,''),u.updated_at,b.created_at,b.updated_at FROM boosts b JOIN users u ON u.id=b.booster_id WHERE b.message_id IN (SELECT value FROM json_each(?)) ORDER BY b.created_at", displayIDs(ids))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := make(map[int64][]Boost, len(ids))
	for rows.Next() {
		var b Boost
		var bio string
		if err = rows.Scan(&b.ID, &b.MessageID, &b.BoosterID, &b.Content, &b.Booster, &bio, timestamp{&b.BoosterUpdatedAt}, timestamp{&b.CreatedAt}, timestamp{&b.UpdatedAt}); err != nil {
			return nil, err
		}
		b.BoosterTitle = (UserDisplay{Name: b.Booster, Bio: bio}).Title()
		result[b.MessageID] = append(result[b.MessageID], b)
	}
	return result, rows.Err()
}
