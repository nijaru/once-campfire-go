import hashlib,http.cookiejar,json,os,re,shutil,signal,socket,sqlite3,subprocess,sys,tempfile,time,urllib.parse,urllib.request
from pathlib import Path
ROOT=Path.cwd();WORK=ROOT/'.cache/compression-policy-20261012';OLD=ROOT/'.cache/local-post-work-20261011';SEED=ROOT/'.cache/parity-seeds/default';OUT=WORK/'client-integration-rust-corrected';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'bench'));from acknowledged_writes import verify
labels=json.loads((SEED/'labels.json').read_text());fixture={}
for line in (ROOT/'.cache/shared-current/reference.env').read_text().splitlines():
 if line and not line.startswith('#'):k,v=line.split('=',1);fixture[k]=v
results=[]
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
for app in ['rust']:
 with tempfile.TemporaryDirectory(prefix='client-integration-',dir=WORK) as td:
  d=Path(td);db=d/'production.sqlite3'
  with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
  shutil.copytree(SEED/'storage',d/'files')
  with sqlite3.connect(db) as c:
   c.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id");c.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
   seed_fk=c.execute('PRAGMA foreign_key_check').fetchall();creator=c.execute('SELECT id FROM users WHERE email_address=?',(labels['emails.david'],)).fetchone()[0]
  front,target=port(),port();base=f'http://127.0.0.1:{front}';container=f'cf-client-integration-{os.getpid()}'
  config=fixture|{'DISABLE_SSL':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(d),'CAMPFIRE_FILES_PATH':str(d/'files'),'GOMAXPROCS':'4','TOKIO_WORKER_THREADS':'4','JOB_CONCURRENCY':'3'}
  if app=='go':argv=[str(OLD/'current'),'server'];env=os.environ|config
  else:
   config|={'CAMPFIRE_DATABASE_PATH':'/probe/production.sqlite3','CAMPFIRE_STORAGE_PATH':'/probe','CAMPFIRE_FILES_PATH':'/probe/files'}
   argv=['docker','run','--rm','--name',container,'-p',f'{front}:{front}','-v',f'{d}:/probe','-v',f'{ROOT/"bench"}:/verify:ro']
   for k,v in config.items():argv+=['-e',f'{k}={v}']
   argv+=['campfire-local-generation-checks:latest','/rust-current','server'];env=os.environ
  log=(OUT/f'{app}.log').open('w');p=subprocess.Popen(argv,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  try:
   end=time.monotonic()+60
   while True:
    if p.poll() is not None:raise RuntimeError(f'{app} exited')
    try:
     if urllib.request.urlopen(base+'/up',timeout=1).status==200:break
    except OSError:pass
    if time.monotonic()>end:raise RuntimeError('not ready')
    time.sleep(.1)
   jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
   body=client.open(base+'/session/new').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else ''
   client.open(urllib.request.Request(base+'/session',data=urllib.parse.urlencode({'email_address':labels['emails.david'],'password':labels['passwords.all'],'authenticity_token':csrf}).encode(),headers={'Sec-Fetch-Site':'same-origin'})).read()
   assert any(x.name=='session_token' for x in jar);cookie='; '.join(f'{x.name}={x.value}' for x in jar)
   body=client.open(base+f'/rooms/{labels["rooms.watercooler"]}').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else ''
   for coding in [0,1]:
    before=int(subprocess.check_output(['docker','exec',container,'python3','-c',"import sqlite3; print(sqlite3.connect('/probe/production.sqlite3').execute('SELECT max(id) FROM messages').fetchone()[0])"],text=True))
    raw=subprocess.check_output([str(WORK/'httprate-maintained'),'--base',base,'--cookie',cookie,'--gzip',str(coding),'--conc','2','--rate','8','--duration','1','--post-room',str(labels['rooms.hq']),'--csrf',csrf],text=True)
    sample=json.loads(raw);(OUT/f'{app}-gzip{coding}.json').write_text(raw)
    assert sample['errors']==0 and sample['ok']==8 and sample['unscheduled']==0 and sample['invalid_responses']==0,sample
    command="import json,sqlite3,sys; sys.path.insert(0,'/verify'); from acknowledged_writes import verify; sample=json.load(sys.stdin); db=sqlite3.connect('/probe/production.sqlite3'); print(json.dumps(verify(db,"+str(before)+","+str(labels['rooms.hq'])+","+str(creator)+",sample)))"
    try:sample['write_audit']=json.loads(subprocess.check_output(['docker','exec','-i',container,'python3','-c',command],input=json.dumps(sample),text=True))
    except Exception:
     debug=subprocess.check_output(['docker','exec',container,'python3','-c',"import json,sqlite3; c=sqlite3.connect('/probe/production.sqlite3'); print(json.dumps(c.execute('SELECT m.id,m.room_id,m.creator_id,m.client_message_id,rt.body,idx.body FROM messages m LEFT JOIN action_text_rich_texts rt ON rt.record_type=\"Message\" AND rt.record_id=m.id AND rt.name=\"body\" LEFT JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>"+str(before)+"').fetchall()))"],text=True)
     (OUT/'audit-failure.json').write_text(debug);raise
    sample['app']=app;results.append(sample)
   if app=='go':p.send_signal(signal.SIGTERM)
   else:subprocess.check_call(['docker','stop','--time','30',container],stdout=subprocess.DEVNULL)
   p.wait(timeout=35);assert p.returncode==0
   with sqlite3.connect(db) as c:assert c.execute('PRAGMA integrity_check').fetchone()==('ok',);assert c.execute('PRAGMA foreign_key_check').fetchall()==seed_fk
  finally:
   if p.poll() is None:
    if app=='go':p.send_signal(signal.SIGTERM)
    else:subprocess.run(['docker','stop','--time','30',container],stdout=subprocess.DEVNULL)
    p.wait(timeout=35)
   log.close()
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n');print([(r['app'],r['gzip'],r['ok'],r['write_audit']) for r in results])
