package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"runtime/pprof"
	"syscall"
	"time"
)

type sample struct {
	Level  int     `json:"level"`
	Round  int     `json:"round"`
	Count  int     `json:"count"`
	CPUUS  float64 `json:"cpu_us_per_body"`
	WallUS float64 `json:"wall_us_per_body"`
}

type bodyResult struct {
	Name   string `json:"name"`
	SHA256 string `json:"sha256"`
	Plain  int    `json:"plain_bytes"`
	Level6 int    `json:"level6_bytes"`
	Level3 int    `json:"level3_bytes"`
}

func cpu() float64 {
	var r syscall.Rusage
	if err := syscall.Getrusage(syscall.RUSAGE_SELF, &r); err != nil {
		panic(err)
	}
	return float64(r.Utime.Sec+r.Stime.Sec) + float64(r.Utime.Usec+r.Stime.Usec)/1e6
}

func compress(w *gzip.Writer, data []byte) []byte {
	var out bytes.Buffer
	w.Reset(&out)
	w.Header.OS = 3
	if _, err := w.Write(data); err != nil {
		panic(err)
	}
	if err := w.Close(); err != nil {
		panic(err)
	}
	w.Reset(nil)
	return out.Bytes()
}

func main() {
	runtime.GOMAXPROCS(4)
	var bodies [][]byte
	var names []string
	for _, app := range []string{"current", "upstream"} {
		for seq := 0; seq < 8; seq++ {
			name := fmt.Sprintf("%s-%d", app, seq)
			body, err := os.ReadFile(filepath.Join(os.Args[1], name+".html"))
			if err != nil {
				panic(err)
			}
			bodies = append(bodies, body)
			names = append(names, name)
			// Match the fixed-load namespace shape without changing application data:
			// rand.Text is 26 base32 characters, followed by a numeric sequence.
			marker := fmt.Sprintf("compression-probe-%d", seq)
			loadMarker := fmt.Sprintf("rate-JBSWY3DPEHPK3PXPQZV4MTN2K7-%d", 20000+seq)
			derived := bytes.ReplaceAll(body, []byte(marker), []byte(loadMarker))
			derived = bytes.ReplaceAll(derived, []byte(fmt.Sprintf("bench write %d", seq)), []byte(fmt.Sprintf("bench write %d", 20000+seq)))
			bodies = append(bodies, derived)
			names = append(names, name+"-load-shaped")
		}
	}
	writers := map[int]*gzip.Writer{}
	for _, level := range []int{6, 3} {
		writers[level], _ = gzip.NewWriterLevel(nil, level)
	}
	var bodyResults []bodyResult
	for i, data := range bodies {
		sizes := map[int]int{}
		for _, level := range []int{6, 3} {
			encoded := compress(writers[level], data)
			sizes[level] = len(encoded)
			reader, err := gzip.NewReader(bytes.NewReader(encoded))
			if err != nil {
				panic(err)
			}
			plain, err := io.ReadAll(reader)
			if err != nil {
				panic(err)
			}
			if err := reader.Close(); err != nil {
				panic(err)
			}
			if !bytes.Equal(plain, data) {
				panic("changed decoded bytes")
			}
		}
		digest := sha256.Sum256(data)
		bodyResults = append(bodyResults, bodyResult{names[i], fmt.Sprintf("%x", digest), len(data), sizes[6], sizes[3]})
	}

	file, err := os.Create(os.Args[2])
	if err != nil {
		panic(err)
	}
	if err := pprof.StartCPUProfile(file); err != nil {
		panic(err)
	}
	startCPU, startWall := cpu(), time.Now()
	const count = 60000
	for i := 0; i < count; i++ {
		compress(writers[6], bodies[i%len(bodies)])
	}
	elapsedCPU, elapsedWall := cpu()-startCPU, time.Since(startWall).Seconds()
	pprof.StopCPUProfile()
	file.Close()
	json.NewEncoder(os.Stdout).Encode(map[string]any{"budget": "One standalone pure-Go level6 calibration;60000 compressions on the same32 captured/derived bodies;process CPU measured inside profile window;no app or native claim.", "count": count, "cpu_seconds": elapsedCPU, "wall_seconds": elapsedWall, "bodies": bodyResults})
}
