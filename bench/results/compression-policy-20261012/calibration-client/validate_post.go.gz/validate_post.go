package main

// Temporary extension of the existing offered-rate client; records exact POST
// acknowledgment IDs for independent SQLite audits outside the timed interval.
import (
	"bytes"
	"compress/gzip"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

var postIDs = regexp.MustCompile(`data-message-id="([0-9]+)"`)

func validatePost(response *http.Response, body []byte, seq uint64) (uint64, error) {
	if !strings.HasPrefix(response.Header.Get("Content-Type"), "text/vnd.turbo-stream.html") {
		return 0, fmt.Errorf("wrong content type")
	}
	switch response.Header.Get("Content-Encoding") {
	case "gzip":
		gz, err := gzip.NewReader(bytes.NewReader(body))
		if err != nil {
			return 0, err
		}
		body, err = io.ReadAll(gz)
		closeErr := gz.Close()
		if err != nil {
			return 0, err
		}
		if closeErr != nil {
			return 0, closeErr
		}
	case "", "identity":
	default:
		return 0, fmt.Errorf("unexpected content encoding")
	}
	text := string(body)
	ids := postIDs.FindAllStringSubmatch(text, -1)
	if !strings.HasPrefix(text, "<turbo-stream") || !strings.HasSuffix(strings.TrimSpace(text), "</turbo-stream>") || !strings.Contains(text, "<template>") || !strings.Contains(text, "</template>") || !strings.Contains(text, "bench write "+strconv.FormatUint(seq, 10)) || len(ids) != 1 {
		return 0, fmt.Errorf("incomplete or mismatched post")
	}
	id, err := strconv.ParseUint(ids[0][1], 10, 64)
	if err != nil || id == 0 {
		return 0, fmt.Errorf("invalid message ID")
	}
	return id, nil
}
