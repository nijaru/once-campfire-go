# Offline validation only. Never starts an application or a load generator.
require_relative '../pr-ready/comparison-verification/bench/comparison_support'
require 'digest'
require 'time'
include BenchmarkSupport
root = Dir.pwd
out = File.join(root,'.cache/cable-progress-20261011/capture')
seed = '/dev/shm/campfire-pr-ready/seed'
db = '/dev/shm/campfire-pr-ready/distinct-fanout-runtime/587611/current-1/db/production.sqlite3'
labels = JSON.parse(File.read(File.join(seed,'labels.json')))
room = Integer(labels.fetch('rooms.watercooler'))
sql = ->(path,q) { text=run('sqlite3','-readonly','-cmd','.timeout 10000','-json',path,q); text.strip.empty? ? [] : JSON.parse(text) }
initial = sql.call(File.join(seed,'db/production.sqlite3'),'SELECT MAX(id) id FROM messages').first.fetch('id')
raw = File.join(out,'current-1.raw.json')
sample = JSON.parse(File.read(raw))
run('ruby',File.join(root,'.cache/shared-verification-current/bench/check_sample.rb'),'cable',input:File.read(raw))
raise 'not distinct sessions' unless sample.fetch('clients') == 64 && sample.fetch('session_rows') == 64 && sample.fetch('distinct_session_cookies') == 64
people = sql.call(db,"SELECT COUNT(DISTINCT s.user_id) n FROM sessions s JOIN users u ON u.id=s.user_id WHERE u.email_address LIKE 'fanout-%@example.test'").first.fetch('n')
raise 'not distinct people' unless people == 64
posted = sample.fetch('latency').fetch('post_successes') + sample.fetch('throughput').fetch('posted')
david = labels.fetch('emails.david').gsub("'","''")
creator = sql.call(db,"SELECT id FROM users WHERE email_address='#{david}'").first.fetch('id')
records = sql.call(db,"SELECT m.id,m.creator_id,m.room_id,rt.body,idx.body indexed_body FROM messages m LEFT JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' LEFT JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>#{initial}")
actual = sql.call(db,"SELECT COUNT(*) n FROM messages WHERE id>#{initial}").first.fetch('n')
seqs = records.map { |r| r.fetch('body').match(/\Afanout bmk([0-9]+)z\z/)&.[](1)&.to_i }
# Prove the original diagnostic typo fails, without changing the population.
wrong = records.map { |r| r.fetch('body').match(/\\Afanout bmk([0-9]+)z\\z/)&.[](1)&.to_i }
raise 'original typo unexpectedly accepted' unless wrong.all?(&:nil?)
raise 'persisted marked writes differ' unless actual == posted && seqs.compact.sort == (1..posted).to_a && records.length == posted
raise 'wrong body, creator, room or FTS body' unless records.all? { |r| r.fetch('creator_id') == creator && r.fetch('room_id') == room && r.fetch('indexed_body') == r.fetch('body') }
acknowledged = sample.delete('acknowledged')
expected_acks = records.zip(seqs).map { |r,s| [s,r.fetch('id')] }.sort
raise 'ack IDs differ' unless acknowledged.length == posted && acknowledged.sort == expected_acks
indexed = sql.call(db,"SELECT COUNT(*) n FROM message_search_index WHERE rowid>#{initial} AND body MATCH 'fanout'").first.fetch('n')
raise 'missing FTS writes' unless indexed == posted
raise 'database integrity' unless sql.call(db,'PRAGMA integrity_check;').first.values == ['ok']
seed_foreign_keys = sql.call(File.join(seed,'db/production.sqlite3'),'PRAGMA foreign_key_check;')
run_foreign_keys = sql.call(db,'PRAGMA foreign_key_check;')
raise 'new foreign key violations' unless run_foreign_keys == seed_foreign_keys
presence = sql.call(db,"SELECT SUM(m.connections) n FROM memberships m JOIN users u ON u.id=m.user_id WHERE u.email_address LIKE 'fanout-%@example.test' AND m.room_id=#{room}").first.fetch('n')
raise 'presence not released' unless presence == 0
sample['verified_distinct_people'] = people
sample['write_audit'] = {persisted: actual, exact_unique_markers: true, exact_bodies: true, creator_room: true, acknowledged_ids: true, indexed: indexed, exact_indexed_bodies: true, integrity: 'ok', foreign_keys: {unchanged_seed_violations: seed_foreign_keys.length, added_violations: 0}, presence_after_disconnect: presence, recovered_offline: true}
row = {app:'current', round:1, cable:sample}
write_json(File.join(out,'current-1.json'),row)
write_json(File.join(out,'results.json'),[row])
metadata = JSON.parse(File.read(File.join(out,'metadata-before-audit-recovery.json')))
metadata['timed_attempts'] = 1
metadata['completed_attempts'] = 1
metadata['captured_below_threshold'] = sample.dig('throughput','delivered_msgs_per_sec') < 1000
metadata['audit_recovery'] = {initial_failure:'overescaped anchored Ruby regex; all matches nil', original_regex_rejected_same_population:true, raw_stdout_sha256:Digest::SHA256.file(raw).hexdigest, database_sha256:Digest::SHA256.file(db).hexdigest, recovery_time:Time.now.utc.iso8601, workload_rerun:false}
write_json(File.join(out,'metadata.json'),metadata)
puts "PASS offline: #{actual} exact acknowledged writes/body/creator/room/FTS, integrity/no added foreign-key violations (1 seed orphan retained), 64 distinct people, all-client delivery and presence 0; #{sample.dig('throughput','delivered_msgs_per_sec')}/s; no workload rerun"
