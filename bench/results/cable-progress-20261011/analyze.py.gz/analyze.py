import json
from pathlib import Path
root=Path(__file__).parent
rows=json.loads((root/'capture/current-1.progress.json').read_text())
samples=[r for r in rows if 'client' in r]
a,b=samples[0],samples[-1]
seconds=(b['client']['elapsed_ns']-a['client']['elapsed_ns'])/1e9
stage={}
for name in a['server']['stages']:
    first,last=a['server']['stages'][name],b['server']['stages'][name]
    active=[r['server']['stages'][name]['started']-r['server']['stages'][name]['completed'] for r in samples]
    stage[name]={
        'completed_delta':last['completed']-first['completed'],
        'completed_per_second':(last['completed']-first['completed'])/seconds,
        'elapsed_sum_delta_ns':last['elapsed_ns']-first['elapsed_ns'],
        'sampled_started_minus_completed_min':min(active),
        'sampled_started_minus_completed_max':max(active),
    }
rate=[(x['client']['complete']-y['client']['complete'])/((x['client']['elapsed_ns']-y['client']['elapsed_ns'])/1e9) for y,x in zip(samples,samples[1:])]
result={
 'interpretation':'Instrumented low-throughput phase is posted-rate limited, not a growing delivery/queue backlog; root cause and instrumentation cost remain unmeasured. No further workload run after first sub-1000/s attempt.',
 'window_seconds':seconds,
 'client_progress_samples':len(samples),
 'sampler_errors':sum('sampler_error' in r for r in rows),
 'complete_progress_rates_per_second':rate,
 'complete_progress_rate_min':min(rate),
 'complete_progress_rate_max':max(rate),
 'stages':stage,
 'cpu_cores_from_process_ticks':{who:(b['proc'][who]['cpu_ticks']-a['proc'][who]['cpu_ticks'])/100/seconds for who in ['server','client']},
 'server_cgroup_cpu_unavailable':all(r['proc']['server']['cgroup_cpu'] is None for r in samples),
 'client_cgroup_cpu_throttled_delta':b['proc']['client']['cgroup_cpu']['nr_throttled']-a['proc']['client']['cgroup_cpu']['nr_throttled'],
 'client_cgroup_includes_runner':True,
 'queue_enqueued_minus_dequeued_aggregate_max':max(sum(s['enqueued']-s['dequeued'] for s in r['server']['sockets']) for r in samples),
 'queue_enqueued_minus_dequeued_per_socket_max':max(s['enqueued']-s['dequeued'] for r in samples for s in r['server']['sockets']),
 'socket_write_started_minus_completed_aggregate_max':max(sum(s['write']['started']-s['write']['completed'] for s in r['server']['sockets']) for r in samples),
 'client_posted_minus_complete_max':max(r['client']['posted']-r['client']['complete'] for r in samples),
 'client_posted_minus_complete_min':min(r['client']['posted']-r['client']['complete'] for r in samples),
 'client_to_observer_lag_ms_max':max((r['received_unix_ns']-r['client']['unix_ns'])/1e6 for r in samples),
 'proc_observation_ms_max':max(r['proc']['observation_ns']/1e6 for r in rows),
 'snapshot_ms_max':max((r['server']['end_unix_ns']-r['server']['start_unix_ns'])/1e6 for r in rows),
 'queue_full_total':sum(s['full'] for s in rows[-1]['server']['sockets']),
 'socket_write_errors_total':sum(s['write']['errors'] for s in rows[-1]['server']['sockets']),
 'auth_rejected_total':rows[-1]['server']['auth_rejected'],
 'socket_slots':len(rows[-1]['server']['sockets']),
 'nonlinearized_fields':True,
 'duration_sums_are_not_wall_stalls':True,
 'per_request_http_flush_correlations_available':False,
}
(root/'capture/summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
