#!/usr/bin/env bash
set -euo pipefail
W="$HOME/.cache/campfire-sqlite-memstatus-native-20261014"
BASE="$HOME/.cache/campfire-frame-writev-20261014"
CACHE="$HOME/.cache/campfire-native-compression-20261013/go-build"
cd "$W"
test "$(docker inspect --format '{{.Id}}' localhost/campfire-publication-map-production)" = 619c76d7a213cad0af1c4588af504714751295801728c63df1041b9c93608fe3
if ! test -e source; then cp -a "$BASE/source" source; fi
rm -rf source/third_party/websocket
cp -a "$BASE/original/third_party/websocket" source/third_party/websocket
mkdir -p source/cmd/sqlite-build-probe
cp sqlite-build-probe.go source/cmd/sqlite-build-probe/main.go
docker run --rm --network host --user root --security-opt label=disable -v "$W:/work" -v "$CACHE:/root/.cache/go-build" -e GOMAXPROCS=4 -e GOAMD64=v1 -e CGO_ENABLED=1 localhost/campfire-publication-map-production bash -c '
 set -euo pipefail; cd /work/source
 go version | grep -F go1.27.1
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/current-native ./cmd/campfire
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/current-probe ./cmd/sqlite-build-probe
 /work/current-probe > /work/current-options.json
 export CGO_CFLAGS="-O2 -g -DSQLITE_DEFAULT_MEMSTATUS=0"
 if ! command -v zstd >/dev/null; then apt-get update -qq && apt-get install -y -qq zstd; fi
 go test -race -tags sqlite_fts5 ./internal/database ./internal/application ./internal/web
 go vet -tags sqlite_fts5 ./internal/database ./internal/application ./internal/web
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/candidate-native ./cmd/campfire
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/candidate-probe ./cmd/sqlite-build-probe
 /work/candidate-probe > /work/candidate-options.json
 '
printf '8a1409c09aa79e188010fb04dfa0c63b66e4f2748de734a117f6ae5db49b0e29  current-native\n' | sha256sum -c -
sha256sum current-native candidate-native
/usr/bin/python3 - <<'PY'
import json
for app,expected in [('current',0),('candidate',1)]:
 j=json.load(open(app+'-options.json'));assert j['disabled']==expected and j['version']=='3.53.4',j;print(app,j)
PY
