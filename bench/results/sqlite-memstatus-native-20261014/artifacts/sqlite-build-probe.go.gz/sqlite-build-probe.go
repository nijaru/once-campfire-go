package main

import (
	"database/sql"
	"encoding/json"
	"os"

	_ "github.com/mattn/go-sqlite3"
)

func main() {
	db, err := sql.Open("sqlite3", ":memory:")
	if err != nil {
		panic(err)
	}
	defer db.Close()
	var version string
	var disabled int
	if err := db.QueryRow("SELECT sqlite_version(), sqlite_compileoption_used('DEFAULT_MEMSTATUS=0')").Scan(&version, &disabled); err != nil {
		panic(err)
	}
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"version": version, "disabled": disabled}); err != nil {
		panic(err)
	}
}
