import gzip,hashlib,json,re
from html.parser import HTMLParser
from pathlib import Path
W=Path(__file__).resolve().parent
class Tags(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.forms=[];self.buttons=[];self.links=[]
 def handle_starttag(self,t,a):
  if t=='form':self.forms.append(dict(a))
  if t=='button':self.buttons.append(dict(a))
  if t=='a':self.links.append(dict(a))
def transform(body):
 prefix,rest=body.split('<div class="quick-boosts">',1);inner,suffix=rest.split('</div>\n<div class="flex flex-wrap border-top',1)
 starts=re.findall(r'<form ([^>]+)>',inner);assert len(starts)==8 and len(set(starts))==1
 hidden=re.findall(r'<input type="hidden" id="boost_content" name="boost\[content\]" value="([^"]+)">',inner);assert len(hidden)==8
 transformed=re.sub(r'<form [^>]+>|</form>','',inner)
 transformed=re.sub(r'<input type="hidden" id="boost_content" name="boost\[content\]" value="([^"]+)"><button name="button"',lambda m:'<button name="boost[content]" value="'+m[1]+'"',transformed)
 before=Tags();before.feed(inner);after=Tags();after.feed(transformed)
 assert len(before.buttons)==len(after.buttons)==8 and before.links==after.links
 for a,b,e in zip(before.buttons,after.buttons,hidden):
  a.pop('name');assert b.pop('name')=='boost[content]' and b.pop('value')==e;assert a==b
 return prefix+'<form class="quick-boosts" '+starts[0]+'>'+transformed+'</form>\n<div class="flex flex-wrap border-top'+suffix
# Match Go encoding/json's HTML escaping of an otherwise ordinary UTF-8 string.
def wire(body):return json.dumps({'identifier':'shared-constant','message':body},ensure_ascii=False,separators=(',',':')).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e').encode()
results=[]
with (W/'derived.jsonl').open('w') as out:
 for row in map(json.loads,(W.parent/'deflate-algorithm-20261014/corpus.jsonl').read_text().splitlines()):
  if 'plain' not in row:continue
  before=row['plain'].encode();after=transform(row['plain']).encode();a=gzip.compress(before,compresslevel=6,mtime=0);b=gzip.compress(after,compresslevel=6,mtime=0)
  results.append({'sequence':row['sequence'],'before_bytes':len(before),'after_bytes':len(after),'before_wire':len(wire(row['plain'])),'after_wire':len(wire(after.decode())),'before_gzip':len(a),'after_gzip':len(b)})
  out.write(json.dumps({'sequence':row['sequence'],'plain':after.decode(),'sha256':hashlib.sha256(after).hexdigest()},ensure_ascii=False)+'\n')
assert len(results)==256
ratios={k:sum(r['after_'+k] for r in results)/sum(r['before_'+k] for r in results) for k in ['bytes','wire','gzip']}
x={'population':256,'ratios':ratios,'per_body_gzip_growth':sum(r['after_gzip']>r['before_gzip'] for r in results),'method':'Python zlib level6 is a preliminary wire-size screen only; independent native standard-Go replay required if this screen passes. Go-style JSON escaping modeled, not captured socket receipts. All8 button attributes/submission values and new-link attributes identical.'}
x['screen_pass']=ratios['bytes']<=.8 and ratios['wire']<=.8 and x['per_body_gzip_growth']==0
(W/'representation.json').write_text(json.dumps(x,indent=2)+'\n');(W/'representation-rows.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(x,indent=2))
assert x['screen_pass']
