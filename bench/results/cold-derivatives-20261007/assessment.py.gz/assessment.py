#!/usr/bin/env python3
"""Finite local cold-transform assessment, with complete responses and blob graphs."""
import argparse, importlib.machinery, importlib.util, sys, os, tempfile, json, sqlite3, shutil, urllib.request, hashlib, time, threading, concurrent.futures, re, html
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'bin'))
loader=importlib.machinery.SourceFileLoader('parity',str(ROOT/'bin/check-parity'));spec=importlib.util.spec_from_loader(loader.name,loader);parity=importlib.util.module_from_spec(spec);loader.exec_module(parity)
from parity_storage import allocate_blob,blob_graph
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--profile',action='store_true');p.add_argument('--reps',type=int,default=3);p.add_argument('--rep-offset',type=int,default=0);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);a.out=a.out.resolve();a.binary=a.binary.resolve();os.sched_setaffinity(0,{4,5,6,7});seed=ROOT/'.cache/parity-seeds/default';labels=json.loads((seed/'labels.json').read_text());ticks=os.sysconf('SC_CLK_TCK');records=[]
env={k:v for k,v in os.environ.items() if not k.startswith(('CAMPFIRE_','THRUSTER_')) and k!='TLS_DOMAIN'}
for line in (ROOT/'reference/parity/.env.reference').read_text().splitlines():
 if line and not line.startswith('#') and '=' in line:
  k,v=line.split('=',1);env[k]=v
env.update(DISABLE_SSL='true',TARGET_BIND='127.0.0.1',GOMAXPROCS='4',TOKIO_WORKER_THREADS='4')
wrapper=a.out/'server';wrapper.write_text('#!/bin/sh\nexec taskset -c 0-3 '+str(a.binary)+' "$@"\n');wrapper.chmod(0o755)
def process(base):
 port=base.rsplit(':',1)[1]
 for q in Path('/proc').glob('[0-9]*/environ'):
  try:
   if ('TARGET_PORT='+port).encode() in q.read_bytes().split(b'\0'):return int(q.parent.name)
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 raise AssertionError('missing server PID')
def cpu(pid):
 fields=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split();return sum(int(fields[i]) for i in (11,12,13,14))/ticks
for rep in range(a.rep_offset,a.rep_offset+a.reps):
 with tempfile.TemporaryDirectory(dir=a.out,prefix='seed-') as temp:
  work=Path(temp);db=work/'database.sqlite3'
  with sqlite3.connect(f'file:{seed}/db/production.sqlite3?mode=ro',uri=True) as source,sqlite3.connect(db) as target:source.backup(target)
  shutil.copytree(seed/'storage',work/'files');runenv=env|{'CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(work),'CAMPFIRE_FILES_PATH':str(work/'files')}
  if a.profile:runenv['GO_CPU_PROFILE']=str(a.out/f'{rep}.pprof')
  with parity.upgrade.server(wrapper,runenv,a.out,f'server-{rep}') as base:
   app=parity.App(base,db,labels);assert app.login('kevin')[0]==302;pid=process(base)
   templates={}
   for name,label in [('image','messages.image'),('video','messages.video')]:
    page=app.request('kevin','GET',f"/rooms/{labels['rooms.designers']}/messages/{labels[label]}")[2]
    match=re.search(r'(?:src|poster)="([^"]*/rails/active_storage/representations/redirect/[^/]+/([^/]+)/[^\"]+)"',page);assert match,(name,'no representation')
    templates[name]=html.unescape(match[2])
   # Warm the route, media libraries and connection behavior on a disposable source.
   for warm in (True,False):
    counts=(1,) if warm else ((1,4) if rep%2==0 else (4,1))
    for count in counts:
     for name,fixture,ctype in [('image','black_hole.jpg','image/jpeg'),('video','alpha-centuri.mov','video/quicktime')]:
      raw=(ROOT/'reference/reference/test/fixtures/files'/fixture).read_bytes();blob=allocate_blob(app,raw,fixture,ctype)
      assert app.fetch('kevin','PUT',blob['upload_path'],raw,blob['direct_upload']['headers'])[0]==204
      path='/rails/active_storage/representations/proxy/'+blob['signed_id']+'/'+templates[name]+'/'+fixture
      before=app.rows('SELECT count(*) FROM active_storage_blobs')[0][0];before_files={q.relative_to(work/'files') for q in (work/'files').rglob('*') if q.is_file()};barrier=threading.Barrier(count+1)
      def request():
       barrier.wait();start=time.perf_counter();req=urllib.request.Request(base+path,headers={'Accept-Encoding':'identity'})
       with urllib.request.urlopen(req,timeout=60) as response:
        data=response.read();status=response.status;headers=response.headers
       end=time.perf_counter();assert status==200 and data and len(data)==int(headers['Content-Length']);assert headers['Content-Type'].startswith('image/');return {'ms':(end-start)*1000,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
      with concurrent.futures.ThreadPoolExecutor(max_workers=count) as pool:
       futures=[pool.submit(request) for _ in range(count)];cpu_start=cpu(pid);started=time.perf_counter();barrier.wait();results=[f.result() for f in futures];elapsed=time.perf_counter()-started;cost=cpu(pid)-cpu_start
      assert len({r['sha256'] for r in results})==1
      graph=blob_graph(app,blob['id']);expected=2 if name=='image' else 3;assert len(graph)==expected,(name,graph);assert app.rows('SELECT count(*) FROM active_storage_blobs')[0][0]==before+expected-1;after_files={q.relative_to(work/'files') for q in (work/'files').rglob('*') if q.is_file()};assert before_files.issubset(after_files) and len(after_files-before_files)==expected-1,(name,'orphan or missing files')
      if not warm:
       records.append({'phase':'cold','rep':rep,'media':name,'clients':count,'group_ms':elapsed*1000,'server_and_child_cpu_ms':cost*1000,'responses':results,'graph_blobs':len(graph)})
       barrier=threading.Barrier(5);warm_results=[]
       with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        cpu_start=cpu(pid);started=time.perf_counter()
        for _ in range(32):
         futures=[pool.submit(request) for _ in range(4)];barrier.wait();warm_results.extend(f.result() for f in futures)
        elapsed=time.perf_counter()-started;cost=cpu(pid)-cpu_start
       assert all(r['sha256']==results[0]['sha256'] for r in warm_results)
       assert blob_graph(app,blob['id'])==graph
       records.append({'phase':'warm','rep':rep,'media':name,'clients':4,'group_ms':elapsed*1000,'server_and_child_cpu_ms':cost*1000,'responses':warm_results,'graph_blobs':len(graph)})
  (a.out/'raw.json').write_text(json.dumps(records,indent=2)+'\n')
identity={'binary_sha256':hashlib.sha256(a.binary.read_bytes()).hexdigest(),'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed_sha256':hashlib.sha256((seed/'db/production.sqlite3').read_bytes()).hexdigest(),'workers':4,'server_cpus':'0-3','client_cpus':'4-7','encoding':'identity','repetitions':a.reps,'profile':a.profile,'cpu_counter_resolution_ms':1000/ticks,'scope':'Assessment only; not offered-rate latency, capacity or native physical-core evidence.'}
(a.out/'metadata.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(records))
