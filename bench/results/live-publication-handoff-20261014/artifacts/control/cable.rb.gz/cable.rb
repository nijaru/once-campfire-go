require_relative '../campfire-post-fix-20261010/bench/comparison_support'
require_relative '../campfire-post-fix-20261010/bench/http_client'
require 'digest'
require 'net/http'
require 'time'
include BenchmarkSupport
STDOUT.sync = true
root = Dir.pwd
work = root
fixture = File.expand_path('../campfire-post-fix-20261010',root)
seed = File.join(fixture,'seed')
out = File.join(work,'cable')
raise 'output exists' if File.exist?(out)
FileUtils.mkdir_p(out)
labels = JSON.parse(File.read(File.join(seed,'labels.json')))
fixture_env = File.readlines(File.join(fixture,'reference.env'),chomp:true).reject { |l| l.empty? || l.start_with?('#') }.to_h { |l| l.split('=',2) }
loadgen = File.expand_path('../campfire-ws-json-20261011/loadgen-trace',root)
room = Integer(labels.fetch('rooms.watercooler'))
people = 64
base = 'http://127.0.0.1:25340'
container = "cf-publication-handoff-#{Process.pid}"
sql = ->(db,q) { t=run('sqlite3','-cmd','.timeout 10000','-json',db,q); t.strip.empty? ? [] : JSON.parse(t) }
lg = ->(*args) { JSON.parse(run('taskset','-c','8,10,12,14',loadgen,*args)) }
images = {'current'=>'localhost/campfire-publication-map-production','candidate'=>'localhost/campfire-publication-map-production'}
metadata = JSON.parse(File.read(File.join(root,'experiment.json')),symbolize_names:true).merge(started_at:Time.now.utc.iso8601,mode:'cable',images:images.transform_values{|i|run('docker','inspect','--format','{{.Id}}',i).strip},client_sha256:Digest::SHA256.file(loadgen).hexdigest,binaries:%w[current candidate].to_h{|a|[a,Digest::SHA256.file(File.join(work,'binaries',a+'-native')).hexdigest]})
write_json(File.join(out,'metadata.json'),metadata)
results=[]
begin
  metadata.fetch(:orders).each_with_index do |order,round|
    order.each do |app|
      data="/dev/shm/campfire-publication-handoff/#{Process.pid}/#{app}-#{round+1}"
      prepare_storage(seed,data)
      FileUtils.mkdir_p(File.join(data,'logs'))
      db=File.join(data,'db/production.sqlite3')
      david=labels.fetch('emails.david').gsub("'","''")
      sql.call(db,"UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id; UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id;")
      sql.call(db,"WITH RECURSIVE n(i) AS (VALUES(1) UNION ALL SELECT i+1 FROM n WHERE i<#{people}) INSERT INTO users(name,email_address,password_digest,role,status,created_at,updated_at) SELECT 'Fanout '||i,'fanout-'||i||'@example.test',password_digest,0,0,'2026-10-10 00:00:00','2026-10-10 00:00:00' FROM n CROSS JOIN users WHERE email_address='#{david}';")
      sql.call(db,"INSERT INTO memberships(room_id,user_id,involvement,created_at,updated_at) SELECT #{room},id,'everything','2026-10-10 00:00:00','2026-10-10 00:00:00' FROM users WHERE email_address LIKE 'fanout-%@example.test';")
      verified=sql.call(db,"SELECT COUNT(*) n,COUNT(DISTINCT u.id) distinct_users FROM users u JOIN memberships m ON m.user_id=u.id WHERE u.email_address LIKE 'fanout-%@example.test' AND u.role=0 AND u.status=0 AND m.room_id=#{room}").first
      raise 'fixture people mismatch' unless verified.values.all? { |n| n==people }
      initial=sql.call(db,'SELECT MAX(id) id FROM messages').first.fetch('id')
      config=fixture_env.merge('HTTP_PORT'=>'25340','TARGET_PORT'=>'25341','GOMAXPROCS'=>'4','TOKIO_WORKER_THREADS'=>'4','RAILS_MAX_THREADS'=>'4','JOB_CONCURRENCY'=>'3','GOGC'=>'100','GO_CPU_PROFILE'=>'','GO_PHASE_CPU'=>'','GO_ALLOC_PROFILE'=>'')
      run('docker','run','-d','--name',container,'--network','host','--security-opt','label=disable',*environment(config),*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),'-v',work+':/work:ro',images.fetch(app),'taskset','-c','0,2,4,6','/work/binaries/'+app+'-native','server')
      deadline=clock+60
      client=BenchmarkHTTPClient.new(base)
      until client.ready?
        raise 'server not ready' if clock>deadline
        sleep 0.1
      end
      run('docker','exec','--user','root',container,'chmod','-R','a+rwX','/rails/storage/db')
      cookie=lg.call('login','--base',base,'--email',labels.fetch('emails.david'),'--password',labels.fetch('passwords.all')).fetch('cookie')
      scrape=lg.call('scrape','--base',base,'--cookie',cookie,'--room',room.to_s)
      session_path=File.join(data,'sessions.tsv')
      File.open(session_path,'w',0600) do |file|
        people.times do |n|
          http=Net::HTTP.new('127.0.0.1',25340,nil)
          http.local_host="127.0.0.#{n+2}"
          jar={}
          merge=->(response) { (response.get_fields('set-cookie')||[]).each { |s| k,v=s.split(';',2).first.split('=',2); jar[k]=v } }
          http.start do |h|
            page=h.get('/session/new');merge.call(page)
            token=page.body[/<meta name="csrf-token" content="([^"]*)"/,1].to_s
            request=Net::HTTP::Post.new('/session')
            request['Cookie']=jar.map { |k,v| "#{k}=#{v}" }.join('; ')
            request['Sec-Fetch-Site']='same-origin'
            request.set_form_data({'email_address'=>"fanout-#{n+1}@example.test",'password'=>labels.fetch('passwords.all'),'authenticity_token'=>token})
            response=h.request(request);merge.call(response)
            raise "fixture login #{response.code}" unless response.code=='302' && jar.key?('session_token')
          end
          c=jar.map { |k,v| "#{k}=#{v}" }.join('; ')
          page=lg.call('scrape','--base',base,'--cookie',c,'--room',room.to_s)
          raise 'bad member room' unless page.fetch('status')==200 && page.fetch('streams').length==3
          identifiers=[{'channel'=>'PresenceChannel','room_id'=>room},{'channel'=>'UnreadRoomsChannel'},{'channel'=>'HeartbeatChannel'}].map { |s| JSON.generate(s) }
          page.fetch('streams').each { |s| channel,name=s.split('|',2);identifiers << JSON.generate({'channel'=>channel,'signed_stream_name'=>name}) }
          file.puts([c,*identifiers].join("\t"))
        end
      end
      authenticated=sql.call(db,"SELECT COUNT(DISTINCT s.user_id) n FROM sessions s JOIN users u ON u.id=s.user_id WHERE u.email_address LIKE 'fanout-%@example.test'").first.fetch('n')
      raise 'not distinct authenticated people' unless authenticated==people
      # Authentication/setup does not belong in the posting/delivery CPU profile.
      run('docker','stop','--time','30',container)
      remove_container(container)
      config['GO_ALLOC_PROFILE']=''
      config['GO_CPU_PROFILE']=''
      config['GO_EXECUTION_TRACE']=''
      run('docker','run','-d','--name',container,'--network','host','--security-opt','label=disable',*environment(config),*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),'-v',work+':/work:ro',images.fetch(app),'taskset','-c','0,2,4,6','/work/binaries/'+app+'-native','server')
      deadline=clock+60
      until client.ready?
        raise 'profile server not ready' if clock>deadline
        sleep 0.1
      end
      argv=['taskset','-c','8,10,12,14',loadgen,'cable','--base',base,'--cookie',cookie,'--room',room.to_s,'--csrf',scrape.fetch('csrf').to_s,'--clients',people.to_s,'--sessions',session_path,'--latency-msgs','300','--interval-ms','100','--tput-secs','5','--posters','4','--refresh-secs','50']
      stdout=nil
      Open3.popen3({'HTTP_TRACE'=>'1'},*argv) do |stdin,output,error,wait|
        stdin.close
        reader=Thread.new {output.read}
        File.open(File.join(out,"#{app}-#{round+1}.phases.log"),'w') { |log| error.each_line { |line| log.write(line) } }
        stdout=reader.value
        File.write(File.join(out,"#{app}-#{round+1}.raw.json"),stdout)
        raise 'cable failed' unless wait.value.success?
      end
      run('ruby',File.join(fixture,'check_sample.rb'),'cable',input:stdout)
      sample=JSON.parse(stdout)
      raise 'session shape mismatch' unless sample.fetch('distinct_session_cookies')==people && sample.fetch('session_rows')==people
      posted=sample.dig('latency','post_successes')+sample.dig('throughput','posted')
      records=sql.call(db,"SELECT m.id,m.creator_id,m.room_id,rt.body,idx.body indexed_body FROM messages m LEFT JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' LEFT JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>#{initial}")
      expected_creator=sql.call(db,"SELECT id FROM users WHERE email_address='#{david}'").first.fetch('id')
      seqs=records.map { |r| r.fetch('body').match(/\Afanout bmk([0-9]+)z\z/)&.[](1)&.to_i }
      raise 'persisted population mismatch' unless records.length==posted && seqs.compact.sort==(1..posted).to_a
      raise 'body/creator/room/FTS mismatch' unless records.all? { |r| r.fetch('creator_id')==expected_creator && r.fetch('room_id')==room && r.fetch('indexed_body')==r.fetch('body') }
      trace=sample.delete('http_trace')
      expected_acks=records.zip(seqs).map { |r,s| [s,r.fetch('id')] }.sort
      raise 'acknowledged-ID mismatch' unless trace.length==posted && trace.map { |r| r.take(2) }.sort==expected_acks
      raise 'invalid client trace' unless trace.all? { |r| r[2..].each_cons(2).all? { |a,b| a<=b } }
      indexed=sql.call(db,"SELECT COUNT(*) n FROM message_search_index WHERE rowid>#{initial} AND body MATCH 'fanout'").first.fetch('n')
      raise 'missing FTS writes' unless indexed==posted
      raise 'integrity failed' unless sql.call(db,'PRAGMA integrity_check;').first.values==['ok']
      seed_fk=sql.call(File.join(seed,'db/production.sqlite3'),'PRAGMA foreign_key_check;')
      raise 'new FK violations' unless sql.call(db,'PRAGMA foreign_key_check;')==seed_fk
      deadline=clock+10
      loop do
        connections=sql.call(db,"SELECT SUM(m.connections) n FROM memberships m JOIN users u ON u.id=m.user_id WHERE u.email_address LIKE 'fanout-%@example.test' AND m.room_id=#{room}").first.fetch('n')
        break if connections==0
        raise 'presence not released' if clock>deadline
        sleep 0.1
      end
      sample['write_audit']={persisted:posted,acknowledged_ids:true,exact_markers_bodies_creator_room_fts:true,indexed:indexed,integrity:'ok',unchanged_seed_fk_violations:seed_fk.length,new_fk_violations:0,presence_after_disconnect:0}
      row={app:app,round:round+1,cable:sample}
      results << row
      write_json(File.join(out,"#{app}-#{round+1}.json"),row)
      write_json(File.join(out,'results.json'),results)
      puts "#{app} #{round+1}: #{sample.dig('throughput','delivered_msgs_per_sec')} delivered/s; POST mean/p99 #{sample.dig('throughput','post','mean_ms')}/#{sample.dig('throughput','post','p99_ms')}; #{posted} audited"
      run('docker','stop','--time','30',container)
      remove_container(container)
      FileUtils.rm_rf(data)
    end
  end
ensure
  metadata[:finished_at]=Time.now.utc.iso8601
  metadata[:completed_runs]=results.length
  write_json(File.join(out,'metadata.json'),metadata)
  write_json(File.join(out,'results.json'),results)
  remove_container(container)
end
