#!/usr/bin/env bash
set -euo pipefail
W="$HOME/.cache/campfire-publication-handoff-20261014"
CACHE="$HOME/.cache/campfire-native-compression-20261013/go-build"
EMBED="$HOME/.cache/campfire-display-projection-20261013/source"
cd "$W"; test -d "$CACHE"; tar xf source.tar.gz
cp -a "$HOME/.cache/campfire-deflate-algorithm-20261014/source/reference" source/reference
for d in assets/generated internal/presentation/templates internal/web/pwa; do
 rm -rf "source/$d"; cp -a "$EMBED/$d" "source/$d"
done
cp source/internal/cable/hub.go candidate-hub.go
mkdir -p binaries
docker run --rm --network host --user root --security-opt label=disable -v "$W:/work" -v "$CACHE:/root/.cache/go-build" \
 -e GOMAXPROCS=4 -e GOAMD64=v1 -e CGO_ENABLED=1 localhost/campfire-publication-map-production bash -c '
 set -euo pipefail; cd /work/source
 go test -race -tags sqlite_fts5 ./internal/cable ./internal/application ./internal/web
 go vet -tags sqlite_fts5 ./internal/cable ./internal/application ./internal/web
 cp /work/baseline-hub.go internal/cable/hub.go
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/binaries/current-native ./cmd/campfire
 cp /work/candidate-hub.go internal/cable/hub.go
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/binaries/candidate-native ./cmd/campfire
 go version
 '
printf '8a1409c09aa79e188010fb04dfa0c63b66e4f2748de734a117f6ae5db49b0e29  binaries/current-native\n' | sha256sum -c -
sha256sum binaries/*
