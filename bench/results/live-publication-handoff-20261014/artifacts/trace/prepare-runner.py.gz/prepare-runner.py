from pathlib import Path
import shutil
W=Path('.cache/live-critical-path-20261014');s=Path('.cache/current-three-way-20261013/cable.rb').read_text()
s=s.replace("out = File.join(work,'cable')","out = File.join(work,'capture')")
s=s.replace("container = \"cf-current-upstream-cable-#{Process.pid}\"","container = \"cf-live-critical-path-#{Process.pid}\"")
s=s.replace("images = {'current'=>'localhost/campfire-write-generation-production','upstream'=>'localhost/campfire-write-generation-production','rust'=>'localhost/campfire-write-generation-production'}", "images = {'current'=>'localhost/campfire-publication-map-production'}")
s=s.replace("metadata.fetch(:orders).each_with_index", "[['current']].each_with_index")
s=s.replace("'GO_ALLOC_PROFILE'=>'')", "'GO_ALLOC_PROFILE'=>'','GO_EXECUTION_TRACE'=>'')")
s=s.replace("*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),images.fetch(app),'taskset','-c','0,2,4,6',{'current'=>'/go-candidate','upstream'=>'/go-upstream','rust'=>'/rust-current'}.fetch(app),'server')", "*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),'-v',work+':/work:ro',images.fetch(app),'taskset','-c','0,2,4,6','/work/binaries/current-native','server')",1)
old="config['GO_CPU_PROFILE']=''\n      run('docker','run'"
s=s.replace(old,"config['GO_CPU_PROFILE']=''\n      config['GO_EXECUTION_TRACE']='/rails/storage/logs/runtime.trace'\n      config['ATTRIBUTION_CPU_PATH']='/rails/storage/logs/cpu.json'\n      run('docker','run'",1)
s=s.replace("*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),images.fetch(app),'taskset','-c','0,2,4,6',{'current'=>'/go-candidate','upstream'=>'/go-upstream','rust'=>'/rust-current'}.fetch(app),'server')", "*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),'-v',work+':/work:ro',images.fetch(app),'python3','/work/supervise.py','taskset','-c','0,2,4,6','/work/binaries/current-native','server')",1)
s=s.replace("'--latency-msgs','300'","'--latency-msgs','100'")
s=s.replace("FileUtils.rm_rf(data)","""cpu=JSON.parse(File.read(File.join(data,'logs/cpu.json')))
      raise 'server did not join cleanly' unless cpu.fetch('exit_code')==0
      row[:cpu]=cpu
      FileUtils.cp(File.join(data,'logs/runtime.trace'),File.join(out,'current.trace'))
      raise 'trace missing' unless File.size(File.join(out,'current.trace'))>0
      write_json(File.join(out,"#{app}-#{round+1}.json"),row)
      write_json(File.join(out,'results.json'),results)
      metadata[:source_binary_sha256]=Digest::SHA256.file(File.join(work,'binaries/current-native')).hexdigest
      metadata[:client_sha256]=Digest::SHA256.file(loadgen).hexdigest
      metadata[:trace_sha256]=Digest::SHA256.file(File.join(out,'current.trace')).hexdigest
      FileUtils.rm_rf(data)""")
assert s.count("[['current']]")==1 and s.count("'/work/binaries/current-native'")==2 and "'/go-candidate'" not in s
(W/'capture.rb').write_text(s);shutil.copy2('.cache/post-critical-path-20261013/supervise.py',W/'supervise.py')
