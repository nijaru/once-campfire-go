#!/usr/bin/env bash
set -euo pipefail
W="$HOME/.cache/campfire-live-critical-path-20261014"
BASE="$HOME/.cache/campfire-deflate-algorithm-20261014"
EMBED="$HOME/.cache/campfire-display-projection-20261013/source"
CACHE="$HOME/.cache/campfire-native-compression-20261013/go-build"
cd "$W"
test -d "$CACHE"; test -f "$BASE/source/reference/vectors/rails_compat.json"
tar xf source.tar.gz
cp -a "$BASE/source/reference" source/reference
for d in assets/generated internal/presentation/templates internal/web/pwa; do
 test -d "$EMBED/$d"; rm -rf "source/$d"; cp -a "$EMBED/$d" "source/$d"
done
mkdir -p binaries
# Native test decoder only in this disposable build container; no image/host edit.
docker run --rm --network host --user root --security-opt label=disable \
 -v "$W:/work" -v "$CACHE:/root/.cache/go-build" \
 -e GOMAXPROCS=4 -e GOAMD64=v1 -e CGO_ENABLED=1 \
 localhost/campfire-publication-map-production bash -c '
 set -euo pipefail
 if ! command -v zstd >/dev/null; then apt-get update && apt-get install -y --no-install-recommends zstd; fi
 cd /work/source
 go test -race -tags sqlite_fts5 ./internal/cable ./internal/front ./internal/web
 go vet -tags sqlite_fts5 ./internal/cable ./internal/database ./internal/application ./internal/front ./internal/web
 (cd third_party/websocket && go test -race ./... && go vet ./...)
 go build -tags sqlite_fts5 -trimpath -buildvcs=false -o /work/binaries/current-native ./cmd/campfire
 go version
 '
sha256sum binaries/current-native
