import difflib,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
R=Path.cwd();W=R/'.cache/live-critical-path-20261014';S=W/'source'
assert not S.exists();shutil.copytree(R/'.cache/post-critical-path-20261013/current',S,ignore=shutil.ignore_patterns('reference'))
# Only tests use this local symlink; remote fixture copy is read-only task input.
(S/'reference').symlink_to('../../../reference')
originals={}
def change(file,old,new):
 p=S/file;s=p.read_text();originals.setdefault(file,s);assert s.count(old)==1,(file,old);p.write_text(s.replace(old,new))
def traced(file):
 if '"runtime/trace"' not in (S/file).read_text():change(file,'import (','import (\n "runtime/trace"')
def region(file,sig,ctx,label):
 p=S/file;s=p.read_text();originals.setdefault(file,s);a=s.index(sig);b=s.index('{',a);p.write_text(s[:b+1]+'\n defer trace.StartRegion('+ctx+',"'+label+'").End()\n'+s[b+1:]);traced(file)
f='internal/front/server.go'
change(f,'if id := r.Header.Get("X-Benchmark-Request"); id != "" {\n\t\t\t\ttrace.Log(ctx, "benchmark.ingress", id+","+strconv.FormatInt(wall, 10))\n\t\t\t}', 'trace.Log(ctx, "benchmark.ingress", "unlabelled,"+strconv.FormatInt(wall, 10))')
f='internal/web/server.go';sig='func (s *Server) createMessage(';s=(S/f).read_text();a=s.index(sig);b=s.index('defer trace.StartRegion(r.Context(), "action.create").End()',a);old='defer trace.StartRegion(r.Context(), "action.create").End()';change(f,old,old+'\n trace.Log(r.Context(),"benchmark.sequence",r.Form.Get("message[body]"))')
region('internal/cable/hub.go','func (h *Hub) publish(', 'ctx','cable.publish')
region('internal/database/models.go','func (d *DB) AuthorizeSessions(', 'ctx','cable.authorization')
region('internal/database/push.go','func (d *DB) RoomMemberIDs(', 'ctx','notifications.members')
f='internal/cable/hub.go'
change(f,'if frame == nil {\n\t\t\t\tframe = websocket.NewPreparedMessage(websocket.MessageText, data)\n\t\t\t}\n\t\t\tif err := writer.Write(frame); err != nil || closeAfter {','''if frame == nil {
    frame = websocket.NewPreparedMessage(websocket.MessageText, data)
   }
   label := frame.BenchmarkSequence
   if label != "" { trace.Log(ctx,"cable.write.begin",label) }
   writeErr := writer.Write(frame)
   if label != "" { trace.Log(ctx,"cable.write.end",label) }
   if writeErr != nil || closeAfter {''')
change(f,'ctx, cancel := context.WithCancel(r.Context())','''ctx, cancel := context.WithCancel(r.Context())
 ctx, task := trace.NewTask(ctx,"cable.connection")
 defer task.End()
 trace.Log(ctx,"cable.user",strconv.FormatInt(user.ID,10))''')
change(f,'func (c *client) sendFrame(data *websocket.PreparedMessage) bool {','''func (c *client) sendFrame(data *websocket.PreparedMessage) bool {
 if data.BenchmarkSequence != "" { trace.Log(context.Background(),"cable.enqueue",strconv.FormatInt(c.user.ID,10)+","+data.BenchmarkSequence) }''')
change(f,'frame = websocket.NewPreparedMessage(websocket.MessageText, data)\n\t\t\tframes[r.identifier] = frame','''frame = websocket.NewPreparedMessage(websocket.MessageText, data)
   // Diagnostic-only immutable tag. Normal payload bytes and ownership unchanged.
   if body, ok := message.(string); ok {
    if _, after, found := strings.Cut(body,"fanout bmk"); found {
     if seq, _, found := strings.Cut(after,"z"); found {
      if n, err := strconv.ParseUint(seq,10,64); err == nil && n > 0 { frame.BenchmarkSequence = seq }
     }
    }
   }
   frames[r.identifier] = frame''')
f='third_party/websocket/prepared.go';change(f,'type PreparedMessage struct {','type PreparedMessage struct {\n BenchmarkSequence string // Private diagnostic tag, assigned before publication only.')
subprocess.check_call(['gofmt','-w',*originals],cwd=S)
patch=''.join(''.join(difflib.unified_diff(old.splitlines(True),(S/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f)) for f,old in sorted(originals.items()))
(W/'live.patch').write_text(patch)
# Compose the complete overlay against exact archived production, not an opaque chained patch.
arc=W/'production.tar';arc.write_bytes(subprocess.check_output(['git','archive','8351224']))
with tarfile.open(arc) as tf:
 full=''.join(''.join(difflib.unified_diff(tf.extractfile(f).read().decode().splitlines(True),(S/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f)) for f in sorted(set(originals)|{x for x in ['cmd/campfire/main.go','internal/database/database.go','internal/web/response_cache.go','internal/web/response.go','internal/database/sessions.go','internal/application/messages.go','internal/application/message_queries.go','internal/database/message_display.go','internal/application/message_effects.go','internal/front/response.go','internal/front/compression.go'] if (S/x).exists()}))
(W/'complete.patch').write_text(full)
x=json.loads((W/'experiment.json').read_text());x['production_archive_sha256']=hashlib.sha256(arc.read_bytes()).hexdigest();x['complete_overlay_sha256']=hashlib.sha256(full.encode()).hexdigest();(W/'experiment.json').write_text(json.dumps(x,indent=2)+'\n')
print('Prepared isolated trace overlay only; production unchanged.')
