"""One current live capture: exact requests and server-frame lifecycle partitions."""
import bisect,collections,json,math,os,re,statistics,subprocess
from pathlib import Path
W=Path(__file__).resolve().parent
HEADER=re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+) (.*)$')
def field(s,k):
 m=re.search(r'\b'+k+r'=(?:"([^"]*)"|([^ ]+))',s)
 return (m[1] if m[1] is not None else m[2]) if m else None

def parse(path):
 tasks={};active={};states={};regions={};connections={};enqueues={};frames={};writing={}
 def account(g,t):
  if g in states:
   state,start=states[g];assert t>=start
   if g in active and t>start:tasks[active[g]]['state_spans'].append([start,t,state])
   if g in writing and t>start:writing[g]['states'][state]+=t-start
   states[g]=(state,t)
 p=subprocess.Popen([os.environ.get('GO','go'),'tool','trace','-d=parsed',str(path)],stdout=subprocess.PIPE,text=True,bufsize=1024*1024)
 for line in p.stdout:
  m=HEADER.match(line)
  if not m:continue
  g=int(m[3]);kind=m[4];t=int(m[5]);text=m[6]
  if kind=='StateTransition' and field(text,'GoID') is not None:
   gid=int(field(text,'GoID'));tr=re.search(r' (\w+)->(\w+)',text);assert tr
   if tr[1]==tr[2]:continue
   account(gid,t);states[gid]=(tr[2],t)
  elif kind=='TaskBegin':
   tid=int(field(text,'ID'));typ=field(text,'Type')
   if typ=='http.message.create':
    assert g not in active;account(g,t);active[g]=tid;states[g]=('Running',t)
    tasks[tid]={'begin':t,'gid':g,'state_spans':[],'region_spans':collections.defaultdict(list)}
   elif typ=='cable.connection':connections[tid]={}
  elif kind=='TaskEnd':
   tid=int(field(text,'ID'))
   if tid in tasks:account(g,t);tasks[tid]['end']=t;assert active.pop(g)==tid
   if tid in connections:connections[tid]['end']=t
  elif kind=='Log':
   tid=int(field(text,'Task'));cat=field(text,'Category');msg=field(text,'Message')
   if cat=='benchmark.ingress':
    assert tid in tasks;tasks[tid]['wall_begin']=int(msg.split(',')[1])
   elif cat=='benchmark.sequence':
    assert tid in tasks;match=re.fullmatch(r'fanout bmk([1-9][0-9]*)z',msg);assert match,msg
    tasks[tid]['sequence']=int(match[1])
   elif cat=='cable.user':connections[tid]['user']=int(msg)
   elif cat=='cable.enqueue':
    user,seq=map(int,msg.split(','));key=(user,seq);assert key not in enqueues
    assert g in active;enqueues[key]={'enqueue':t,'task':active[g]}
   elif cat=='cable.write.begin':
    user=connections[tid]['user'];seq=int(msg);key=(user,seq)
    assert key in enqueues and key not in frames and g not in writing
    account(g,t);states[g]=('Running',t)
    f={'user':user,'sequence':seq,'begin':t,'gid':g,'states':collections.defaultdict(int),**enqueues[key]};frames[key]=f;writing[g]=f
   elif cat=='cable.write.end':
    user=connections[tid]['user'];key=(user,int(msg));f=writing[g];assert frames[key] is f
    account(g,t);f['end']=t;writing.pop(g)
  elif kind in ('RegionBegin','RegionEnd'):
   tid=int(field(text,'Task'));name=field(text,'Type');key=(g,tid,name)
   if kind=='RegionBegin':
    assert key not in regions
    owner=tid if tid in tasks else active.get(g)
    regions[key]=(t,owner)
   elif key in regions:
    start,owner=regions.pop(key)
    if owner is not None:tasks[owner]['region_spans'][name].append([start,t])
 assert p.wait()==0
 assert not active and not writing
 assert set(enqueues)==set(frames)
 for r in tasks.values():
  assert {'end','sequence','wall_begin'}<=set(r)
  assert sum(b-a for a,b,s in r['state_spans'])==r['end']-r['begin']
  for name,spans in r['region_spans'].items():
   for a,b in spans:
    assert r['begin']<=a<=b<=r['end'],name
    assert sum(max(0,min(b,y)-max(a,x)) for x,y,s in r['state_spans'])==b-a
 for f in frames.values():
  assert f['enqueue']<=f['begin']<=f['end'];assert sum(f['states'].values())==f['end']-f['begin']
  assert tasks[f['task']]['sequence']==f['sequence']
 assert all('end' in c for c in connections.values())
 assert len({c['user'] for c in connections.values()})==len(connections)==64
 return list(tasks.values()),list(frames.values())

def describe(rows):
 assert rows;keys=sorted(k for k in rows[0] if k.endswith('_ns'))
 assert all(set(k for k in r if k.endswith('_ns'))==set(keys) for r in rows)
 return {'n':len(rows),'mean_us':{k:statistics.mean(r[k] for r in rows)/1000 for k in keys}}

def correlate(tasks,frames,sample):
 clients=sample['http_trace'];n=sample['latency']['post_successes']+sample['throughput']['posted']
 assert len(clients)==len(tasks)==n
 server={r['sequence']:r for r in tasks};assert sorted(server)==list(range(1,n+1))
 rows=[]
 for seq,msgid,started,headers,wire,validated in clients:
  r=server[seq];assert started<=headers<=wire<=validated;duration=r['end']-r['begin']
  row={'sequence':seq,'message_id':msgid,'client_wire_ns':wire-started,'client_validated_ns':validated-started,'validation_ns':validated-wire,'handler_ns':duration,'before_ingress_ns':r['wall_begin']-started,'after_handler_ns':wire-r['wall_begin']-duration}
  assert row['before_ingress_ns']+row['handler_ns']+row['after_handler_ns']==row['client_wire_ns']
  for state in ['Running','Runnable','Waiting','Syscall']:
   row['handler_'+state+'_ns']=sum(b-a for a,b,s in r['state_spans'] if s==state)
  for name,spans in r['region_spans'].items():
   row[name+'_ns']=sum(b-a for a,b in spans)
   for state in ['Running','Runnable','Waiting','Syscall']:
    row[name+'_'+state+'_ns']=sum(max(0,min(b,y)-max(a,x)) for a,b in spans for x,y,s in r['state_spans'] if s==state)
  assert 'writer.acquire_ns' in row and 'writer.hold_ns' in row
  rows.append(row)
 count=collections.Counter(f['sequence'] for f in frames);assert set(count)==set(server) and set(count.values())=={64}
 delivery=[]
 for f in frames:
  row={k:f[k] for k in ['user','sequence']};row['writer_gid']=f['gid'];row['enqueue_trace_tick']=f['enqueue'];row['write_begin_trace_tick']=f['begin'];row['write_end_trace_tick']=f['end'];row|={'queue_ns':f['begin']-f['enqueue'],'write_ns':f['end']-f['begin'],'server_delivery_ns':f['end']-f['enqueue']}
  for state in ['Running','Runnable','Waiting','Syscall']:row['write_'+state+'_ns']=f['states'][state]
  assert row['queue_ns']+row['write_ns']==row['server_delivery_ns'];delivery.append(row)
 tail=sorted(rows,key=lambda r:r['client_wire_ns'])[-math.ceil(n*.01):]
 ftail=sorted(delivery,key=lambda r:r['server_delivery_ns'])[-math.ceil(len(delivery)*.01):]
 summary={'http_all':describe(rows),'http_slowest_one_percent':describe(tail),'frames_all':describe(delivery),'frames_slowest_one_percent':describe(ftail),'negative_http_boundary_residuals':sum(r['before_ingress_ns']<0 or r['after_handler_ns']<0 for r in rows),'audited_messages':n,'exact_server_frame_lifecycles':len(frames),'all_state_region_reconstructions':True,'client_receive_timestamps':'not recorded; server completion is not all-client completion'}
 return rows,delivery,summary

def queue_states(path,rows):
 gids={r['writer_gid'] for r in rows};states={};spans=collections.defaultdict(list)
 p=subprocess.Popen([os.environ.get('GO','go'),'tool','trace','-d=parsed',str(path)],stdout=subprocess.PIPE,text=True,bufsize=1024*1024)
 for line in p.stdout:
  m=HEADER.match(line)
  if not m or m[4]!='StateTransition':continue
  text=m[6];gid=field(text,'GoID')
  if gid is None or int(gid) not in gids:continue
  gid=int(gid);t=int(m[5]);tr=re.search(r' (\w+)->(\w+)',text);assert tr
  if tr[1]==tr[2]:continue
  if gid in states:
   state,start=states[gid];assert t>=start
   if t>start:spans[gid].append([start,t,state])
  states[gid]=(tr[2],t)
 assert p.wait()==0
 starts={g:[a for a,b,s in values] for g,values in spans.items()}
 for r in rows:
  g=r['writer_gid'];a=r['enqueue_trace_tick'];b=r['write_begin_trace_tick'];parts=collections.defaultdict(int)
  i=max(0,bisect.bisect_right(starts[g],a)-1)
  while i<len(spans[g]) and spans[g][i][0]<b:
   x,y,s=spans[g][i];parts[s]+=max(0,min(b,y)-max(a,x));i+=1
  assert sum(parts.values())==b-a
  for state in ['Running','Runnable','Waiting','Syscall']:r['queue_writer_'+state+'_ns']=parts[state]
 return {'all':describe(rows),'slowest_one_percent':describe(sorted(rows,key=lambda r:r['server_delivery_ns'])[-math.ceil(len(rows)*.01):])}

if __name__=='__main__':
 sample=json.loads((W/'capture/current-1.raw.json').read_text());tasks,frames=parse(W/'capture/current.trace');rows,delivery,summary=correlate(tasks,frames,sample)
 summary['queue_writer_state_partitions']=queue_states(W/'capture/current.trace',delivery)
 for label,records in [('http-correlated',rows),('frame-correlated',delivery)]:
  (W/'capture'/f'{label}.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
 (W/'capture/analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
