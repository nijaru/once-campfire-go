package richtext

import (
	"encoding/json"
	"os"
	"strings"
	"testing"
)

var probeResult Result
var probeText string

// Task-private complete prepared-content/display probe, not a permanent benchmark
// or an application-capacity test. Bodies come from the retained fixture/seed.
func BenchmarkSerializationDocument(b *testing.B) {
	data, err := os.ReadFile(os.Getenv("PROBE_BODIES"))
	if err != nil {
		b.Fatal(err)
	}
	var bodies map[string]string
	if err = json.Unmarshal(data, &bodies); err != nil {
		b.Fatal(err)
	}
	for _, name := range []string{"plain", "escaped", "seed"} {
		body := bodies[name]
		b.Run(name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				doc := Prepare(body)
				content, err := doc.Content(Context{})
				if err != nil {
					b.Fatal(err)
				}
				display, err := doc.Display(Context{})
				if err != nil {
					b.Fatal(err)
				}
				if content.Errors["body_html"] != nil || display.Errors["presentation"] != nil {
					b.Fatal(content.Errors, display.Errors)
				}
				probeResult = display
				probeText = content.BodyHTML
			}
		})
	}
}

// Exhaust the byte alphabet and relevant UTF-8/entity boundaries against the
// existing standalone escaper. The oracle supplies independent HTML expectations.
func TestSerializerDirectEscapingMatchesStandalone(t *testing.T) {
	samples := []string{"", "plain", "a&<>\u00a0b", "é🙂", "\xc2", "\xa0", "\xff", "\xc2\xa0", strings.Repeat("&<>", 1024)}
	for i := 0; i < 256; i++ {
		samples = append(samples, string([]byte{byte(i)}))
	}
	for _, s := range samples {
		var b strings.Builder
		n, err := textEscaper.WriteString(&b, s)
		want := escapeText(s)
		if err != nil || n != len(want) || b.String() != want {
			t.Fatalf("%q: output=%q count=%d err=%v want=%q", s, b.String(), n, err, want)
		}
	}
}
