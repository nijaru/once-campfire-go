#include <stdio.h>
#include <sqlite3.h>
int main(void) {
 sqlite3 *db=0;int rc=sqlite3_open(":memory:",&db);if(rc!=SQLITE_OK)return 1;
 if(sqlite3_exec(db,"CREATE TABLE t(a); INSERT INTO t VALUES(randomblob(4096));",0,0,0)!=SQLITE_OK)return 2;
 int cache=0,high=0;sqlite3_db_status(db,SQLITE_DBSTATUS_CACHE_USED,&cache,&high,0);
 sqlite3_hard_heap_limit64(64*1024*1024);
 sqlite3_hard_heap_limit64(sqlite3_memory_used()+65536);
 void *over_limit=sqlite3_malloc(1024*1024);
 int enforced=over_limit==0;
 sqlite3_free(over_limit);
 printf("{\"version\":\"%s\",\"DEFAULT_MEMSTATUS_0\":%d,\"global_memory_bytes\":%lld,\"hard_limit\":%lld,\"connection_cache_bytes\":%d,\"allocation_limit_enforced\":%d}\n",sqlite3_libversion(),sqlite3_compileoption_used("DEFAULT_MEMSTATUS=0"),(long long)sqlite3_memory_used(),(long long)sqlite3_hard_heap_limit64(-1),cache,enforced);
 sqlite3_hard_heap_limit64(0);sqlite3_close(db);return 0;
}
