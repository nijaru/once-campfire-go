package database

import (
 "context"
 "path/filepath"
 "testing"
)

func BenchmarkResponseVersion(b *testing.B) {
 d, err := Open(filepath.Join(b.TempDir(), "probe.sqlite3"), 4)
 if err != nil { b.Fatal(err) }
 b.Cleanup(func() { d.Close() })
 ctx, cancel := context.WithCancel(context.Background())
 b.Cleanup(cancel)
 b.ReportAllocs()
 b.ResetTimer()
 for b.Loop() {
  if _, err := d.ResponseVersion(ctx); err != nil { b.Fatal(err) }
 }
}
