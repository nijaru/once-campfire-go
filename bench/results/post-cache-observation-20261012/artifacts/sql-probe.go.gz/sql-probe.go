package main

import (
 "context"
 "database/sql"
 "encoding/json"
 "fmt"
 "time"
 _ "github.com/mattn/go-sqlite3"
)

func main() {
 d,e:=sql.Open("sqlite3","file:.cache/parity-seeds/default/db/production.sqlite3?mode=ro&_query_only=on&_stmt_cache_size=256"); if e!=nil {panic(e)};defer d.Close();d.SetMaxOpenConns(1)
 var v string; d.QueryRow("SELECT sqlite_version()").Scan(&v);fmt.Println("SQLite",v)
 for _, table:=range []string{"rooms","users","boosts"} {
  key:="id";if table=="boosts" {key="message_id"}
  rs,e:=d.Query("SELECT DISTINCT "+key+" FROM "+table+" ORDER BY "+key+" LIMIT 40");if e!=nil {panic(e)};var ids []int64;for rs.Next(){var id int64;if e=rs.Scan(&id);e!=nil {panic(e)};ids=append(ids,id)};rs.Close()
  for _, n:=range []int{1,len(ids)} {
   raw,_:=json.Marshal(ids[:n]);fmt.Println(table,"ids",n)
   qs:=[]string{"SELECT t."+key+" FROM "+table+" t WHERE t."+key+" IN (SELECT value FROM json_each(?))","SELECT t."+key+" FROM json_each(?) wanted JOIN "+table+" t ON t."+key+"=wanted.value"}
   for _, q:=range qs {
    fmt.Println(q);r,e:=d.Query("EXPLAIN QUERY PLAN "+q,string(raw));if e!=nil {panic(e)};for r.Next(){var a,b,c int;var plan string;r.Scan(&a,&b,&c,&plan);fmt.Println(plan)};r.Close()
    var count int;start:=time.Now();for k:=0;k<10000;k++ {r,e:=d.QueryContext(context.Background(),q,string(raw));if e!=nil {panic(e)};for r.Next(){var id int64;if e=r.Scan(&id);e!=nil {panic(e)};count++};if e=r.Err();e!=nil {panic(e)};r.Close()};fmt.Println("elapsed",time.Since(start),"rows",count)
   }
  }
 }
}
