import contextlib, hashlib, http.cookiejar, json, os, platform, re, shutil, signal, socket, sqlite3, subprocess, tempfile, time, urllib.parse, urllib.request
from pathlib import Path
ROOT=Path.cwd(); WORK=ROOT/'.cache/local-post-work-20261011'; SEED=ROOT/'.cache/parity-seeds/default'; LABELS=json.loads((SEED/'labels.json').read_text())
OUT=WORK/'capture'; OUT.mkdir(exist_ok=False)
fixture={}
for line in (ROOT/'.cache/shared-current/reference.env').read_text().splitlines():
 if line and not line.startswith('#'):
  k,v=line.split('=',1);fixture[k]=v
metadata={'source':'8351224','upstream':'c4ab53d','platform':platform.platform(),'go':subprocess.check_output(['go','version'],text=True).strip(),'seed_sha256':hashlib.sha256((SEED/'db/production.sqlite3').read_bytes()).hexdigest(),'budget':'One current/upstream CPU capture pair, 3000 offered/s, 2+20s. Setup/login/shared preflight before restart. Local CPU attribution only, not native latency promotion or historical diagnosis. No task-owned concurrent builds/tests/profilers.','settings':{'workers':4,'readers':4,'jobs':3,'gzip':1,'gogc':100},'binaries':{k:hashlib.sha256((WORK/f).read_bytes()).hexdigest() for k,f in [('current','current'),('upstream','upstream-bin'),('client','httprate')]}}
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
def free_port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def wait_ready(base,p):
 deadline=time.monotonic()+60
 while time.monotonic()<deadline:
  if p.poll() is not None:raise RuntimeError('server exited')
  try:
   if urllib.request.urlopen(base+'/up',timeout=1).status==200:return
  except OSError:pass
  time.sleep(.1)
 raise RuntimeError('not ready')
def stop(p):
 if p.poll() is None:
  p.send_signal(signal.SIGTERM)
  try:p.wait(timeout=35)
  except subprocess.TimeoutExpired:p.kill();p.wait();raise
 if p.returncode!=0:raise RuntimeError(f'server exit {p.returncode}')
results=[]
for app,binary in [('current','current'),('upstream','upstream-bin')]:
 with tempfile.TemporaryDirectory(prefix='runtime-',dir=WORK) as td:
  d=Path(td);db=d/'production.sqlite3'
  with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
  shutil.copytree(SEED/'storage',d/'files')
  with sqlite3.connect(db) as c:
   c.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id")
   c.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
   seed_fk=c.execute('PRAGMA foreign_key_check').fetchall()
   actor=c.execute('SELECT id FROM users WHERE email_address=?',(LABELS['emails.david'],)).fetchone()[0]
  target,front=free_port(),free_port();base=f'http://127.0.0.1:{front}'
  env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ}|fixture|{'DISABLE_SSL':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(d),'CAMPFIRE_FILES_PATH':str(d/'files'),'GOMAXPROCS':'4','JOB_CONCURRENCY':'3','GOGC':'100'}
  log=(OUT/f'{app}.log').open('w')
  p=subprocess.Popen([str(WORK/binary),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   wait_ready(base,p)
   jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
   body=client.open(base+'/session/new').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else ''
   request=urllib.request.Request(base+'/session',data=urllib.parse.urlencode({'email_address':LABELS['emails.david'],'password':LABELS['passwords.all'],'authenticity_token':csrf}).encode(),headers={'Sec-Fetch-Site':'same-origin'})
   client.open(request).read();cookie='; '.join(f'{x.name}={x.value}' for x in jar)
   assert any(x.name=='session_token' for x in jar)
   body=client.open(base+f'/rooms/{LABELS["rooms.watercooler"]}').read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body);csrf=m[1] if m else '';css=re.search(r'<link[^>]*href="([^"]+\.css[^\"]*)"',body)[1]
   preflight=json.loads(subprocess.check_output(['ruby',str(ROOT/'.cache/shared-verification-current/bench/contracts.rb'),base,cookie,str(db),str(SEED/'labels.json'),css,str(d/'contracts')],text=True))
   stop(p)
   env['GO_CPU_PROFILE']=str(OUT/f'{app}.cpu.pprof')
   p=subprocess.Popen([str(WORK/binary),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT);wait_ready(base,p);time.sleep(1)
   samples=[]
   for seconds in [2,20]:
    with sqlite3.connect(db) as c:before=c.execute('SELECT max(id) FROM messages').fetchone()[0]
    raw=subprocess.check_output([str(WORK/'httprate'),'--base',base,'--cookie',cookie,'--gzip','1','--conc','64','--queue','8192','--pacing','active','--rate','3000','--duration',str(seconds),'--post-room',str(LABELS['rooms.hq']),'--csrf',csrf],text=True)
    (OUT/f'{app}-{seconds}.raw.json').write_text(raw);s=json.loads(raw);acks=s.pop('acknowledged')
    assert s['errors']==0 and s['unscheduled']==0 and s['ok']==3000*seconds and s['statuses']=={'200':3000*seconds},s
    with sqlite3.connect(db) as c:
     rows=c.execute("SELECT m.id,m.creator_id,m.room_id,m.client_message_id,rt.body,idx.body FROM messages m JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>?",(before,)).fetchall()
     assert c.execute('SELECT count(*) FROM messages WHERE id>?',(before,)).fetchone()[0]==s['ok']
    assert len(rows)==s['ok'] and len({r[3] for r in rows})==s['ok']
    expected=[]
    for id,creator,room,clientid,body,indexed in rows:
     seq=int(re.fullmatch(r'bench write ([0-9]+)',body)[1]);assert creator==actor and room==int(LABELS['rooms.hq']) and indexed.split()==body.split();expected.append([seq,id])
    assert sorted(x[0] for x in expected)==list(range(s['ok'])) and sorted(acks)==sorted(expected)
    s['write_audit']={'exact_ids_body_creator_room_fts':True,'count':len(rows)};samples.append(s)
   stop(p)
   with sqlite3.connect(db) as c:
    assert c.execute('PRAGMA integrity_check').fetchone()==('ok',)
    assert c.execute('PRAGMA foreign_key_check').fetchall()==seed_fk
   result={'app':app,'profiled_writes':sum(x['ok'] for x in samples),'samples':samples,'preflight':preflight['preflight'],'integrity':'ok','unchanged_seed_fk_violations':len(seed_fk)};results.append(result)
   (OUT/f'{app}.json').write_text(json.dumps(result,indent=2)+'\n');print(app,result['profiled_writes'],'audited writes',flush=True)
  finally:
   if p.poll() is None:stop(p)
   log.close()
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
