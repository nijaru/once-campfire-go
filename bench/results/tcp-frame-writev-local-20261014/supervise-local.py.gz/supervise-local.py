"""Join the real server and collect OS CPU; forward container shutdown signals."""
import json, os, signal, subprocess, sys, time
from pathlib import Path
child = subprocess.Popen(sys.argv[1:])
def forward(number, _frame):
    try: os.kill(child.pid, number)
    except ProcessLookupError: pass
signal.signal(signal.SIGTERM, forward)
signal.signal(signal.SIGINT, forward)
started = time.monotonic()
while True:
    try:
        pid, status, usage = os.wait4(child.pid, 0)
        break
    except InterruptedError:
        pass
code = os.waitstatus_to_exitcode(status)
Path(os.environ['ATTRIBUTION_CPU_PATH']).write_text(json.dumps({
    'exit_code': code, 'wall_seconds': time.monotonic()-started,
    'user_seconds': usage.ru_utime, 'system_seconds': usage.ru_stime,
    'cpu_seconds': usage.ru_utime+usage.ru_stime,
})+'\n')
raise SystemExit(code)
