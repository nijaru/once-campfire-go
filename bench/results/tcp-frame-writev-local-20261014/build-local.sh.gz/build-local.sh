#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
W="$ROOT/.cache/frame-writev-20261014"
GO=/Users/nick/.local/share/mise/installs/go/1.27.1/bin/go
mkdir -p "$W/binaries"
cp -a "$W/source/third_party/websocket" "$W/local-candidate-websocket"
trap 'rm -rf "$W/source/third_party/websocket"; cp -a "$W/local-candidate-websocket" "$W/source/third_party/websocket"' EXIT
rm -rf "$W/source/third_party/websocket"
cp -a "$W/original/third_party/websocket" "$W/source/third_party/websocket"
(cd "$W/source"; CGO_ENABLED=1 "$GO" build -mod=readonly -tags sqlite_fts5 -trimpath -buildvcs=false -o "$W/binaries/current-mac" ./cmd/campfire)
rm -rf "$W/source/third_party/websocket"
cp -a "$W/local-candidate-websocket" "$W/source/third_party/websocket"
(cd "$W/source"; CGO_ENABLED=1 "$GO" build -mod=readonly -tags sqlite_fts5 -trimpath -buildvcs=false -o "$W/binaries/candidate-mac" ./cmd/campfire)
CARGO_TARGET_DIR="$W/local-client-target" cargo build --release --locked --offline --manifest-path "$ROOT/.cache/ws-json-20261011/client/Cargo.toml"
cp "$W/local-client-target/release/loadgen" "$W/binaries/loadgen-mac"
"$GO" version
rustc --version
shasum -a 256 "$W/binaries/"*
