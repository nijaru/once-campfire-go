import json
from pathlib import Path
from statistics import mean, median

root = Path(__file__).parent / 'capture'
results = json.loads((root / 'results.json').read_text())
summary = {'runs': [], 'correlations': [], 'limits': ['No sub-1000/s phase captured; no causal conclusion about historical collapse.', 'Client recording common to both arms; client overhead neutrality unproved.', 'Server probe wraps net.Conn; matched control isolates its complete-workload effect, not each probe effect.', 'Cross-process realtime clock correlations on one VM; small signed negative ordering residuals retained.', 'Affinity is not isolation. No external host interference cause established.']}

def describe(values):
    ordered = sorted(values)
    return {'n': len(values), 'mean_ms': mean(values) / 1e6, 'p50_ms': median(values) / 1e6, 'p99_ms': ordered[min(len(ordered)-1, int(len(ordered)*.99))] / 1e6, 'max_ms': max(values) / 1e6, 'min_ms': min(values) / 1e6}

for result in results:
    app, rnd, cable = result['app'], result['round'], result['cable']
    summary['runs'].append({'app': app, 'round': rnd, 'rate': cable['throughput']['delivered_msgs_per_sec'], 'post_p99_ms': cable['throughput']['post']['p99_ms'], 'all_p99_ms': cable['throughput']['all_clients']['p99_ms'], 'paced_p99_ms': cable['latency']['all_clients']['p99_ms'], 'audited': cable['write_audit']['persisted']})
    if app != 'trace':
        continue
    raw = json.loads((root / f'{app}-{rnd}.raw.json').read_text())
    client = {r[0]: r for r in raw['http_trace']}
    server_rows = json.loads((root / f'{app}-{rnd}.server.json').read_text())
    server = {r['seq']: r for r in server_rows}
    assert len(server) == len(server_rows) == len(client)
    assert server.keys() == client.keys()
    correlated = []
    for seq, c in client.items():
        s = server[seq]
        assert s['Read'] > 0 and s['Entry'] >= s['Read']
        assert s['Exit'] >= s['Entry'] and s['FirstWrite'] >= s['Entry']
        assert s['LastWrite'] >= s['FirstWrite'] and s['Bytes'] > 0 and s['Errors'] == 0
        # Signed intervals conserve each request, including concurrently running
        # client/handler/socket boundaries. Never subtract marginal percentiles.
        intervals = {'before_handler': s['Entry']-c[2], 'handler': s['Exit']-s['Entry'], 'after_handler_to_body': c[4]-s['Exit'], 'validation': c[5]-c[4]}
        assert sum(intervals.values()) == c[5]-c[2]
        correlated.append({'seq': seq, 'total': c[5]-c[2], **intervals, 'read_to_entry': s['Entry']-s['Read'], 'write_calls': s['WriteNS'], 'exit_to_last_write': s['LastWrite']-s['Exit'], 'last_write_to_body': c[4]-s['LastWrite'], 'headers_to_body': c[4]-c[3]})
    rows = [r for r in correlated if r['seq'] > 100]
    top = sorted(rows, key=lambda r:r['total'], reverse=True)[:max(1,len(rows)//100)]
    metrics = {k: describe([r[k] for r in rows]) for k in rows[0] if k != 'seq'}
    slow = {k: mean(r[k] for r in top)/1e6 for k in rows[0] if k != 'seq'}
    summary['correlations'].append({'round': rnd, 'exact_joined_requests': len(client), 'saturated': metrics, 'slowest_one_percent_n': len(top), 'slowest_one_percent_mean_ms': slow})
for rnd in range(1,4):
    pair = {r['app']: r for r in summary['runs'] if r['round'] == rnd}
    print(f"pair {rnd}: server probe delivered rate {(pair['trace']['rate']/pair['pristine']['rate']-1)*100:+.2f}%; POST p99 {(pair['trace']['post_p99_ms']/pair['pristine']['post_p99_ms']-1)*100:+.2f}%")
print(json.dumps(summary, indent=2))
(root / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
