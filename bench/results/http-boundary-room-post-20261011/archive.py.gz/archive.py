import difflib
import gzip
import hashlib
import json
from pathlib import Path
from statistics import median

root=Path.cwd()
http=root/'.cache/http-boundary-20261012'
post=root/'.cache/post-room-20261012'
out=root/'bench/results/http-boundary-room-post-20261011'
out.mkdir(parents=True,exist_ok=False)
manifest=[]

def save(name,content):
    if isinstance(content,str): content=content.encode()
    packed=gzip.compress(content,mtime=0)
    (out/(name+'.gz')).write_bytes(packed)
    manifest.append({'path':name+'.gz','sha256':hashlib.sha256(packed).hexdigest(),'bytes':len(packed)})

def diff(paths):
    chunks=[]
    for before,after,name in paths:
        a=before.read_text().splitlines(keepends=True) if before else []
        b=after.read_text().splitlines(keepends=True)
        chunks.extend(difflib.unified_diff(a,b,fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
    return ''.join(chunks)

save('http-server.patch',diff([(root/'internal/front/server.go',http/'source/internal/front/server.go','internal/front/server.go'),(None,http/'source/internal/front/bench_trace.go','internal/front/bench_trace.go'),(None,http/'source/internal/front/bench_trace_test.go','internal/front/bench_trace_test.go')]))
save('http-client.patch',diff([(root/'.cache/shared-verification-current/loadgen/src/main.rs',http/'client/src/main.rs','src/main.rs')]))
save('room-candidate.patch',diff([(root/'internal/web/server.go',post/'source/internal/web/server.go','internal/web/server.go'),(None,post/'source/internal/web/message_room_test.go','internal/web/message_room_test.go')]))
save('fixed-client.patch',diff([(root/'bench/httprate/main.go',post/'source/bench/httprate/main.go','bench/httprate/main.go'),(None,post/'source/bench/httprate/validate_post.go','bench/httprate/validate_post.go')]))
for name,path in [('http-run.rb',http/'run.rb'),('http-analyze.py',http/'analyze.py'),('http-Dockerfile',http/'Dockerfile'),('room-run.rb',post/'http.rb'),('room-Dockerfile',post/'Dockerfile'),('current-check.log',root/'.cache/check-http-boundary-current.log'),('http-trace-gates.log',http/'trace-build-final.log'),('http-client-gates.log',http/'client-final-gates.log'),('room-local-check.log',post/'check.log'),('room-native-gates.log',post/'native-build.log'),('http-run.log',http/'run.log'),('room-run.log',post/'fixed.log')]:
    save(name,path.read_bytes())
for name,path in [('http-metadata.json',http/'capture/metadata.json'),('http-results.json',http/'capture/results.json'),('http-summary.json',http/'capture/summary.json')]:
    save(name,path.read_bytes())
fixed=json.loads((post/'fixed/results.json').read_text())
# Preflight includes fixture-grounded read checks but is not timing or a new read
# claim. Keep only the complete POST measurement and audit records public.
fixed=[{'app':r['app'],'round':r['round'],'http':r['http']} for r in fixed]
save('room-results.json',json.dumps(fixed,indent=2)+'\n')
metadata=json.loads((post/'fixed/metadata.json').read_text())
metadata['binary_sha256']={'current':'b92bbcebe6ac87631e60eed82abf825ca164c101e0ebf0863d185b0f1f010cf4','candidate':'0ca025633ce85aeef263a14d19290e42d3ea97879c1461aa19ed636ebe11f051','fixed_client':'b32ba319f2be026f18dd82538fe03651355c20bee637ddc00b105baa20d2d4d5'}
metadata['gate_result']='Candidate rejected; all three fixed-rate p99 pairs lose; no capacity/Cable comparison after primary failure; no production or permanent test changes.'
metadata['scope']='Fresh current/candidate release binaries differ in browser createMessage only; same generated assets, dependencies and flags. Fixture FK violations unchanged; shared read preflight retained privately. Private client decodes/validates after the completion timestamp and before the next worker request; all exact ACK IDs independently audited. No historical fixed-run latency equivalence claimed.'
save('room-metadata.json',json.dumps(metadata,indent=2)+'\n')
rows=[]
for r in fixed:
    timed=next(s for s in r['http'] if not s['warmup'])
    assert all(s['errors']==s['unscheduled']==s['dropped']==0 for s in r['http'])
    assert all(s['ok']==s['planned']==s['acknowledged_write_audit']['count']==s['persisted_write_audit']['count'] for s in r['http'])
    rows.append({'app':r['app'],'round':r['round'],'p99_ms':timed['latency']['p99_ms'],'ok':timed['ok'],'mean_ms':timed['latency']['mean_ms']})
a=[r['p99_ms'] for r in rows if r['app']=='go-before'];b=[r['p99_ms'] for r in rows if r['app']=='go']
summary={'runs':rows,'median_current_p99_ms':median(a),'median_candidate_p99_ms':median(b),'median_p99_change_percent':(median(b)/median(a)-1)*100,'audited_warm_timed_writes':sum(s['ok'] for r in fixed for s in r['http']),'decision':'Rejected; all three p99 pairs lose. Budget closed; no production change.'}
save('room-summary.json',json.dumps(summary,indent=2)+'\n')
save('archive.py',Path(__file__).read_bytes())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print(len(manifest),'artifacts',sum(r['bytes'] for r in manifest),'compressed bytes')
