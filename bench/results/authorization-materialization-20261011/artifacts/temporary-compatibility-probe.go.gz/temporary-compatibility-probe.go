package database

import (
	"context"
	"errors"
	"reflect"
	"testing"
)

// Packed authorization results must preserve exact token keys and integer
// identities. The existing revocation test uses ordinary tokens and small IDs.
func TestAuthorizationPreservesTokenKeysAndLargeIdentities(t *testing.T) {
	d := testDB(t)
	ctx := context.Background()
	const user int64 = 1<<53 + 7
	stamp := Stamp(d.Now())
	if _, err := d.Write.ExecContext(ctx, "INSERT INTO users(id,name,created_at,updated_at) VALUES (?,?,?,?)", user, "Member", stamp, stamp); err != nil {
		t.Fatal(err)
	}
	ordinary, err := d.StartSession(ctx, user, "ordinary", "127.0.0.1")
	if err != nil {
		t.Fatal(err)
	}
	original, err := d.StartSession(ctx, user, "escaped", "127.0.0.1")
	if err != nil {
		t.Fatal(err)
	}
	escaped := "quote\"\\\n雪"
	if _, err = d.Write.ExecContext(ctx, "UPDATE sessions SET token=? WHERE token=?", escaped, original); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		name   string
		tokens []string
		want   map[string]int64
	}{
		{"nil", nil, map[string]int64{}},
		{"empty", []string{}, map[string]int64{}},
		{"missing", []string{"missing"}, map[string]int64{}},
		{"duplicates and escaped key", []string{ordinary, escaped, escaped, "missing"}, map[string]int64{ordinary: user, escaped: user}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got, err := d.AuthorizedSessions(ctx, tc.tokens, 0)
			if err != nil || !reflect.DeepEqual(got, tc.want) {
				t.Fatalf("authorization: %v %v; want %v", got, err, tc.want)
			}
		})
	}
	cancelled, cancel := context.WithCancel(ctx)
	cancel()
	if _, err = d.AuthorizedSessions(cancelled, []string{ordinary}, 0); !errors.Is(err, context.Canceled) {
		t.Fatalf("cancelled authorization: %v", err)
	}
	// A cancelled query must not poison a pooled connection or cache authority.
	got, err := d.AuthorizedSessions(ctx, []string{ordinary}, 0)
	if err != nil || got[ordinary] != user {
		t.Fatalf("authorization after cancellation: %v %v", got, err)
	}
}
