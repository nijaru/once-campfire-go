package database

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"log/slog"
	"sync"
	"sync/atomic"

	"github.com/mattn/go-sqlite3"
)

// The WAL callback owns its physical writer connection until it returns. It
// schedules PASSIVE checkpoints without blocking, or performs native RESTART at
// the growth threshold before database/sql can release that connection. Native
// checkpointing from a WAL hook is supported by SQLite's callback contract;
// running SQL through database/sql here would instead reenter its locked driver.
type checkpoints struct {
	pool       *sql.DB
	connection *sql.Conn
	passive    *sql.Stmt
	context    context.Context
	cancel     context.CancelFunc
	wake       chan struct{}
	done       chan struct{}
	running    sync.Mutex
	closing    atomic.Bool
	wokenAt    int // accessed only by the single serialized writer
}

func openCheckpoints(dsn string) (*checkpoints, error) {
	pool, err := sql.Open("sqlite3", dsn)
	if err != nil {
		return nil, err
	}
	pool.SetMaxOpenConns(1)
	pool.SetMaxIdleConns(1)
	conn, err := pool.Conn(context.Background())
	if err != nil {
		pool.Close()
		return nil, err
	}
	stmt, err := conn.PrepareContext(context.Background(), "PRAGMA main.wal_checkpoint(PASSIVE)")
	if err != nil {
		conn.Close()
		pool.Close()
		return nil, err
	}
	ctx, cancel := context.WithCancel(context.Background())
	p := &checkpoints{
		pool: pool, connection: conn, passive: stmt, context: ctx, cancel: cancel,
		wake: make(chan struct{}, 1), done: make(chan struct{}),
	}
	go p.run()
	return p, nil
}

func (p *checkpoints) run() {
	defer close(p.done)
	for {
		select {
		case <-p.context.Done():
			return
		case <-p.wake:
			p.running.Lock()
			var busy, pages, copied int
			err := p.passive.QueryRowContext(p.context).Scan(&busy, &pages, &copied)
			p.running.Unlock()
			if err != nil && p.context.Err() == nil {
				slog.Warn("WAL checkpoint failed", "error", err)
			}
		}
	}
}

func (p *checkpoints) committed(conn *sqlite3.SQLiteConn, database string, pages int) int {
	if database != "main" || p.closing.Load() {
		return 0
	}
	if pages >= 10_000 {
		p.running.Lock()
		_, _, err := conn.Checkpoint(2) // SQLITE_CHECKPOINT_RESTART
		p.running.Unlock()
		if err != nil {
			slog.Warn("WAL restart checkpoint failed", "error", err)
		}
		return 0 // maintenance must not report an already committed write as failed
	}
	if pages < p.wokenAt {
		p.wokenAt = 0
	}
	if pages-p.wokenAt >= 1_000 {
		select {
		case p.wake <- struct{}{}:
			p.wokenAt = pages
		default:
		}
	}
	return 0
}

func (p *checkpoints) Close() error {
	p.closing.Store(true)
	p.cancel()
	<-p.done
	return errors.Join(p.passive.Close(), p.connection.Close(), p.pool.Close())
}

// Connector keeps per-database callback ownership out of sql's global registry.
type writerConnector struct {
	dsn    string
	driver *sqlite3.SQLiteDriver
}

func (c writerConnector) Connect(context.Context) (driver.Conn, error) { return c.driver.Open(c.dsn) }
func (c writerConnector) Driver() driver.Driver                        { return c.driver }

func checkpointWriter(dsn string, p *checkpoints) *sql.DB {
	return sql.OpenDB(writerConnector{dsn: dsn, driver: &sqlite3.SQLiteDriver{
		ConnectHook: func(conn *sqlite3.SQLiteConn) error {
			conn.RegisterWALHook(func(database string, pages int) int { return p.committed(conn, database, pages) })
			return nil
		},
	}})
}
