//go:build cgo

package sqlite3

/*
#ifndef USE_LIBSQLITE3
#include "sqlite3-binding.h"
#else
#include <sqlite3.h>
#endif
extern int walHookTrampoline(void*, sqlite3*, char*, int);
*/
import "C"
import "unsafe"

// RegisterWALHook replaces the connection's automatic checkpoint callback.
// SQLite calls it after a WAL commit releases the write lock. Nonzero return
// codes report an error despite the commit having occurred; return SQLITE_OK
// for observational callbacks. Connection access must remain serialized.
func (c *SQLiteConn) RegisterWALHook(callback func(string, int) int) {
	if callback == nil {
		C.sqlite3_wal_hook(c.db, nil, nil)
	} else {
		C.sqlite3_wal_hook(c.db, (*[0]byte)(C.walHookTrampoline), newHandle(c, callback))
	}
}

//export walHookTrampoline
func walHookTrampoline(handle unsafe.Pointer, _ *C.sqlite3, database *C.char, pages C.int) C.int {
	return C.int(lookupHandle(handle).(func(string, int) int)(C.GoString(database), int(pages)))
}

// Checkpoint runs SQLite's native checkpoint operation on the serialized
// connection, including from its WAL hook. Modes match sqlite3_wal_checkpoint_v2:
// 0 PASSIVE, 1 FULL, 2 RESTART, 3 TRUNCATE, -1 NOOP.
func (c *SQLiteConn) Checkpoint(mode int) (log, copied int, err error) {
	var nlog, ncopy C.int
	if rc := C.sqlite3_wal_checkpoint_v2(c.db, nil, C.int(mode), &nlog, &ncopy); rc != C.SQLITE_OK {
		err = c.lastError()
	}
	return int(nlog), int(ncopy), err
}
