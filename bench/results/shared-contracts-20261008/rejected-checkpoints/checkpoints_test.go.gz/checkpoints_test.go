package database

import (
	"testing"
	"time"
)

func TestBackgroundCheckpointsAdvance(t *testing.T) {
	d := testDB(t)
	if _, err := d.Write.Exec("CREATE TABLE checkpoint_probe(payload BLOB)"); err != nil {
		t.Fatal(err)
	}
	// Grow beyond the background threshold and the restart threshold using real
	// transactions, then let the final partial background checkpoint settle.
	for range 180 {
		if _, err := d.Write.Exec("INSERT INTO checkpoint_probe VALUES (zeroblob(262144))"); err != nil {
			t.Fatal(err)
		}
	}
	deadline := time.Now().Add(5 * time.Second)
	for {
		var busy, pages, copied int
		err := d.Write.QueryRow("PRAGMA main.wal_checkpoint(NOOP)").Scan(&busy, &pages, &copied)
		if err != nil {
			t.Fatal(err)
		}
		if busy == 0 && pages > 0 && copied > 0 && pages-copied < 1000 {
			if pages >= 10000 {
				t.Fatalf("restart did not reduce current WAL frames: %d", pages)
			}
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("background checkpoint did not advance: busy=%d pages=%d copied=%d", busy, pages, copied)
		}
		time.Sleep(time.Millisecond)
	}
	var count int
	if err := d.Read.QueryRow("SELECT COUNT(*) FROM checkpoint_probe").Scan(&count); err != nil || count != 180 {
		t.Fatal(count, err)
	}
}
