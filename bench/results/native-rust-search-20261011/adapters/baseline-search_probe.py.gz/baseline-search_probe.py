import json, sqlite3, time, statistics
from pathlib import Path
seed=Path.home()/'.cache/campfire-post-fix-20261010/seed/db/production.sqlite3'
db=sqlite3.connect(f'file:{seed}?mode=ro',uri=True)
queries=['coffee','message','room']
probe="SELECT m.id,m.room_id,m.updated_at,member.user_id IS NOT NULL FROM message_search_index idx JOIN messages m ON m.id=idx.rowid LEFT JOIN memberships member ON member.room_id=m.room_id AND member.user_id=? WHERE idx.body MATCH ? ORDER BY idx.rowid DESC LIMIT 1000"
fallback="SELECT m.id,m.room_id,m.updated_at,1 FROM messages m JOIN message_search_index idx ON idx.rowid=m.id JOIN memberships member ON member.room_id=m.room_id WHERE member.user_id=? AND idx.body MATCH ? ORDER BY m.id DESC LIMIT 100"
continuation="SELECT m.id,m.room_id,m.updated_at,1 FROM messages m JOIN message_search_index idx ON idx.rowid=m.id JOIN memberships member ON member.room_id=m.room_id WHERE member.user_id=? AND idx.body MATCH ? AND idx.rowid<? ORDER BY m.id DESC LIMIT ?"
result={'sqlite_version':sqlite3.sqlite_version,'messages':db.execute('select count(*) from messages').fetchone()[0],'queries':[]}
users=[r[0] for r in db.execute('select id from users where status=0')]
for query in queries:
    summary={'term':query,'active_users':len(users),'global_matches':db.execute('select count(*) from message_search_index where body match ?',('"'+query+'"',)).fetchone()[0],'fallback_users':0,'samples':[]}
    for user in users:
        rows=db.execute(probe,(user,'"'+query+'"')).fetchall()
        accessible=[r for r in rows if r[3]]
        if len(accessible)>=100 or len(rows)<1000: continue
        summary['fallback_users']+=1
        expected=db.execute(fallback,(user,'"'+query+'"')).fetchall()
        tail=db.execute(continuation,(user,'"'+query+'"',rows[-1][0],100-len(accessible))).fetchall()
        assert accessible+tail==expected
        if len(summary['samples'])<3:
            summary['samples'].append({'probe_accessible':len(accessible),'fallback_rows':len(expected),'tail_rows':len(tail),'fallback_plan':db.execute('explain query plan '+fallback,(user,'"'+query+'"')).fetchall(),'continuation_plan':db.execute('explain query plan '+continuation,(user,'"'+query+'"',rows[-1][0],100-len(accessible))).fetchall()})
    result['queries'].append(summary)
print(json.dumps(result,indent=2))
