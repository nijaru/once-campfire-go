import sqlite3, tempfile, json
from pathlib import Path
seed=Path.home()/'.cache/campfire-post-fix-20261010/seed/db/production.sqlite3'
probe="SELECT m.id,m.room_id,m.updated_at,member.user_id IS NOT NULL FROM message_search_index idx JOIN messages m ON m.id=idx.rowid LEFT JOIN memberships member ON member.room_id=m.room_id AND member.user_id=? WHERE idx.body MATCH ? ORDER BY idx.rowid DESC LIMIT 1000"
fallback="SELECT m.id,m.room_id,m.updated_at,1 FROM messages m JOIN message_search_index idx ON idx.rowid=m.id JOIN memberships member ON member.room_id=m.room_id WHERE member.user_id=? AND idx.body MATCH ? ORDER BY m.id DESC LIMIT 100"
continuation="SELECT m.id,m.room_id,m.updated_at,1 FROM messages m JOIN message_search_index idx ON idx.rowid=m.id JOIN memberships member ON member.room_id=m.room_id WHERE member.user_id=? AND idx.body MATCH ? AND idx.rowid<? ORDER BY m.id DESC LIMIT ?"
scoped="SELECT m.id,m.room_id,m.updated_at,1 FROM message_search_index idx JOIN messages m ON m.id=idx.rowid JOIN memberships member ON member.room_id=m.room_id AND member.user_id=? WHERE idx.body MATCH ? ORDER BY idx.rowid DESC LIMIT 100"
out={'sqlite_version':sqlite3.sqlite_version,'fixture_basis':'TestSearchFindsSparseMembershipBehindInaccessibleMatches; existing seed, 1100 newer inaccessible matches','cases':[]}
for prefix in [0,50]:
    with tempfile.TemporaryDirectory(prefix='campfire-search-probe-') as directory:
        src=sqlite3.connect(f'file:{seed}?mode=ro',uri=True); db=sqlite3.connect(str(Path(directory)/'data.sqlite3')); src.backup(db); src.close()
        db.execute('pragma cache_size=2000')
        user,room=db.execute('select u.id,m.room_id from users u join memberships m on m.user_id=u.id where u.status=0 order by u.id,m.room_id limit 1').fetchone()
        stamp='2026-10-10 00:00:00.000000'
        hidden=db.execute("insert into rooms(creator_id,name,type,created_at,updated_at) values (?,'Sparse probe','Rooms::Closed',?,?)",(user,stamp,stamp)).lastrowid
        def insert(room,i):
            id=db.execute('insert into messages(room_id,creator_id,client_message_id,created_at,updated_at) values (?,?,?,?,?)',(room,user,f'sparse-probe-{i}',stamp,stamp)).lastrowid
            db.execute("insert into action_text_rich_texts(name,record_type,record_id,body,created_at,updated_at) values ('body','Message',?,'<p>sparseneedle</p>',?,?)",(id,stamp,stamp))
            db.execute('insert into message_search_index(rowid,body) values (?,?)',(id,'sparseneedle'))
        for i in range(100): insert(room,i)
        for i in range(1100): insert(room if prefix and i>=100 and i%20==0 else hidden,i+100)
        db.commit()
        def measured(sql,args):
            steps=[0]
            def progress(): steps[0]+=1; return 0
            db.set_progress_handler(progress,1)
            rows=db.execute(sql,args).fetchall(); db.set_progress_handler(None,0)
            return rows,steps[0]
        rows,probe_steps=measured(probe,(user,'"sparseneedle"'))
        accessible=[r for r in rows if r[3]]
        expected,old_steps=measured(fallback,(user,'"sparseneedle"'))
        tail,new_steps=measured(continuation,(user,'"sparseneedle"',rows[-1][0],100-len(accessible)))
        direct,direct_steps=measured(scoped,(user,'"sparseneedle"'))
        assert accessible+tail==expected==direct
        out['cases'].append({'reachable_probe_rows':len(accessible),'probe_rows':len(rows),'result_rows':len(expected),'tail_rows':len(tail),'probe_vm_steps':probe_steps,'restart_vm_steps':old_steps,'continuation_vm_steps':new_steps,'old_total_vm_steps':probe_steps+old_steps,'new_total_vm_steps':probe_steps+new_steps,'scoped_vm_steps':direct_steps,'scoped_plan':db.execute('explain query plan '+scoped,(user,'"sparseneedle"')).fetchall(),'fallback_plan':db.execute('explain query plan '+fallback,(user,'"sparseneedle"')).fetchall(),'continuation_plan':db.execute('explain query plan '+continuation,(user,'"sparseneedle"',rows[-1][0],100-len(accessible))).fetchall()})
print(json.dumps(out,indent=2))
