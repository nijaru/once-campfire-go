require_relative '../campfire-post-fix-20261010/bench/comparison_support'
require_relative '../campfire-post-fix-20261010/bench/http_client'
require_relative '../campfire-post-fix-20261010/bench/contracts'
require_relative '../campfire-post-fix-20261010/bench/validate_acks'
require 'digest'
require 'time'
include BenchmarkSupport
root = Dir.pwd
fixture = File.expand_path('../campfire-post-fix-20261010',root)
seed = File.join(fixture,'seed')
mode = ARGV.fetch(0)
raise 'bad mode' unless %w[capacity fixed].include?(mode)
out = File.join(root,mode)
raise 'output exists' if File.exist?(out)
FileUtils.mkdir_p(out)
labels = JSON.parse(File.read(File.join(seed,'labels.json')))
fixture_env = File.readlines(File.join(fixture,'reference.env'),chomp:true).reject { |l| l.empty? || l.start_with?('#') }.to_h { |l| l.split('=',2) }
loadgen = File.join(fixture,'loadgen-src/loadgen/target/release/loadgen')
rate_loadgen = File.join(fixture,'httprate')
room = Integer(labels.fetch('rooms.watercooler'))
write_room = Integer(labels.fetch('rooms.hq'))
base = 'http://127.0.0.1:25170'
container = "cf-fixed-latency-#{Process.pid}"
metadata = {started_at:Time.now.utc.iso8601,source_revision:'9990759185b556a365d6e72853a7bf542589ce5c',application_revision:'811ae046389282ac44f5dd714d29ce43d6f0a276',upstream_revision:'c4ab53d00b0a19a55962e03d18057ca6c3da9437',rust_revision:'6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad',verification_revision:'ec02debb3e44f40b8778a6a42db3c4515b2f9eaf',mode:mode,cohort:{rounds:3,orders:[%w[go-before go rust],%w[rust go go-before],%w[go go-before rust]]},instrumentation:'none; no task-owned builds/tests/agents/profilers during timing',seed_sha256:Digest::SHA256.file(File.join(seed,'db/production.sqlite3')).hexdigest,loadgen_sha256:Digest::SHA256.file(loadgen).hexdigest,rate_loadgen_sha256:Digest::SHA256.file(rate_loadgen).hexdigest,server_cpus:'0,2,4,6',client_cpus:'8,10,12,14',settings:{read_rate:10000,post_rate:3000,duration:8,warmup:2,concurrency_bound:64,gzip:1,gogc:100,pacing:'active'},validation:'Shared seed-grounded route contracts before timing and four shared per-response checks after each read sample. Timed httprate consumes full wire bodies and checks status/nonempty/transport, not semantic content. Each write sample independently audits exact persisted indexed body, unique client identity, room and creator; Fixed-rate acknowledgment IDs are not captured; capacity uses the shared acknowledgment-ID/body audit.',images:{}}
results = []
sql = ->(db,query) { text=run('sqlite3','-cmd','.timeout 10000','-json',db,query);text.strip.empty? ? [] : JSON.parse(text) }
lg = ->(*args) { JSON.parse(run('taskset','-c','8,10,12,14',loadgen,*args)) }
begin
  3.times do |round|
    order = [%w[go-before go rust],%w[rust go go-before],%w[go go-before rust]].fetch(round)
    order.each do |app|
      data = "/dev/shm/campfire-native-rust-baseline/#{Process.pid}/#{mode}-#{app}-#{round+1}"
      prepare_storage(seed,data)
      FileUtils.mkdir_p(File.join(data,'logs'))
      db = File.join(data,'db/production.sqlite3')
      sql.call(db,"UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id; UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id;")
      image = 'localhost/campfire-native-rust-baseline'
      binary = {'go'=>'/go-current-native','go-before'=>'/go-upstream','rust'=>'/rust-current'}.fetch(app)
      metadata[:images][app] = run('docker','inspect','--format','{{.Id}}',image).strip
      config = fixture_env.merge('HTTP_PORT'=>'25170','TARGET_PORT'=>'25171','GOMAXPROCS'=>'4','TOKIO_WORKER_THREADS'=>'4','RAILS_MAX_THREADS'=>'4','JOB_CONCURRENCY'=>'3','GOGC'=>'100')
      # Rootless container root maps to this benchmark user.
      run('docker','run','-d','--name',container,'--network','host','--security-opt','label=disable',*environment(config),*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),image,'taskset','-c','0,2,4,6',binary,'server')
      deadline = clock + 60
      client = BenchmarkHTTPClient.new(base)
      until client.ready?
        if clock > deadline
          stdout,stderr,status=Open3.capture3('docker','logs',container)
          File.write(File.join(out,"#{app}-#{round+1}-startup.log"),stdout+stderr)
          raise 'server not ready'
        end
        sleep 0.1
      end
      run('docker','exec','--user','root',container,'chmod','-R','a+rwX','/rails/storage/db')
      sleep 3
      cookie = lg.call('login','--base',base,'--email',labels.fetch('emails.david'),'--password',labels.fetch('passwords.all')).fetch('cookie')
      scrape = lg.call('scrape','--base',base,'--cookie',cookie,'--room',room.to_s)
      prepared = BenchmarkContracts.prepare(base,cookie,db,labels,scrape.fetch('css'),File.join(data,'contracts'))
      routes = {'room_show'=>"/rooms/#{room}",'messages_page'=>"/rooms/#{room}/messages?before=#{labels.fetch('messages.busy_060')}",'sidebar'=>'/users/me/sidebar','search'=>'/searches?q=coffee','post_message'=>nil}
      samples = []
      routes.select { |name,path| name == 'post_message' }.each do |name,path|
        rate = path ? 10000 : 3000
        [2,8].each do |duration|
          before = sql.call(db,'SELECT MAX(id) id FROM messages').first.fetch('id')
          if mode == 'fixed'
            argv = ['taskset','-c','8,10,12,14',rate_loadgen,'--base',base,'--cookie',cookie,'--gzip','1','--conc','64','--queue','8192','--pacing','active','--rate',rate.to_s,'--duration',duration.to_s,'--post-room',write_room.to_s,'--csrf',scrape.fetch('csrf').to_s]
          else
            audit = File.join(data,"#{duration}-acks.jsonl")
            argv = ['taskset','-c','8,10,12,14',loadgen,'http','--base',base,'--cookie',cookie,'--gzip','1','--conc',duration == 2 ? '4' : '16','--duration',duration.to_s,'--post-room',write_room.to_s,'--csrf',scrape.fetch('csrf').to_s,'--validate',prepared.fetch(:contracts).fetch(name),'--audit-writes',audit]
          end
          started = clock
          cpu_before = Process.times
          sample = JSON.parse(run(*argv))
          cpu_after = Process.times
          sample['generator_cpu_percent'] = 100*(cpu_after.cutime+cpu_after.cstime-cpu_before.cutime-cpu_before.cstime)/(clock-started)
          sample['route'] = name
          sample['warmup'] = duration == 2
          write_json(File.join(out,"#{app}-#{round+1}-#{name}-#{duration}.json"),sample)
          if mode == 'fixed'
            raise 'lost offered arrivals' unless sample.fetch('errors') == 0 && sample.fetch('unscheduled') == 0 && sample.fetch('ok') == rate*duration && sample.fetch('statuses') == {'200'=>rate*duration}
          else
            raise 'invalid capacity responses' unless sample.fetch('errors') == 0 && sample.fetch('invalid_responses') == 0 && sample.fetch('validation') == 'route-contract-v1' && sample.fetch('ok') > 0 && sample.fetch('statuses') == {'200'=>sample.fetch('ok')}
            sample['acknowledged_write_audit'] = AcknowledgedWrites.verify(db,write_room,[audit],sample.fetch('ok'))
          end
          unless path
            rows = sql.call(db,"SELECT m.id,m.creator_id,m.room_id,m.client_message_id,rt.body,idx.body indexed_body FROM messages m JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>#{before}")
            creator = sql.call(db,"SELECT id FROM users WHERE email_address='#{labels.fetch('emails.david').gsub("'","''")}'").first.fetch('id')
            actual = sql.call(db,"SELECT COUNT(*) n FROM messages WHERE id>#{before}").first.fetch('n')
            bodies = mode == 'fixed' ? rows.map { |r| r.fetch('body')[/bench write ([0-9]+)/,1]&.to_i }.sort : nil
            expected = sample.fetch('ok')
            raise 'persisted write population mismatch' unless actual == expected && rows.length == actual && (mode == 'capacity' || bodies == (0...actual).to_a)
            raise 'wrong room, creator, identity or FTS' unless rows.map { |r| r.fetch('client_message_id') }.uniq.length == actual && rows.all? { |r| r.fetch('creator_id') == creator && r.fetch('room_id') == write_room && r.fetch('indexed_body').split.join(' ') == "bench write #{r.fetch('body')[/bench write ([0-9a-f]+)/,1]}" }
            sample['persisted_write_audit'] = {count:actual,exact_bodies:true,unique_client_ids:true,correct_creator_room:true,normalized_fts:true}
          end
          samples << sample
          puts "#{app} #{round+1} #{name} #{duration}s: p99=#{sample.dig('latency','p99_ms')}ms service=#{sample.dig('service_latency','p99_ms')}ms late=#{sample.dig('generator_lateness','p99_ms')}ms"
        end
        if path
          probe = lg.call('http','--base',base,'--cookie',cookie,'--path',path,'--gzip','1','--conc','1','--duration','10','--requests','4','--validate',prepared.fetch(:contracts).fetch(name))
          run('ruby',File.join(fixture,'check_sample.rb'),input:JSON.generate(probe))
          samples.last['after_shared_contract'] = probe
        end
      end
      raise 'database integrity' unless sql.call(db,'PRAGMA integrity_check;').first.values == ['ok']
      row = {app:app,round:round+1,http:samples,preflight:prepared.fetch(:preflight)}
      results << row
      write_json(File.join(out,"#{app}-#{round+1}.json"),row)
      write_json(File.join(out,'results.json'),results)
      write_json(File.join(out,'metadata.json'),metadata)
      remove_container(container)
      FileUtils.rm_rf(data)
    end
  end
ensure
  remove_container(container)
end
