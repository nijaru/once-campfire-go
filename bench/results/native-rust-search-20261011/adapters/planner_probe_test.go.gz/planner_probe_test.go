//go:build sqlite_trace

package database

import (
 "fmt"
 "testing"
)

func TestPrivateSearchQueryPlan(t *testing.T) {
 d:=testDB(t)
 var version string
 if err:=d.Read.QueryRow("SELECT sqlite_version()").Scan(&version); err!=nil { t.Fatal(err) }
 fmt.Println("Go SQLite:",version)
 rows,err:=d.Read.Query("EXPLAIN QUERY PLAN SELECT m.id,m.room_id,m.updated_at FROM message_search_index idx JOIN messages m ON m.id=idx.rowid JOIN memberships member ON member.room_id=m.room_id AND member.user_id=? WHERE idx.body MATCH ? ORDER BY idx.rowid DESC LIMIT 100",1,"needle")
 if err!=nil { t.Fatal(err) }
 defer rows.Close()
 for rows.Next() {
  var id,parent,unused int
  var detail string
  if err:=rows.Scan(&id,&parent,&unused,&detail); err!=nil { t.Fatal(err) }
  fmt.Println(detail)
 }
 if err:=rows.Err(); err!=nil { t.Fatal(err) }
}
