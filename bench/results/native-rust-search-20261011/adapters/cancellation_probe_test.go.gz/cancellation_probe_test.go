//go:build sqlite_trace

package database

import (
 "context"
 "errors"
 "strings"
 "sync"
 "testing"
 "time"

 sqlite3 "github.com/mattn/go-sqlite3"
)

// This private probe gates entry to sqlite3_step, not admission or Go row filtering.
func TestPrivateSearchCancellationReusesReader(t *testing.T) {
 d := testDB(t)
 d.Read.SetMaxOpenConns(1)
 d.Read.SetMaxIdleConns(1)
 ctx, cancel := context.WithCancel(context.Background())
 defer cancel()
 entered := make(chan struct{})
 var once sync.Once
 conn, err := d.Read.Conn(context.Background())
 if err != nil { t.Fatal(err) }
 err = conn.Raw(func(raw any) error {
  return raw.(*sqlite3.SQLiteConn).SetTrace(&sqlite3.TraceConfig{
   EventMask: sqlite3.TraceStmt,
   Callback: func(info sqlite3.TraceInfo) int {
    if strings.Contains(info.StmtOrTrigger, "WHERE idx.body MATCH") {
     once.Do(func(){ close(entered); <-ctx.Done() })
    }
    return 0
   },
  })
 })
 if closeErr := conn.Close(); err == nil { err = closeErr }
 if err != nil { t.Fatal(err) }
 finished := make(chan error,1)
 go func(){
  read, err := d.BeginMessageRead(ctx)
  if err == nil {
   _, err = read.SearchReferences(ctx,1,"absentneedle")
   read.Close()
  }
  finished <- err
 }()
 select { case <-entered: case <-time.After(5*time.Second): t.Fatal("search never entered SQLite execution") }
 cancel()
 select {
 case err = <-finished:
  if !errors.Is(err,context.Canceled) { t.Fatalf("cancelled search: %v",err) }
 case <-time.After(5*time.Second): t.Fatal("cancelled search did not join")
 }
 reuse, stop := context.WithTimeout(context.Background(),5*time.Second)
 defer stop()
 var one int
 if err := d.Read.QueryRowContext(reuse,"SELECT 1").Scan(&one); err != nil || one != 1 { t.Fatalf("reader reuse: %d %v",one,err) }
}
