package database

import (
	"context"
	"encoding/json"
	"fmt"
	"path/filepath"
	"reflect"
	"testing"
)

const accessIN = "SELECT s.token,s.user_id FROM sessions s JOIN users u ON u.id=s.user_id WHERE u.status=0 AND s.token IN (SELECT value FROM json_each(?))"
const accessJOIN = "SELECT s.token,s.user_id FROM json_each(?) requested JOIN sessions s ON s.token=requested.value JOIN users u ON u.id=s.user_id WHERE u.status=0"
const accessMembership = " AND EXISTS (SELECT 1 FROM memberships m WHERE m.user_id=s.user_id AND m.room_id=?)"

func accessFixture(tb testing.TB, n int) (*DB, []string) {
	tb.Helper()
	d, err := Open(filepath.Join(tb.TempDir(), "access.sqlite3"), 4)
	if err != nil {
		tb.Fatal(err)
	}
	tb.Cleanup(func() {
		if err := d.Close(); err != nil {
			tb.Error(err)
		}
	})
	ctx := context.Background()
	stamp := Stamp(d.Now())
	if _, err = d.Write.ExecContext(ctx, "INSERT INTO rooms(id,creator_id,type,created_at,updated_at) VALUES(1,1,'Room',?,?)", stamp, stamp); err != nil {
		tb.Fatal(err)
	}
	tokens := make([]string, n)
	for i := range tokens {
		id := int64(i + 1)
		if _, err = d.Write.ExecContext(ctx, "INSERT INTO users(id,name,created_at,updated_at) VALUES(?,?,?,?)", id, fmt.Sprintf("Member %d", id), stamp, stamp); err != nil {
			tb.Fatal(err)
		}
		if _, err = d.Write.ExecContext(ctx, "INSERT INTO memberships(room_id,user_id,created_at,updated_at) VALUES(1,?,?,?)", id, stamp, stamp); err != nil {
			tb.Fatal(err)
		}
		token, err := d.StartSession(ctx, id, "probe", "127.0.0.1")
		if err != nil {
			tb.Fatal(err)
		}
		tokens[i] = token
	}
	return d, tokens
}

func accessQuery(ctx context.Context, d *DB, query string, tokens []string, room int64) (map[string]int64, error) {
	raw, err := json.Marshal(tokens)
	if err != nil {
		return nil, err
	}
	args := []any{string(raw)}
	if room != 0 {
		query += accessMembership
		args = append(args, room)
	}
	rows, err := d.Read.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := make(map[string]int64, len(tokens))
	for rows.Next() {
		var token string
		var user int64
		if err = rows.Scan(&token, &user); err != nil {
			return nil, err
		}
		result[token] = user
	}
	return result, rows.Err()
}

func TestAccessPlansAndEquivalentAuthority(t *testing.T) {
	d, tokens := accessFixture(t, 64)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var version string
	if err := d.Read.QueryRow("SELECT sqlite_version()").Scan(&version); err != nil {
		t.Fatal(err)
	}
	t.Log("sqlite", version)
	for _, room := range []int64{0, 1} {
		var baseline map[string]int64
		for _, q := range []struct{ name, sql string }{{"IN", accessIN}, {"JOIN", accessJOIN}} {
			got, err := accessQuery(ctx, d, q.sql, append(tokens, tokens[0], "missing"), room)
			if err != nil {
				t.Fatal(err)
			}
			if len(got) != 64 {
				t.Fatal("wrong population", len(got))
			}
			if baseline == nil {
				baseline = got
			} else if !reflect.DeepEqual(baseline, got) {
				t.Fatal("identity mismatch")
			}
			raw, _ := json.Marshal(tokens)
			query := q.sql
			args := []any{string(raw)}
			if room != 0 {
				query += accessMembership
				args = append(args, room)
			}
			rows, err := d.Read.QueryContext(ctx, "EXPLAIN QUERY PLAN "+query, args...)
			if err != nil {
				t.Fatal(err)
			}
			for rows.Next() {
				var id, parent, unused int
				var detail string
				if err := rows.Scan(&id, &parent, &unused, &detail); err != nil {
					t.Fatal(err)
				}
				t.Logf("%s room=%d %s", q.name, room, detail)
			}
			if err := rows.Err(); err != nil {
				t.Fatal(err)
			}
			rows.Close()
		}
	}
}

func BenchmarkAuthorizationAccess(b *testing.B) {
	for _, n := range []int{1, 64} {
		d, tokens := accessFixture(b, n)
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		for _, room := range []int64{0, 1} {
			for _, q := range []struct{ name, sql string }{{"IN", accessIN}, {"JOIN", accessJOIN}} {
				b.Run(fmt.Sprintf("people=%d/room=%d/%s", n, room, q.name), func(b *testing.B) {
					b.ReportAllocs()
					for b.Loop() {
						got, err := accessQuery(ctx, d, q.sql, tokens, room)
						if err != nil || len(got) != n {
							b.Fatalf("%v %d", err, len(got))
						}
					}
				})
			}
		}
	}
}
