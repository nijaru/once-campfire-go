#!/usr/bin/env bash
set -euo pipefail
root="$HOME/.cache/campfire-publication-map-20261011"
cp -a "$HOME/.cache/campfire-post-fix-20261010/seed" "$root/functional-seed"
sha256sum "$root/functional-seed/db/production.sqlite3"
docker run --rm --network host --security-opt label=disable -v "$root/functional-seed:/seed" -v "$HOME/.cache/campfire-search-query-20261011/correctness-root:/contract-root:ro" -v "$root/gates:/gates" localhost/campfire-publication-map-production python3 /build/ws-json/bin/check-parity --rust-root /contract-root --seed /seed --go-binary /go-candidate --rust-binary /rust-current --out /gates/functional-fixed --only message_lifecycle pagination room_membership authentication
