#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/.cache/campfire-publication-map-20261011"
name="cf-publication-map-browser-$$"
data="$PWD/browser-runtime"
mkdir "$data"
chmod a+rwx "$data"
trap 'docker rm -f "$name" >/dev/null 2>&1 || true' EXIT
docker run -d --name "$name" --network host --security-opt label=disable -e SECRET_KEY_BASE=browser-test-only -e DISABLE_SSL=1 -e HTTP_PORT=25360 -e TARGET_PORT=25361 -e TARGET_BIND=127.0.0.1 -v "$data:/rails/storage" localhost/campfire-publication-map-production /go-candidate server
for i in $(seq 1 100); do if curl -sf http://127.0.0.1:25360/up >/dev/null; then break; fi; sleep 0.1; done
sha256sum "$HOME/.cache/campfire-search-query-20261011/browser-source/browser/smoke.mjs"
docker inspect localhost/campfire-search-browser --format '{{.Id}}'
docker run --rm --network host --ipc=host localhost/campfire-search-browser node browser/smoke.mjs --base http://127.0.0.1:25360
