require_relative '../campfire-post-fix-20261010/bench/comparison_support'
require_relative '../campfire-post-fix-20261010/bench/http_client'
require_relative '../campfire-post-fix-20261010/bench/contracts'
require 'digest'
require 'time'
require 'net/http'
require 'zlib'
require 'stringio'
include BenchmarkSupport
root=Dir.pwd
fixture=File.expand_path('../campfire-post-fix-20261010',root)
seed=File.join(fixture,'seed')
out=File.join(root,'comparison-final')
raise 'output exists' if File.exist?(out)
FileUtils.mkdir_p(out)
labels=JSON.parse(File.read(File.join(seed,'labels.json')))
config=File.readlines(File.join(fixture,'reference.env'),chomp:true).reject { |l| l.empty? || l.start_with?('#') }.to_h { |l| l.split('=',2) }
loadgen=File.join(fixture,'loadgen-src/loadgen/target/release/loadgen')
room=Integer(labels.fetch('rooms.watercooler'))
base='http://127.0.0.1:25310'
container="cf-search-query-#{Process.pid}"
image='localhost/campfire-author-projection'
metadata={started_at:Time.now.utc.iso8601,base_revision:'ccfa838840e57f5a0935f6ef4c569557642010b7',candidate:'body-only miss projection; full-record creator projection retained',image_id:run('docker','inspect','--format','{{.Id}}',image).strip,seed_sha256:Digest::SHA256.file(File.join(seed,'db/production.sqlite3')).hexdigest,loadgen_sha256:Digest::SHA256.file(loadgen).hexdigest,server_cpus:'0,2,4,6',client_cpus:'8,10,12,14',settings:{warmup:2,duration:30,warmup_concurrency:4,concurrency:8,gzip:1,gogc:100,workers:4,readers:4,job_concurrency:3,response_cache_mb:0,fragment_cache_mb:0},cohort:{rounds:1,orders:[%w[candidate baseline]],stop_early:false},instrumentation:'none; no task-owned builds/tests/agents/profilers during timing',warm_control:'same forty-message pagination with default 32MB response/fragment budgets; not general capacity',follow_up:'one final longer candidate-first page pair after independent review found effect size unresolved; no further timing',hypothesis:'body-only display miss projection removes duplicate author JOIN/name copies; land only consistent meaningful uncached full-response gains without regression or contract loss',fixture_basis:'existing sparse-membership regression: 100 older accessible, 1100 newer matches with 50 reachable among newest1000; seeded dense coffee control; not a general capacity benchmark',binary_sha256:{baseline:run('docker','run','--rm',image,'sha256sum','/go-search-candidate').split.first,candidate:run('docker','run','--rm',image,'sha256sum','/go-author-projection').split.first}}
results=[]
sql=->(db,q) { text=run('sqlite3','-cmd','.timeout 10000','-json',db,q); text.strip.empty? ? [] : JSON.parse(text) }
lg=->(*args) { JSON.parse(run('taskset','-c','8,10,12,14',loadgen,*args)) }
begin
  1.times do |_|
    round=3
    order=round.even? ? %w[baseline candidate] : %w[candidate baseline]
    order.each do |app|
      data="/dev/shm/campfire-search-query/#{Process.pid}/#{app}-#{round+1}"
      prepare_storage(seed,data)
      FileUtils.mkdir_p(File.join(data,'logs'))
      db=File.join(data,'db/production.sqlite3')
      actor=sql.call(db,"SELECT id FROM users WHERE email_address='#{labels.fetch('emails.david').gsub("'","''")}'").first.fetch('id')
      stamp='2026-10-10 00:00:00.000000'
      sql.call(db,"UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id; UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id;")
      hidden=sql.call(db,"INSERT INTO rooms(creator_id,name,type,created_at,updated_at) VALUES (#{actor},'Sparse probe','Rooms::Closed','#{stamp}','#{stamp}') RETURNING id;").first.fetch('id')
      sql.call(db,"BEGIN; WITH RECURSIVE n(i) AS (VALUES(0) UNION ALL SELECT i+1 FROM n WHERE i<1199) INSERT INTO messages(room_id,creator_id,client_message_id,created_at,updated_at) SELECT CASE WHEN i<100 OR (i>=200 AND (i-100)%20=0) THEN #{room} ELSE #{hidden} END,#{actor},'sparse-probe-'||i,'#{stamp}','#{stamp}' FROM n; INSERT INTO action_text_rich_texts(name,record_type,record_id,body,created_at,updated_at) SELECT 'body','Message',id,'<p>sparseneedle</p>','#{stamp}','#{stamp}' FROM messages WHERE client_message_id LIKE 'sparse-probe-%'; INSERT INTO message_search_index(rowid,body) SELECT id,'sparseneedle' FROM messages WHERE client_message_id LIKE 'sparse-probe-%'; COMMIT;")
      raise 'inaccessible fixture leaked membership' unless sql.call(db,"SELECT count(*) n FROM memberships WHERE room_id=#{hidden} AND user_id=#{actor}").first.fetch('n')==0
      raise 'fixture population' unless sql.call(db,"SELECT count(*) n FROM message_search_index WHERE body MATCH 'sparseneedle'").first.fetch('n')==1200
      env=config.merge('HTTP_PORT'=>'25310','TARGET_PORT'=>'25311','GOMAXPROCS'=>'4','TOKIO_WORKER_THREADS'=>'4','RAILS_MAX_THREADS'=>'4','JOB_CONCURRENCY'=>'3','GOGC'=>'100','CAMPFIRE_RESPONSE_CACHE_MB'=>'0','CAMPFIRE_FRAGMENT_CACHE_MB'=>'0')
      binary=app=='candidate' ? '/go-author-projection' : '/go-search-candidate'
      run('docker','run','-d','--name',container,'--network','host','--security-opt','label=disable',*environment(env),*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),image,'taskset','-c','0,2,4,6',binary,'server')
      deadline=clock+60
      client=BenchmarkHTTPClient.new(base)
      until client.ready?; raise 'not ready' if clock>deadline; sleep 0.1; end
      run('docker','exec','--user','root',container,'chmod','-R','a+rwX','/rails/storage/db')
      sleep 3
      cookie=lg.call('login','--base',base,'--email',labels.fetch('emails.david'),'--password',labels.fetch('passwords.all')).fetch('cookie')
      scrape=lg.call('scrape','--base',base,'--cookie',cookie,'--room',room.to_s)
      BenchmarkContracts.prepare(base,cookie,db,labels,scrape.fetch('css'),File.join(data,'contracts'))
      row={app:app,round:round+1,http:[],load_start:File.read('/proc/loadavg').strip}
      {'page'=>nil}.each do |name,term|
        if name=='warm-page'
          remove_container(container)
          warm_env=env.merge('CAMPFIRE_RESPONSE_CACHE_MB'=>'32','CAMPFIRE_FRAGMENT_CACHE_MB'=>'32')
          run('docker','run','-d','--name',container,'--network','host','--security-opt','label=disable',*environment(warm_env),*mounts(File.join(data,'db')=>'/rails/storage/db',File.join(data,'files')=>'/rails/storage/files',File.join(data,'logs')=>'/rails/storage/logs'),image,'taskset','-c','0,2,4,6',binary,'server')
          deadline=clock+60
          until client.ready?; raise 'warm server not ready' if clock>deadline; sleep 0.1; end
          sleep 3
        end
        path=term ? "/searches?q=#{term}" : "/rooms/#{room}/messages?before=#{labels.fetch('messages.busy_060')}"
        ids=sql.call(db,"SELECT m.id FROM messages m JOIN message_search_index idx ON idx.rowid=m.id JOIN memberships mm ON mm.room_id=m.room_id WHERE mm.user_id=#{actor} AND idx.body MATCH '#{term}' ORDER BY m.id DESC LIMIT 100").map { |r| r.fetch('id') }.reverse if term
        if name.end_with?('page')
          anchor=Integer(labels.fetch('messages.busy_060'))
          ids=sql.call(db,"SELECT m.id FROM messages m WHERE room_id=#{room} AND created_at<(SELECT created_at FROM messages WHERE id=#{anchor}) ORDER BY created_at DESC LIMIT 40").map { |r| r.fetch('id') }.reverse
          raise 'bad page cardinality' unless ids.length==40
        end
        raise 'bad sparse cardinality' if name=='sparse' && ids.length!=100
        response=Net::HTTP.new('127.0.0.1',25310,nil).start { |h| h.get(path,'Cookie'=>cookie,'Accept-Encoding'=>'gzip') }
        body=response['content-encoding']=='gzip' ? Zlib::GzipReader.new(StringIO.new(response.body)).read : response.body
        raise 'preflight IDs' unless response.code=='200' && body.scan(/data-message-id="(\d+)"/).flatten.map(&:to_i)==ids
        rows=sql.call(db,"SELECT m.id,m.client_message_id,idx.body FROM messages m JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id IN (#{ids.join(',')})")
        by_id=rows.to_h { |r| [r.fetch('id'),r] }
        required=ids.map { |id| ["id=\"message_#{id}\"","id=\"message_#{by_id.fetch(id).fetch('client_message_id')}\""].find { |marker| body.include?(marker) } || raise('DOM identity missing') }
        contract=File.join(data,"#{name}-contract.json")
        write_json(contract,kind:name.end_with?('page') ? 'messages_page' : 'search',content_type:'text/html',required:required,message_ids:ids,message_content:ids.map { |id| by_id.fetch(id).fetch('body').scan(/[A-Za-z0-9_]+/) })
        [2,30].each do |duration|
          sample=lg.call('http','--base',base,'--cookie',cookie,'--path',path,'--gzip','1','--conc',duration==2 ? '4' : '8','--duration',duration.to_s,'--validate',contract)
          write_json(File.join(out,"#{app}-#{round+1}-#{name}-#{duration}-failed.json"),sample) unless sample.fetch('errors')==0 && sample.fetch('invalid_responses')==0
          raise 'invalid complete responses' unless sample.fetch('errors')==0 && sample.fetch('invalid_responses')==0 && sample.fetch('validation')=='route-contract-v1' && sample.fetch('statuses')=={'200'=>sample.fetch('ok')}
          sample['workload']=name
          sample['cache_budget_mb']=name=='warm-page' ? 32 : 0
          sample['warmup']=duration==2
          sample['expected_messages']=ids.length
          row[:http]<<sample
          write_json(File.join(out,"#{app}-#{round+1}-#{name}-#{duration}.json"),sample)
          puts "#{app} #{round+1} #{name} #{duration}s: #{sample.fetch('rps')} rps p99=#{sample.dig('latency','p99_ms')}ms; #{sample.fetch('ok')} validated complete responses"
          STDOUT.flush
        end
      end
      row[:load_end]=File.read('/proc/loadavg').strip
      raise 'integrity' unless sql.call(db,'PRAGMA integrity_check').first.values==['ok']
      results<<row
      write_json(File.join(out,'results.json'),results)
      write_json(File.join(out,'metadata.json'),metadata)
      remove_container(container)
      FileUtils.rm_rf(data)
    end
  end
ensure
  remove_container(container)
end
