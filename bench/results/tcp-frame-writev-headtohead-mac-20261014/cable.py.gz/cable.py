import contextlib, hashlib, http.cookiejar, json, os, platform, re, shutil, signal, socket, sqlite3, subprocess, sys, tempfile, time, urllib.parse, urllib.request
from pathlib import Path
ROOT=Path.cwd(); W=ROOT/'.cache/frame-writev-headtohead-20261014'; SEED=ROOT/'.cache/parity-seeds/default'; OUT=W/'cable'; OUT.mkdir(exist_ok=False)
LABELS=json.loads((SEED/'labels.json').read_text()); ROOM=int(LABELS['rooms.watercooler']); LG=W/'binaries/loadgen-mac'
FIXTURE={}
for line in (ROOT/'.cache/shared-current/reference.env').read_text().splitlines():
 if line and not line.startswith('#'):
  k,v=line.split('=',1);FIXTURE[k]=v
CLIENT_ENV={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ}|{'TOKIO_WORKER_THREADS':'4'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def sql(db,q,params=()):
 with sqlite3.connect(db,timeout=10) as c:
  c.row_factory=sqlite3.Row
  return [dict(r) for r in c.execute(q,params).fetchall()]
def free_port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def snapshot(name):
 (OUT/name).write_text(subprocess.check_output(['uptime'],text=True)+subprocess.check_output(['ps','-A','-o','pid,pcpu,comm','-r'],text=True))
def ready(base,p):
 deadline=time.monotonic()+60
 while time.monotonic()<deadline:
  if p.poll() is not None:raise RuntimeError('server exited before readiness')
  try:
   if urllib.request.urlopen(base+'/up',timeout=1).status==200:return
  except OSError:pass
  time.sleep(.1)
 raise RuntimeError('readiness timeout')
def stop(p):
 if p.poll() is None:
  p.send_signal(signal.SIGTERM)
  try:p.wait(timeout=35)
  except subprocess.TimeoutExpired:p.kill();p.wait();raise
 if p.returncode!=0:raise RuntimeError(f'server/supervisor exit {p.returncode}')
def load(*args):return json.loads(subprocess.check_output([str(LG),*map(str,args)],text=True,env=CLIENT_ENV,timeout=60))
def login(base,email,ip):
 jar=http.cookiejar.CookieJar(); client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
 headers={'X-Forwarded-For':ip}
 body=client.open(urllib.request.Request(base+'/session/new',headers=headers)).read().decode();m=re.search(r'<meta name="csrf-token" content="([^"]*)"',body)
 data=urllib.parse.urlencode({'email_address':email,'password':LABELS['passwords.all'],'authenticity_token':m[1] if m else ''}).encode()
 client.open(urllib.request.Request(base+'/session',data=data,headers=headers|{'Sec-Fetch-Site':'same-origin'})).read()
 if not any(c.name=='session_token' for c in jar):raise RuntimeError('fixture HTTP login failed')
 return '; '.join(f'{c.name}={c.value}' for c in jar)
metadata=json.loads((W/'experiment.json').read_text())|{'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'platform':platform.platform(),'binaries':{a:sha(W/'binaries'/f'{a}-mac') for a in ['optimized','upstream','rust']},'client_sha256':sha(LG),'seed_sha256':sha(SEED/'db/production.sqlite3'),'go_version':subprocess.check_output(['/Users/nick/.local/share/mise/installs/go/1.27.1/bin/go','version'],text=True).strip(),'client_rust_version':subprocess.check_output(['rustc','--version'],text=True).strip(),'harness_sha256':sha(__file__),'setup_ip_policy':'RealHTTPlogin via supportedtrustedloopbackforwarding, synthetic198.51.100.N IPs; noMacloopbackaliases/configchanges. AllarmsFORWARD_HEADERS=true. Serverrestart resetsloginlimiter beforeworkload. Noauthorization bypass.'}
write(OUT/'metadata.json',metadata); results=[]; overall=time.monotonic()
try:
 for round,order in enumerate(metadata['orders'],1):
  for app in order:
   if time.monotonic()-overall>20*60:raise RuntimeError('declared20min Cablecapture deadline exceeded')
   prefix=f'{app}-{round}'
   with tempfile.TemporaryDirectory(prefix=prefix+'-',dir=W) as td:
    d=Path(td);db=d/'production.sqlite3'
    with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
    shutil.copytree(SEED/'storage',d/'files')
    sql(db,"UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id")
    sql(db,"UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
    sql(db,"WITH RECURSIVE n(i) AS (VALUES(1) UNION ALL SELECT i+1 FROM n WHERE i<64) INSERT INTO users(name,email_address,password_digest,role,status,created_at,updated_at) SELECT 'Fanout '||i,'fanout-'||i||'@example.test',password_digest,0,0,'2026-10-10 00:00:00','2026-10-10 00:00:00' FROM n CROSS JOIN users WHERE email_address=?",(LABELS['emails.david'],))
    sql(db,"INSERT INTO memberships(room_id,user_id,involvement,created_at,updated_at) SELECT ?,id,'everything','2026-10-10 00:00:00','2026-10-10 00:00:00' FROM users WHERE email_address LIKE 'fanout-%@example.test'",(ROOM,))
    if sql(db,"SELECT COUNT(*) n,COUNT(DISTINCT u.id) distinct_users FROM users u JOIN memberships m ON m.user_id=u.id WHERE u.email_address LIKE 'fanout-%@example.test' AND m.room_id=? AND u.role=0 AND u.status=0",(ROOM,))[0]!={'n':64,'distinct_users':64}:raise RuntimeError('fixture people mismatch')
    initial=sql(db,'SELECT MAX(id) id FROM messages')[0]['id']; seed_fk=sql(db,'PRAGMA foreign_key_check');actor=sql(db,'SELECT id FROM users WHERE email_address=?',(LABELS['emails.david'],))[0]['id']
    target,front=free_port(),free_port()
    while target==front:front=free_port()
    base=f'http://127.0.0.1:{front}'
    env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ}|FIXTURE|{'DISABLE_SSL':'true','FORWARD_HEADERS':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(d),'CAMPFIRE_FILES_PATH':str(d/'files'),'GOMAXPROCS':'4','JOB_CONCURRENCY':'3','TOKIO_WORKER_THREADS':'4','RAILS_MAX_THREADS':'4','GOGC':'100','GO_CPU_PROFILE':'','GO_PHASE_CPU':'','GO_ALLOC_PROFILE':'','GO_EXECUTION_TRACE':''}
    with (OUT/(prefix+'.log')).open('w') as log:
     p=subprocess.Popen([str(W/'binaries'/f'{app}-mac'),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
     try:
      ready(base,p);cookie=load('login','--base',base,'--email',LABELS['emails.david'],'--password',LABELS['passwords.all'])['cookie'];scrape=load('scrape','--base',base,'--cookie',cookie,'--room',ROOM)
      if scrape['status']!=200 or len(scrape['streams'])!=3:raise RuntimeError('creator room preflight failed')
      sessions=d/'sessions.tsv'
      with sessions.open('w') as f:
       os.chmod(sessions,0o600)
       for n in range(64):
        c=login(base,f'fanout-{n+1}@example.test',f'198.51.100.{n+2}')
        page=load('scrape','--base',base,'--cookie',c,'--room',ROOM)
        if page['status']!=200 or len(page['streams'])!=3:raise RuntimeError('member room preflight failed')
        identifiers=[{'channel':'PresenceChannel','room_id':ROOM},{'channel':'UnreadRoomsChannel'},{'channel':'HeartbeatChannel'}]
        identifiers.extend({'channel':channel,'signed_stream_name':name} for channel,name in (s.split('|',1) for s in page['streams']))
        f.write('\t'.join([c,*[json.dumps(i,separators=(',',':')) for i in identifiers]])+'\n')
      if sql(db,"SELECT COUNT(DISTINCT s.user_id) n FROM sessions s JOIN users u ON u.id=s.user_id WHERE u.email_address LIKE 'fanout-%@example.test'")[0]['n']!=64:raise RuntimeError('not64authenticatedpeople')
      stop(p)
      cpu=OUT/(prefix+'.cpu.json');env['ATTRIBUTION_CPU_PATH']=str(cpu)
      snapshot(prefix+'.host-before.txt')
      p=subprocess.Popen([sys.executable,str(W/'supervise-local.py'),str(W/'binaries'/f'{app}-mac'),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
      ready(base,p);time.sleep(3)
      command=[str(LG),'cable','--base',base,'--cookie',cookie,'--room',str(ROOM),'--csrf',scrape.get('csrf') or '','--clients','64','--sessions',str(sessions),'--latency-msgs','300','--interval-ms','100','--tput-secs','5','--posters','4','--refresh-secs','50']
      with (OUT/(prefix+'.phases.log')).open('w') as errors:
       process=subprocess.run(command,stdout=subprocess.PIPE,stderr=errors,text=True,env=CLIENT_ENV|{'HTTP_TRACE':'1'},timeout=180)
      (OUT/(prefix+'.raw.json')).write_text(process.stdout)
      if process.returncode!=0:raise RuntimeError(f'Cableclient exit{process.returncode}')
      subprocess.run(['ruby',str(ROOT/'.cache/shared-verification-current/bench/check_sample.rb'),'cable'],input=process.stdout,text=True,stdout=subprocess.DEVNULL,check=True)
      sample=json.loads(process.stdout)
      if sample['distinct_session_cookies']!=64 or sample['session_rows']!=64:raise RuntimeError('distinctsession shape mismatch')
      posted=sample['latency']['post_successes']+sample['throughput']['posted']
      rows=sql(db,"SELECT m.id,m.creator_id,m.room_id,rt.body,idx.body indexed_body FROM messages m LEFT JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' LEFT JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>?",(initial,))
      seqs=[int(m[1]) if (m:=re.fullmatch('fanout bmk([0-9]+)z',r['body'])) else None for r in rows]
      if len(rows)!=posted or sorted(s for s in seqs if s is not None)!=list(range(1,posted+1)):raise RuntimeError('canonicalpersisted population mismatch')
      if not all(r['creator_id']==actor and r['room_id']==ROOM and r['body']==r['indexed_body'] for r in rows):raise RuntimeError('creator/room/body/FTS mismatch')
      trace=sample.pop('http_trace')
      if len(trace)!=posted or sorted(r[:2] for r in trace)!=sorted([s,r['id']] for r,s in zip(rows,seqs)):raise RuntimeError('exactACK-ID mismatch')
      if not all(all(a<=b for a,b in zip(t[2:],t[3:])) for t in trace):raise RuntimeError('invalidHTTPtraceclock')
      indexed=sql(db,"SELECT COUNT(*) n FROM message_search_index WHERE rowid>? AND body MATCH 'fanout'",(initial,))[0]['n']
      if indexed!=posted or sql(db,'PRAGMA integrity_check')!=[{'integrity_check':'ok'}] or sql(db,'PRAGMA foreign_key_check')!=seed_fk:raise RuntimeError('databaseintegrity/FTS/FK failed')
      deadline=time.monotonic()+10
      while sql(db,"SELECT SUM(m.connections) n FROM memberships m JOIN users u ON u.id=m.user_id WHERE u.email_address LIKE 'fanout-%@example.test' AND m.room_id=?",(ROOM,))[0]['n']!=0:
       if time.monotonic()>deadline:raise RuntimeError('presence not released')
       time.sleep(.1)
      sample['write_audit']={'persisted':posted,'exact_canonical_ids_body_creator_room_fts':True,'integrity':'ok','indexed':indexed,'unchanged_seed_fk_violations':len(seed_fk),'presence_after_disconnect':0}
      stop(p);usage=json.loads(cpu.read_text())
      if usage['exit_code']!=0:raise RuntimeError('joinedserverexit nonzero')
      result={'app':app,'round':round,'cable':sample,'joined_cpu':usage,'cpu_per_write_us':usage['cpu_seconds']*1e6/posted}
      results.append(result);write(OUT/(prefix+'.json'),result);write(OUT/'results.json',results)
      snapshot(prefix+'.host-after.txt')
      print(f"{prefix}: {sample['throughput']['delivered_msgs_per_sec']}delivered/s, pacedp99 {sample['latency']['all_clients']['p99_ms']}ms, {result['cpu_per_write_us']:.3f}CPUus/write, {posted}audited",flush=True)
     finally:
      if p.poll() is None:stop(p)
finally:
 metadata['finished_at']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());metadata['completed_runs']=len(results)
 write(OUT/'metadata.json',metadata);write(OUT/'results.json',results)
