import hashlib,json,os,shutil,signal,socket,sqlite3,subprocess,tempfile,time,sys,urllib.request
from pathlib import Path
ROOT=Path.cwd();W=ROOT/'.cache/frame-writev-headtohead-20261014';MODE=sys.argv[1];assert MODE in ['fixed','capacity'];OUT=W/MODE;OUT.mkdir(exist_ok=False);SEED=ROOT/'.cache/parity-seeds/default';labels=json.loads((SEED/'labels.json').read_text())
sys.path.insert(0,str(ROOT/'bench'));from acknowledged_writes import verify
fixture={}
for line in (ROOT/'.cache/shared-current/reference.env').read_text().splitlines():
 if line and not line.startswith('#'):k,v=line.split('=',1);fixture[k]=v
clientenv={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ}|{'TOKIO_WORKER_THREADS':'4'}
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def load(*args):return json.loads(subprocess.check_output([str(W/'binaries/loadgen-mac'),*map(str,args)],text=True,env=clientenv,timeout=90))
def ready(base,p):
 end=time.monotonic()+60
 while True:
  if p.poll() is not None:raise RuntimeError('server exitedbefore readiness')
  try:
   if urllib.request.urlopen(base+'/up',timeout=1).status==200:return
  except OSError:pass
  if time.monotonic()>end:raise RuntimeError('startup timeout')
  time.sleep(.1)
def stop(p):
 if p.poll() is None:p.send_signal(signal.SIGTERM)
 try:p.wait(timeout=35)
 except subprocess.TimeoutExpired:p.kill();p.wait();raise
 if p.returncode!=0:raise RuntimeError(f'server/supervisor exit{p.returncode}')
def snapshot(name):
 (OUT/name).write_text(subprocess.check_output(['uptime'],text=True)+subprocess.check_output(['ps','-A','-o','pid,pcpu,comm','-r'],text=True))
metadata=json.loads((W/'experiment.json').read_text())|{'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'mode':MODE,'binaries':{a:sha(W/'binaries'/f'{a}-mac') for a in ['optimized','upstream','rust']},'shared_client_sha256':sha(W/'binaries/loadgen-mac'),'fixed_client_sha256':sha(W/'binaries/httprate-mac'),'harness_sha256':sha(__file__),'audit_helper_sha256':sha(ROOT/'bench/acknowledged_writes.py'),'capacity_validator_sha256':sha(ROOT/'.cache/shared-verification-current/bench/validate_acks.rb')}
write(OUT/'metadata.json',metadata);results=[];phase_started=time.monotonic()
try:
 for round,order in enumerate(metadata['orders'],1):
  for app in order:
   if time.monotonic()-phase_started>20*60:raise RuntimeError('phase budget exceeded')
   prefix=f'{app}-{round}'
   with tempfile.TemporaryDirectory(prefix=MODE+'-'+prefix+'-',dir=W) as td:
    d=Path(td);db=d/'production.sqlite3'
    with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
    shutil.copytree(SEED/'storage',d/'files');target,front=port(),port()
    while target==front:front=port()
    with sqlite3.connect(db) as c:
     c.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id");c.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
     actor=c.execute('SELECT id FROM users WHERE email_address=?',(labels['emails.david'],)).fetchone()[0];fk=c.execute('PRAGMA foreign_key_check').fetchall()
    env=clientenv|fixture|{'DISABLE_SSL':'true','FORWARD_HEADERS':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(d),'CAMPFIRE_FILES_PATH':str(d/'files'),'GOMAXPROCS':'4','TOKIO_WORKER_THREADS':'4','RAILS_MAX_THREADS':'4','JOB_CONCURRENCY':'3','GOGC':'100','GO_CPU_PROFILE':'','GO_PHASE_CPU':'','GO_ALLOC_PROFILE':'','GO_EXECUTION_TRACE':''}
    base=f'http://127.0.0.1:{front}';samples=[]
    with (OUT/(prefix+'.log')).open('w') as log:
     p=subprocess.Popen([str(W/'binaries'/f'{app}-mac'),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
     try:
      ready(base,p);cookie=load('login','--base',base,'--email',labels['emails.david'],'--password',labels['passwords.all'])['cookie'];page=load('scrape','--base',base,'--cookie',cookie,'--room',labels['rooms.watercooler'])
      if page['status']!=200 or len(page['streams'])!=3:raise RuntimeError('incomplete room')
      contracts=json.loads(subprocess.check_output(['ruby',str(ROOT/'.cache/shared-verification-current/bench/contracts.rb'),base,cookie,str(db),str(SEED/'labels.json'),page['css'],str(d/'contracts')],text=True,timeout=90))
      stop(p);cpu=OUT/(prefix+'.cpu.json');env['ATTRIBUTION_CPU_PATH']=str(cpu);snapshot(prefix+'.host-before.txt')
      p=subprocess.Popen([sys.executable,str(W/'supervise-local.py'),str(W/'binaries'/f'{app}-mac'),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
      ready(base,p);time.sleep(3)
      for duration in [2,8]:
       with sqlite3.connect(db) as c:before=c.execute('SELECT MAX(id) FROM messages').fetchone()[0]
       shared=['--base',base,'--cookie',cookie,'--gzip','1','--duration',str(duration),'--post-room',str(labels['rooms.hq']),'--csrf',page.get('csrf') or '']
       if MODE=='fixed':
        command=[str(W/'binaries/httprate-mac'),*shared,'--conc','64','--queue','8192','--pacing','active','--rate','3000']
       else:
        ack=OUT/(prefix+f'-{duration}-acks.jsonl')
        command=[str(W/'binaries/loadgen-mac'),'http',*shared,'--conc','4' if duration==2 else '16','--validate',contracts['contracts']['post_message'],'--audit-writes',str(ack)]
       raw=subprocess.check_output(command,text=True,env=clientenv,timeout=90)
       (OUT/(prefix+f'-{duration}.raw.json')).write_text(raw);sample=json.loads(raw)
       if MODE=='fixed':
        assert sample['ok']==3000*duration and sample['errors']==0 and sample['invalid_responses']==0 and sample['unscheduled']==0 and sample['statuses']=={'200':3000*duration},sample
        with sqlite3.connect(db) as c:audit=verify(c,before,labels['rooms.hq'],actor,sample)
        sample.pop('acknowledged')
       else:
        assert sample['ok']>0 and sample['errors']==0 and sample['invalid_responses']==0 and sample['validation']=='route-contract-v1' and sample['statuses']=={'200':sample['ok']},sample
        audit=json.loads(subprocess.check_output(['ruby',str(ROOT/'.cache/shared-verification-current/bench/validate_acks.rb'),str(db),str(labels['rooms.hq']),str(sample['ok']),str(ack)],text=True,timeout=90))
        acks=[json.loads(line) for line in ack.read_text().splitlines()]
        expected={a['id']:a['token'] for a in acks}
        with sqlite3.connect(db) as c:
         rows=c.execute("SELECT m.id,m.room_id,m.creator_id,m.client_message_id,rt.body,idx.body FROM messages m JOIN action_text_rich_texts rt ON rt.record_type='Message' AND rt.record_id=m.id AND rt.name='body' JOIN message_search_index idx ON idx.rowid=m.id WHERE m.id>?",(before,)).fetchall()
         assert c.execute('SELECT COUNT(*) FROM messages WHERE id>?',(before,)).fetchone()[0]==sample['ok']==len(rows)
        assert len({r[3] for r in rows})==len(rows) and {r[0] for r in rows}==set(expected)
        assert all(r[1]==int(labels['rooms.hq']) and r[2]==actor and expected[r[0]] in r[4] and r[5].split()==expected[r[0]].split() for r in rows)
        audit['exact_population_creator_room_unique_client_normalized_fts']=True
       sample['duration_seconds']=duration;sample['warmup']=duration==2;sample['write_audit']=audit;samples.append(sample);write(OUT/(prefix+f'-{duration}.json'),sample)
      with sqlite3.connect(db) as c:assert c.execute('PRAGMA integrity_check').fetchone()==('ok',) and c.execute('PRAGMA foreign_key_check').fetchall()==fk
      stop(p);usage=json.loads(cpu.read_text());assert usage['exit_code']==0
      result={'app':app,'round':round,'http':samples,'joined_cpu':usage,'shared_preflight':contracts['preflight'],'integrity':'ok','unchanged_seed_fk_violations':len(fk)};results.append(result);write(OUT/(prefix+'.json'),result);write(OUT/'results.json',results);snapshot(prefix+'.host-after.txt')
      print(prefix,MODE,'p99',samples[-1]['latency']['p99_ms'],'ms',sum(s['ok'] for s in samples),'auditedwrites',flush=True)
     finally:
      if p.poll() is None:stop(p)
finally:
 metadata['finished_at']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());metadata['completed_runs']=len(results);write(OUT/'metadata.json',metadata);write(OUT/'results.json',results)
