#!/usr/bin/env bash
set -euo pipefail
ROOT="$PWD"
W="$ROOT/.cache/frame-writev-headtohead-20261014"
GO=/Users/nick/.local/share/mise/installs/go/1.27.1/bin/go
mkdir -p "$W/binaries"
cp "$ROOT/.cache/frame-writev-20261014/binaries/candidate-mac" "$W/binaries/optimized-mac"
cp "$ROOT/.cache/frame-writev-20261014/binaries/loadgen-mac" "$W/binaries/loadgen-mac"
(cd "$W/upstream"; python3 bin/build-assets; CGO_ENABLED=1 "$GO" build -mod=readonly -tags sqlite_fts5 -trimpath -buildvcs=false -o "$W/binaries/upstream-mac" ./cmd/campfire)
EPOCH="$(python3 -c 'import json,datetime; x=json.load(open(".cache/frame-writev-headtohead-20261014/rust-commit.json"));print(int(datetime.datetime.fromisoformat(x["committer"]["date"].replace("Z","+00:00")).timestamp()))')"
LIBRARY_PATH=/opt/homebrew/lib SOURCE_DATE_EPOCH="$EPOCH" CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR="$W/rust-target" cargo build --release --locked --manifest-path "$W/rust/Cargo.toml" -p campfire
cp "$W/rust-target/release/campfire" "$W/binaries/rust-mac"
(cd "$ROOT/bench/httprate"; "$GO" build -mod=readonly -trimpath -buildvcs=false -o "$W/binaries/httprate-mac" .)
"$GO" version;rustc --version;pkg-config --modversion vips
shasum -a 256 "$W/binaries/"*
