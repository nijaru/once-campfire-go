import gzip,hashlib,json,subprocess,sys
from pathlib import Path
W=Path('.cache/frame-writev-headtohead-20261014');D=Path('bench/results/tcp-frame-writev-headtohead-mac-20261014');D.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
items=[]
def add(name,raw):
 p=D/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);body=gzip.compress(raw,compresslevel=9,mtime=0);p.write_bytes(body);items.append({'path':str(p.relative_to(D)),'raw_bytes':len(raw),'compressed_bytes':len(body),'raw_sha256':sha(raw),'compressed_sha256':sha(body)})
for name in ['experiment.json','identities.json','conclusion.json','conclusion.log','build.sh','build.log','build-offline-missing-dependency.log','preflight.py','preflight.log','capture-http.py','cable.py','supervise-local.py','httprate-tests.log','fixed.log','capacity.log','cable.log','summarize.py','rust-tree.json','rust-commit.json','desktop-reachability.log','pack.py']:
 add(name,(W/name).read_bytes())
for phase in ['fixed','capacity','cable','preflight']:
 for p in sorted((W/phase).rglob('*')):
  if not p.is_file():continue
  if p.suffix in ['.json','.jsonl'] or p.name.endswith('.phases.log'):add(str(p.relative_to(W)),p.read_bytes())
# Systemprocessrosters remainprivate;retainonlyhashes/uptime/loadline.
host=[]
for p in sorted(W.glob('*/*.host-*.txt')):
 b=p.read_bytes();host.append({'path':str(p.relative_to(W)),'private_raw_sha256':sha(b),'raw_bytes':len(b),'uptime_load_line':b.decode().splitlines()[0]})
add('host-snapshots.json',json.dumps({'hardware_model':'Mac15,9','logical_cpus':16,'memory_bytes':137438953472,'macOS':'26.6.2 (25G83)','CPU_affinity':'none','normal_background_activity':'WindowServer/Ghostty/otherrepositories;notexclusiveorassumedneutral','snapshots':host},indent=2).encode()+b'\n')
for p in sorted((W/'incomplete').rglob('*')):
 if p.is_file() and p.suffix in ['.json','.log'] and not p.name.startswith('upstream-'):add(str(p.relative_to(W)),p.read_bytes())
add('competitor-go.mod',(W/'upstream/go.mod').read_bytes());add('competitor-go.sum',(W/'upstream/go.sum').read_bytes());add('competitor-Cargo.toml',(W/'rust/Cargo.toml').read_bytes());add('competitor-Cargo.lock',(W/'rust/Cargo.lock').read_bytes())
manifest={'record':'tcp-frame-writev-headtohead-mac-20261014','artifacts':items,'artifact_count':len(items),'total_compressed_bytes':sum(x['compressed_bytes'] for x in items),'audited_performance_writes':969903,'preflight_writes':300,'all_audited_writes':970203,'excluded_setup_population':'http.pyshadowedstdlibbeforelogin/warmup/posting;0posts/0validruns;noapplicationpopulationexcluded','production_source':'8351224b56c9a3c6784ed5d7510857212133ac4c','privacy':'Runtimeapplicationlogs/fullsystemrosters/binaries/archives/fixtures/cookies/credentials/databasesprivate;numericbenchmarkACKs/shas/contracts/buildlogs/scriptsretained.'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in items:
 b=(D/x['path']).read_bytes();raw=gzip.decompress(b);assert sha(b)==x['compressed_sha256'] and sha(raw)==x['raw_sha256'] and len(b)==x['compressed_bytes'] and len(raw)==x['raw_bytes']
 if x['path'].endswith('.json.gz'):json.loads(raw)
print(len(items),'artifacts',manifest['total_compressed_bytes'],'bytes; allcompressed/rawhashes/CRC/lengths/JSONverified')
