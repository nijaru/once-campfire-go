import hashlib,json,os,shutil,signal,socket,sqlite3,subprocess,tempfile,time,sys
from pathlib import Path
ROOT=Path.cwd();W=ROOT/'.cache/frame-writev-headtohead-20261014';OUT=W/'preflight';OUT.mkdir(exist_ok=False);SEED=ROOT/'.cache/parity-seeds/default';labels=json.loads((SEED/'labels.json').read_text())
sys.path.insert(0,str(ROOT/'bench'));from acknowledged_writes import verify
fixture={}
for line in (ROOT/'.cache/shared-current/reference.env').read_text().splitlines():
 if line and not line.startswith('#'):k,v=line.split('=',1);fixture[k]=v
clientenv={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ}|{'TOKIO_WORKER_THREADS':'4'}
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def load(*args):return json.loads(subprocess.check_output([str(W/'binaries/loadgen-mac'),*map(str,args)],text=True,env=clientenv,timeout=90))
results=[]
for app in ['upstream','optimized','rust']:
 with tempfile.TemporaryDirectory(prefix='preflight-'+app+'-',dir=W) as td:
  d=Path(td);db=d/'production.sqlite3'
  with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:src.backup(dst)
  shutil.copytree(SEED/'storage',d/'files');target,front=port(),port()
  while target==front:front=port()
  env=clientenv|fixture|{'DISABLE_SSL':'true','FORWARD_HEADERS':'true','HTTP_PORT':str(front),'TARGET_PORT':str(target),'TARGET_BIND':'127.0.0.1','CAMPFIRE_DATABASE_PATH':str(db),'CAMPFIRE_STORAGE_PATH':str(d),'CAMPFIRE_FILES_PATH':str(d/'files'),'GOMAXPROCS':'4','TOKIO_WORKER_THREADS':'4','RAILS_MAX_THREADS':'4','JOB_CONCURRENCY':'3','GOGC':'100','GO_CPU_PROFILE':'','GO_PHASE_CPU':'','GO_ALLOC_PROFILE':'','GO_EXECUTION_TRACE':''}
  base=f'http://127.0.0.1:{front}'
  with (OUT/(app+'.log')).open('w') as log:
   p=subprocess.Popen([str(W/'binaries'/f'{app}-mac'),'server'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
   try:
    import urllib.request
    end=time.monotonic()+60
    while True:
     if p.poll() is not None:raise RuntimeError(f'{app} exitedbefore readiness')
     try:
      if urllib.request.urlopen(base+'/up',timeout=1).status==200:break
     except OSError:pass
     if time.monotonic()>end:raise RuntimeError('startup timeout')
     time.sleep(.1)
    cookie=load('login','--base',base,'--email',labels['emails.david'],'--password',labels['passwords.all'])['cookie'];page=load('scrape','--base',base,'--cookie',cookie,'--room',labels['rooms.watercooler'])
    if page['status']!=200 or len(page['streams'])!=3:raise RuntimeError('incomplete room')
    with sqlite3.connect(db) as c:
     c.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id");c.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
     initial=c.execute('SELECT MAX(id) FROM messages').fetchone()[0];actor=c.execute('SELECT id FROM users WHERE email_address=?',(labels['emails.david'],)).fetchone()[0];fk=c.execute('PRAGMA foreign_key_check').fetchall()
    contract=json.loads(subprocess.check_output(['ruby',str(ROOT/'.cache/shared-verification-current/bench/contracts.rb'),base,cookie,str(db),str(SEED/'labels.json'),page['css'],str(OUT/app)],text=True,timeout=90))
    raw=subprocess.check_output([str(W/'binaries/httprate-mac'),'--base',base,'--cookie',cookie,'--gzip','1','--conc','4','--queue','8192','--pacing','active','--rate','100','--duration','1','--post-room',str(labels['rooms.hq']),'--csrf',page.get('csrf') or ''],text=True,timeout=30)
    (OUT/(app+'.raw.json')).write_text(raw);sample=json.loads(raw)
    assert sample['ok']==100 and sample['errors']==0 and sample['invalid_responses']==0 and sample['unscheduled']==0 and sample['statuses']=={'200':100},sample
    with sqlite3.connect(db) as c:
     audit=verify(c,initial,labels['rooms.hq'],actor,sample)
     assert c.execute('PRAGMA integrity_check').fetchone()==('ok',) and c.execute('PRAGMA foreign_key_check').fetchall()==fk
    sample.pop('acknowledged');results.append({'app':app,'shared_preflight':contract['preflight'],'write_probe':sample,'audit':audit})
    (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(app,'sharedcontracts/100exactwrites pass',flush=True)
   finally:
    if p.poll() is None:p.send_signal(signal.SIGTERM)
    try:p.wait(timeout=35)
    except subprocess.TimeoutExpired:p.kill();p.wait();raise
    if p.returncode!=0:raise RuntimeError(f'{app} serverexit {p.returncode}')
