import json,statistics as S
from pathlib import Path
w=Path('.cache/frame-writev-headtohead-20261014');out={'valid_performance_runs':27,'functional_preflight_writes':300,'phases':{},'head_to_head_ratios':{},'limitations':['PhysicalnativeMac/noCPUaffinity/notexclusivetiming; normalotherrepo/UIwork. Threebalancedroundsnotconfidence/noisequantification.','RatioscomparethisnewMaccohort only; no835before-aftertimes orolderLinuxrankingssubstituted.','TCPgatherpath affectsCableframewrites,notfixedHTTPPOST. DifferentfixedPOSTrankingdoesnotestablishcandidatefixedPOSTgain.','FinalLinuxpromotioncontrols/fullintegrationgates remainpending; productionunchanged.','Capacityp99 atunequalachievedloads; joinedOSCPUincludesstartup,setup,idle,allwarm/timedwork/shutdown,notcomponentCPUattribution.']}
metrics={}
for phase in ['fixed','capacity','cable']:
 rows=json.loads((w/phase/'results.json').read_text());assert len(rows)==9 and {(r['app'],r['round']) for r in rows}=={(a,i) for a in ['optimized','upstream','rust'] for i in [1,2,3]}
 total=0;appsum={}
 for a in ['optimized','upstream','rust']:
  records=[]
  for r in [r for r in rows if r['app']==a]:
   assert r['joined_cpu']['exit_code']==0
   if phase=='cable':
    c=r['cable'];n=c['write_audit']['persisted'];total+=n
    assert c['ready']==64 and c['clients']==64 and c['session_rows']==64 and c['distinct_session_cookies']==64 and c['failed']==0 and c['subscriptions_per_client_range']=={'max':6,'min':6}
    assert c['latency']['complete']==300 and c['latency']['post_errors']==0 and c['throughput']['complete']==c['throughput']['posted'] and c['throughput']['post_errors']==0
    assert c['write_audit']['presence_after_disconnect']==0 and c['write_audit']['integrity']=='ok' and c['write_audit']['unchanged_seed_fk_violations']==1 and c['write_audit']['exact_canonical_ids_body_creator_room_fts']
    records.append({'round':r['round'],'delivery_per_second':c['throughput']['delivered_msgs_per_sec'],'paced_all_client_p99_ms':c['latency']['all_clients']['p99_ms'],'saturated_post_p99_ms':c['throughput']['post']['p99_ms'],'all_audited_writes':n,'cpu_per_write_us':r['cpu_per_write_us']})
   else:
    assert r['integrity']=='ok' and r['unchanged_seed_fk_violations']==1
    for x in r['http']:
     assert x['errors']==0 and x['invalid_responses']==0 and x['statuses']=={'200':x['ok']}
     if phase=='fixed':assert x['ok']==3000*x['duration_seconds'] and x['unscheduled']==0 and x['write_audit']['exact_ids_body_client_creator_room_fts']
     else:assert x['write_audit']['verified'] and x['write_audit']['exact_population_creator_room_unique_client_normalized_fts']
    n=sum(x['ok'] for x in r['http']);total+=n;x=r['http'][-1]
    records.append({'round':r['round'],'rps':x['rps'],'p99_ms':x['latency']['p99_ms'],'average_wire_bytes':x['avg_bytes'],'timed_writes':x['ok'],'all_audited_writes':n})
  keys=[k for k in records[0] if k not in ['round','all_audited_writes','timed_writes']]
  med={k:S.median(r[k] for r in records) for k in keys};appsum[a]={'records':records,'medians':med,'ranges':{k:[min(r[k] for r in records),max(r[k] for r in records)] for k in keys}}
 out['phases'][phase]={'audited_writes':total,'applications':appsum}
 for competitor in ['upstream','rust']:
  ratio={k:100*(appsum['optimized']['medians'][k]/appsum[competitor]['medians'][k]-1) for k in keys}
  out['head_to_head_ratios'].setdefault(phase,{})[competitor]=ratio
out['audited_performance_writes']=sum(p['audited_writes'] for p in out['phases'].values());out['all_audited_writes']=out['audited_performance_writes']+300
(w/'conclusion.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='phases'},indent=2))
for phase,p in out['phases'].items():
 print(phase)
 for a,v in p['applications'].items():print(a,v['medians'])
